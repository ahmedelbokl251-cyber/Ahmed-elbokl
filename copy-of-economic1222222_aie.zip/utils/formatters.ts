// utils/formatters.ts
// Fix: Updated imports to use the newly defined types from '../types'
import { Language, TranslatedString } from '../types';
import { translations } from '../translations';

type Translator = (key: keyof typeof translations | TranslatedString, params?: Record<string, string | number>) => string;

export const formatNumber = (num: number | null | undefined, language: Language = 'ar', t: Translator): string => {
  if (num === null || num === undefined || isNaN(num)) {
    return 'N/A';
  }

  const locale = language === 'ar' ? 'ar-EG' : 'en-US';

  if (Math.abs(num) >= 1_000_000_000) {
    return `${(num / 1_000_000_000).toLocaleString(locale, { maximumFractionDigits: 2 })} ${t('billion')}`;
  } else if (Math.abs(num) >= 1_000_000) {
    return `${(num / 1_000_000).toLocaleString(locale, { maximumFractionDigits: 2 })} ${t('million')}`;
  } else if (Math.abs(num) >= 1_000) {
    return `${(num / 1_000).toLocaleString(locale, { maximumFractionDigits: 2 })} ${t('thousand')}`;
  } else {
    return num.toLocaleString(locale, { maximumFractionDigits: 2 });
  }
};

export const formatFileSize = (bytes: number, language: Language = 'ar', t: Translator): string => {
  if (bytes === 0) return `0 ${t('bytes')}`;
  const k = 1024;
  const sizes: (keyof typeof translations)[] = ['bytes', 'kb', 'mb', 'gb', 'tb'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  const locale = language === 'ar' ? 'ar-EG' : 'en-US';
  return `${parseFloat((bytes / Math.pow(k, i)).toLocaleString(locale, { maximumFractionDigits: 2 }))} ${t(sizes[i])}`;
};

export const formatResponseContent = (response: string, language: Language = 'ar', t: Translator): string => {
  let html = response;

  // Inline code: `code`
  html = html.replace(/`(.*?)`/g, '<code>$1</code>');

  // Bold text: **text** -> <strong>text</strong>
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

  // Italics text: *text* or _text_ -> <em>text</em>
  html = html.replace(/(?<!\*)\*(?!\*)(.*?)(?<!\*)\*(?!\*)/g, '<em>$1</em>');
  html = html.replace(/(?<!\_)\_(?!\_)(.*?)(?<!\_)\_(?!\_)/g, '<em>$1</em>');

  // Links: [text](url)
  html = html.replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="text-blue-500 hover:underline">$1</a>');

  // Process line by line for block-level elements
  const lines = html.split('\n');
  let processedLines: string[] = [];
  let inList = false;
  let listType: 'ul' | 'ol' | null = null;
  let inTable = false;

  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();

    // Check for table start/end (simple markdown table check)
    if (line.match(/^\|.*?\|$/) || line.match(/^\|[-=]+\|[-=]+\|/)) {
        if (!inTable) {
            processedLines.push('<table class="data-table">');
            inTable = true;
        }
        // Process table rows (split by | and trim, then wrap in th/td)
        const cells = line.split('|').map(cell => cell.trim()).filter(cell => cell !== '');
        if (line.match(/^\|[-=]+\|[-=]+\|/)) { // Separator row
            processedLines.push('<thead><tr>' + cells.map(cell => `<th></th>`).join('') + '</tr></thead><tbody>');
        } else {
            const tag = (processedLines.slice(-1)[0] === '<table class="data-table">' || processedLines.slice(-1)[0].includes('<thead>')) ? 'th' : 'td';
            processedLines.push('<tr>' + cells.map(cell => `<${tag}>${cell}</${tag}>`).join('') + '</tr>');
        }
        inList = false; // Tables break lists
        listType = null;
    } else {
        if (inTable) {
            processedLines.push('</tbody></table>');
            inTable = false;
        }

        // Headings
        if (line.startsWith('### ')) {
          processedLines.push('<h3>' + line.substring(4) + '</h3>');
          inList = false;
        } else if (line.startsWith('## ')) {
          processedLines.push('<h2>' + line.substring(3) + '</h2>');
          inList = false;
        } else if (line.startsWith('# ')) {
          processedLines.push('<h1>' + line.substring(2) + '</h1>');
          inList = false;
        }
        // Blockquotes
        else if (line.startsWith('> ')) {
          processedLines.push('<blockquote>' + line.substring(2) + '</blockquote>');
          inList = false;
        }
        // Code blocks
        else if (line.startsWith('```')) {
          const codeBlockEnd = lines.indexOf('```', i + 1);
          if (codeBlockEnd !== -1) {
            const code = lines.slice(i + 1, codeBlockEnd).join('\n');
            processedLines.push('<pre><code>' + code + '</code></pre>');
            i = codeBlockEnd;
            inList = false;
          } else {
            processedLines.push('<p class="mb-2">' + line + '</p>'); // Fallback if no closing ```
          }
        }
        // Unordered lists
        else if (line.match(/^[-*]\s/)) {
          if (!inList || listType !== 'ul') {
            if (inList) processedLines.push(`</${listType}>`); // Close previous list
            processedLines.push('<ul class="list-disc pr-5 mt-1 space-y-1">');
            inList = true;
            listType = 'ul';
          }
          processedLines.push('<li>' + line.substring(line.match(/^[-*]\s/)![0].length) + '</li>');
        }
        // Ordered lists
        else if (line.match(/^\d+\.\s/)) {
          if (!inList || listType !== 'ol') {
            if (inList) processedLines.push(`</${listType}>`); // Close previous list
            processedLines.push('<ol class="list-decimal pr-5 mt-1 space-y-1">');
            inList = true;
            listType = 'ol';
          }
          processedLines.push('<li>' + line.substring(line.match(/^\d+\.\s/)![0].length) + '</li>');
        }
        // Paragraphs or other content
        else if (line) {
          if (inList) { // Close list if paragraph starts
            processedLines.push(`</${listType}>`);
            inList = false;
            listType = null;
          }
          // Check if it's already an HTML block element (e.g., div)
          if (line.startsWith('<') && line.endsWith('>')) {
            processedLines.push(line);
          } else {
            processedLines.push('<p class="mb-2">' + line + '</p>');
          }
        } else { // Empty line
          if (inList) { // If empty line, close list
            processedLines.push(`</${listType}>`);
            inList = false;
            listType = null;
          }
          processedLines.push(''); // Keep empty lines for spacing
        }
    }
  }

  if (inList) { // Close any open list at the end
    processedLines.push(`</${listType}>`);
  }
  if (inTable) { // Close any open table at the end
    processedLines.push('</tbody></table>');
  }

  html = processedLines.join('\n');

  // Specific styling for analysis boxes and prediction items that might be generated as raw HTML
  html = html.replace(/<div class="data-source-badge">/g, '<span class="data-source-badge">');
  html = html.replace(/<\/div class="data-source-badge">/g, '</span>');

  return html;
};