import { GenerateContentResponse } from '@google/genai';
// Fix: Updated imports to use the newly defined types from '../types'
import { StandardEconomicDataItem, GroundingUrl, Language } from '../types';
import { REAL_DATA_SOURCES, INDICATORS, COUNTRIES } from '../constants'; // Import INDICATORS and COUNTRIES
import { translations } from '../translations'; // Import translations for proper typing
// Fix: Imported formatNumber from formatters.ts
import { formatNumber } from './formatters';

// Helper type for the translator function
type Translator = (key: keyof typeof translations | string, params?: Record<string, string | number>) => string;


export function getCountryName(code: string, language: Language, t: Translator): string {
  const country = COUNTRIES.find(c => c.code === code);
  return country?.name[language] || code;
}

export function getIndicatorName(code: string, dataSource: string, language: Language, t: Translator): string {
  if (dataSource === REAL_DATA_SOURCES.worldbank.sourceId) {
    const indicator = REAL_DATA_SOURCES.worldbank.indicators?.[code];
    return indicator?.name[language] || code;
  } else if (dataSource === REAL_DATA_SOURCES.fred.sourceId) {
    const indicator = INDICATORS.find(i => i.fredCode === code);
    return indicator?.name[language] || code;
  }
  return code;
}

export function getUnitName(code: string, dataSource: string, language: Language, t: Translator): string {
  if (dataSource === REAL_DATA_SOURCES.worldbank.sourceId) {
    const indicator = REAL_DATA_SOURCES.worldbank.indicators?.[code];
    return indicator?.unit[language] || '';
  } else if (dataSource === REAL_DATA_SOURCES.fred.sourceId) {
    const indicator = INDICATORS.find(i => i.fredCode === code);
    return indicator?.unit[language] || ''; // Return unit from INDICATORS for FRED
  }
  return ''; // Default empty string if not found
}

/**
 * Calculates basic statistics for a given array of StandardEconomicDataItem.
 * @param data - Array of StandardEconomicDataItem.
 * @param language - Current language.
 * @param t - Translation function.
 * @returns A formatted string of statistics.
 */
export const calculateRealStatistics = (
  data: StandardEconomicDataItem[],
  language: Language,
  t: Translator
): {
  latestValue: number | null;
  latestYear: string;
  averageValue: number;
  maxValue: number;
  minValue: number;
  trend: string;
} => {
  const values = data.map(item => item.value).filter(val => val !== null) as number[];
  if (values.length === 0) {
    return {
      latestValue: null,
      latestYear: 'N/A',
      averageValue: 0,
      maxValue: 0,
      minValue: 0,
      trend: t('noDataFound'),
    };
  }

  const latestValue = data[data.length - 1].value;
  const latestYear = data[data.length - 1].year;
  const averageValue = values.reduce((sum, val) => sum + val, 0) / values.length;
  const maxValue = Math.max(...values);
  const minValue = Math.min(...values);

  let trend = t('stable');
  if (data.length > 1) {
    const firstValue = data[0].value;
    const lastValue = data[data.length - 1].value;
    if (firstValue !== null && lastValue !== null && firstValue !== 0) {
      const change = ((lastValue - firstValue) / firstValue) * 100;

      if (change > 10) trend = t('strongUpward');
      else if (change > 0) trend = t('upward');
      else if (change < -10) trend = t('strongDownward');
      else if (change < 0) trend = t('downward');
    }
  }

  return {
    latestValue,
    latestYear,
    averageValue,
    maxValue,
    minValue,
    trend,
  };
};

/**
 * Generates an insight based on current data.
 * @param data - Array of StandardEconomicDataItem.
 * @param language - Current language.
 * @param t - Translation function.
 * @returns A string containing an analytical insight.
 */
export const generateRealInsight = (
  data: StandardEconomicDataItem[],
  language: Language,
  t: Translator
): string => {
  if (data.length === 0) {
    return t('noDataFoundForAnalysis');
  }

  const stats = calculateRealStatistics(data, language, t);
  const indicatorName = getIndicatorName(data[0].indicatorCode, data[0].source, language, t);
  const countryName = data[0].countryCode ? getCountryName(data[0].countryCode, language, t) : t('notApplicable');
  const unit = getUnitName(data[0].indicatorCode, data[0].source, language, t);

  // Insight 1: Latest data point
  let insight = t('latestDataFor', {
    indicator: indicatorName,
    country: countryName,
    value: formatNumber(stats.latestValue, language, t) + (unit ? ` ${unit}` : ''),
    year: stats.latestYear,
  });

  // Insight 2: Change from start to end
  if (data.length > 1) {
    const firstValue = data[0].value;
    const lastValue = data[data.length - 1].value;
    if (firstValue !== null && lastValue !== null && firstValue !== 0) {
      const changePercentage = ((lastValue - firstValue) / firstValue * 100).toFixed(2);
      const status = parseFloat(changePercentage) >= 0 ? t('improvement') : t('decline');
      insight += ` ${t('performanceChange', { change: changePercentage, status: status })}`;
    }
  }

  // Insight 3: Overall trend
  insight += ` ${t('overallTrend', { period: `${data[0].year}-${data[data.length - 1].year}`, trend: stats.trend })}`;

  return insight;
};

/**
 * Generates a recommendation based on current data.
 * @param data - Array of StandardEconomicDataItem.
 * @param language - Current language.
 * @param t - Translation function.
 * @returns A string containing a recommendation.
 */
export const generateRealRecommendation = (
  data: StandardEconomicDataItem[],
  language: Language,
  t: Translator
): string => {
  if (data.length === 0) {
    return t('noDataForRecommendations');
  }

  const stats = calculateRealStatistics(data, language, t);
  const indicatorCode = data[0].indicatorCode;
  const latestValue = stats.latestValue;
  const trend = stats.trend;

  let recommendation = t('monitorContinuously');

  if (indicatorCode.includes('GDP')) { // GDP
    if (trend === t('upward') || trend === t('strongUpward')) {
      recommendation = t('continueCurrentGrowthPolicies');
    } else {
      recommendation = t('stimulusPoliciesNeeded');
    }
  } else if (indicatorCode.includes('CPI') || indicatorCode.includes('Inflation')) { // Inflation
    if (latestValue !== null && latestValue !== undefined && latestValue > 5) { // Assuming >5% is high inflation
      recommendation = t('monitorInflationActions');
    } else {
      recommendation = t('inflationAcceptable');
    }
  } else if (indicatorCode.includes('UEM') || indicatorCode.includes('Unemployment')) { // Unemployment
    if (latestValue !== null && latestValue !== undefined && latestValue > 7) { // Assuming >7% is high unemployment
      recommendation = t('employmentProgramsNeeded');
    } else {
      recommendation = t('unemploymentAcceptable');
    }
  } else if (indicatorCode.includes('INR') || indicatorCode.includes('Interest Rates') || indicatorCode.includes('FEDFUNDS')) { // Interest Rates
    if (latestValue !== null && latestValue !== undefined && latestValue > 3) recommendation = t('highInterestRatesImpact');
    else recommendation = t('lowInterestRatesBenefit');
  } else if (indicatorCode.includes('EXP')) { // Exports
    if (trend.includes(t('upward'))) recommendation = t('boostExportsPolicies');
    else recommendation = t('reviewTradePolicies');
  } else if (indicatorCode.includes('IMP')) { // Imports
    if (trend.includes(t('strongUpward'))) recommendation = t('encourageLocalProduction');
    else recommendation = t('balanceImports');
  }

  return recommendation;
};

/**
 * Extracts grounding URLs from a Gemini `GenerateContentResponse`.
 * @param response The Gemini API response.
 * @returns An array of `GroundingUrl` objects.
 */
export const getGroundingUrls = (response: GenerateContentResponse): GroundingUrl[] => {
  const urls: GroundingUrl[] = [];
  const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;

  if (groundingChunks) {
    for (const chunk of groundingChunks as any[]) { // Assert to any[] for flexible access
      if (chunk.web && chunk.web.uri) {
        urls.push({ uri: chunk.web.uri, title: chunk.web.title });
      }
      if (chunk.maps && chunk.maps.uri) {
        urls.push({ uri: chunk.maps.uri, title: chunk.maps.title });
      }
      if (chunk.maps?.placeAnswerSources) {
        // Fix: Use type assertion for placeAnswerSources to ensure it's iterable
        for (const source of chunk.maps.placeAnswerSources as any[]) {
          if (source.reviewSnippets) {
            // Fix: Use type assertion for reviewSnippets
            for (const snippet of source.reviewSnippets as any[]) {
              if (snippet.uri) {
                urls.push({ uri: snippet.uri, title: snippet.text });
              }
            }
          }
        }
      }
    }
  }
  return urls;
};


// Helper to strip HTML tags for plain text content
export const stripHtml = (htmlString: string): string => {
  const doc = new DOMParser().parseFromString(htmlString, 'text/html');
  return doc.body.textContent || '';
};

// Helper to get today's date in YYYY-MM-DD format
export const getTodayDateString = (): string => {
  return new Date().toISOString().split('T')[0];
};

// Helper to get date five years ago in YYYY-MM-DD format
export const getFiveYearsAgoDateString = (): string => {
  const date = new Date();
  date.setFullYear(date.getFullYear() - 5);
  return date.toISOString().split('T')[0];
};