
// types.ts
export enum MessageRole {
  USER = 'user',
  MODEL = 'model',
  // Fix: Added TOOL role for function call responses.
  TOOL = 'tool',
}

export interface TextPart {
  type: 'text';
  content: string;
  // Fix: Added isStreaming property to TextPart
  isStreaming?: boolean;
}

export interface ImagePart {
  type: 'image';
  content: string; // Base64 encoded image data (without prefix)
  mimeType: string;
}

// New types for Chart visualization
export interface ChartData {
  labels: string[];
  datasets: Array<{
    label: string;
    data: (number | null)[];
    borderColor?: string;
    backgroundColor?: string | string[];
    fill?: boolean;
    tension?: number;
    yAxisID?: string; // For multiple Y axes
  }>;
}

export interface ChartPart {
  type: 'chart';
  chartType: 'line' | 'bar'; // Start with common types, extend as needed
  title: string;
  data: ChartData;
  options?: any; // Chart.js options
}

export type MessagePart = TextPart | ImagePart | ChartPart;

// Primary Chat Message type for App.tsx -> ChatWindow.tsx -> Message.tsx
export interface ChatMessage {
  id: string;
  role: MessageRole;
  parts: MessagePart[];
  timestamp: Date;
  // Fix: Added rawResponse and groundingUrls to ChatMessage for storing Gemini's full response and extracted URLs
  rawResponse?: import('@google/genai').GenerateContentResponse;
  groundingUrls?: GroundingUrl[];
}

export interface Conversation {
  id: string;
  title: string;
  history: ChatMessage[];
  timestamp: Date;
}

// Type for components like Conversation and MessageBubble if they expect flattened text content.
// This is distinct from ChatMessage which handles multimodal parts.
export interface DisplayMessage {
  id: string;
  sender: 'user' | 'ai'; // Represents who sent the message for display logic
  content: string; // Flattened text content
  timestamp: Date;
  groundingUrls?: GroundingUrl[]; // For search grounding
  isStreaming?: boolean; // Indicates if the message is still being streamed/typed
  // New: Include raw parts for richer display in Conversation component
  rawParts?: MessagePart[];
}

export interface NotificationProps {
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
}

// Extend the Window interface to include our custom properties
declare global {
  // Fix: Moved AIStudio interface definition inside the declare global block
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    showNotification: (message: string, type: 'success' | 'error' | 'warning' | 'info') => void;
    aistudio?: AIStudio;
    marked?: { parse: (markdown: string) => string }; // For markdown rendering
    // Fix: Add webkitAudioContext for broader compatibility
    webkitAudioContext?: typeof AudioContext;
  }
}

export type Language = 'ar' | 'en';

export type TranslatedString = {
  [key in Language]: string;
};

// Fix: Redundant type declaration moved to LanguageContext.tsx as its canonical definition
// export type Translator = (key: keyof typeof translations | TranslatedString, params?: Record<string, string | number>) => string;

export interface CountryOption {
  code: string;
  name: TranslatedString;
}

export interface IndicatorOption {
  code?: string; // World Bank code
  fredCode?: string; // FRED series ID
  name: TranslatedString;
  unit: TranslatedString;
}

export interface EconomicDataItem {
  date: string; // YYYY-MM-DD
  value: number | null;
}

export interface StandardEconomicDataItem { // Unified type for WB and FRED
  date: string; // YYYY-MM-DD
  value: number | null;
  source: string; // 'worldbank' or 'fred'
  countryCode?: string; // Optional for FRED
  countryName?: TranslatedString; // Optional for FRED
  indicatorCode: string; // WB code or FRED series ID
  indicatorName?: TranslatedString;
  unit?: TranslatedString;
  year: string; // YYYY
}

export interface UploadedFile {
  id: string;
  file: File;
  base64?: string; // Base64 encoded content
  uploadTime: Date;
  analyzed: boolean; // Has this file been sent to Gemini for analysis?
  isUploading?: boolean; // New property to indicate upload progress
  uploadProgress?: number; // New property for upload percentage
  error?: string; // New property for upload error message
  mimeType: string; // Storing mimeType for multimodal input
}

export type ChatModel = 'basic' | 'advanced' | 'strategic'; // Fix: Exported ChatModel for broader usage

export interface ModelConfig {
  name: TranslatedString;
  geminiModel: string;
  description: TranslatedString;
}

export interface ApiStatus {
  connected: boolean;
  message?: string;
}

export interface AllApiStatus {
  worldbank: ApiStatus;
  imf: ApiStatus;
  comtrade: ApiStatus;
  fred: ApiStatus; // Added FRED API status
}

export enum ToolType {
  ECONOMIC_ANALYSIS = 'economic_analysis',
  INVESTMENT_CONSULTATION = 'investment_consultation',
  FORECAST = 'forecast',
  STATISTICAL_TESTS = 'statistical_tests',
  VISUALIZATIONS = 'visualizations',
  SEARCH_EXTERNAL = 'search_external',
  EXPORT_CONVERSATION = 'export_conversation',
}

export interface ToolConfig {
  name: TranslatedString;
  icon: string;
  description: TranslatedString;
  type: ToolType;
}

export interface GroundingUrl {
  uri: string;
  title?: string;
}

export interface DataSourceInfo {
  name: TranslatedString;
  baseUrl: string;
  sourceId: string;
  indicators?: { [key: string]: IndicatorOption }; // For World Bank specific indicators
  apiKeyEnvVar?: string; // For APIs requiring an API key (e.g., FRED)
  format?: string;
  description: TranslatedString;
}

export interface FileTypeInfo {
  name: TranslatedString;
  icon: string;
  mimeTypes: string[];
}

export interface DataFetchOptions {
  dataSource: string;
  countryCode?: string;
  indicatorCode: string;
  startDate: string;
  endDate: string;
}

export type MessageSender = 'user' | 'ai'; // 'user' | 'ai' for display purposes
