// constants.ts


// Fix: Updated imports to use the newly defined types from './types'
import { DataSourceInfo, ModelConfig, ToolConfig, ToolType, FileTypeInfo, CountryOption, IndicatorOption, ChatModel } from './types';
import { COUNTRIES } from './countries';
import { INDICATORS } from './indicators';

export const REAL_DATA_SOURCES: { [key: string]: DataSourceInfo } = {
  worldbank: {
    name: { ar: 'البنك الدولي', en: 'World Bank' },
    baseUrl: "https://api.worldbank.org/v2/country/",
    sourceId: 'worldbank',
    indicators: {
      'NY.GDP.MKTP.CD': { name: { ar: 'الناتج المحلي الإجمالي', en: 'GDP' }, unit: { ar: 'دولار أمريكي', en: 'USD' } },
      'FP.CPI.TOTL.ZG': { name: { ar: 'التضخم (مؤشر أسعار المستهلك)', en: 'Inflation (CPI)' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } },
      'SL.UEM.TOTL.ZS': { name: { ar: 'معدل البطالة', en: 'Unemployment Rate' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } },
      'FR.INR.LNDP': { name: { ar: 'أسعار الفائدة', en: 'Interest Rates' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } },
      'NE.EXP.GNFS.CD': { name: { ar: 'الصادرات من السلع والخدمات', en: 'Exports of Goods and Services' }, unit: { ar: 'دولار أمريكي', en: 'USD' } },
      'NE.IMP.GNFS.CD': { name: { ar: 'الواردات من السلع والخدمات', en: 'Imports of Goods and Services' }, unit: { ar: 'دولار أمريكي', en: 'USD' } },
      'BN.CAB.XOKA.CD': { name: { ar: 'الحساب الجاري', en: 'Current Account Balance' }, unit: { ar: 'دولار أمريكي', en: 'USD' } },
      'GC.BAL.CASH.CD': { name: { ar: 'الرصيد المالي للحكومة', en: 'Government Cash Surplus/Deficit' }, unit: { ar: 'دولار أمريكي', en: 'USD' } },
      'NY.GNS.ICTR.ZS': { name: { ar: 'إجمالي الادخار الوطني', en: 'Gross National Savings' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } },
      'BX.KLT.DINV.CD.WD': { name: { ar: 'الاستثمار الأجنبي المباشر، صافي التدفقات', en: 'Foreign Direct Investment, net inflows' }, unit: { ar: 'دولار أمريكي', en: 'USD' } },
      'SP.POP.TOTL': { name: { ar: 'إجمالي السكان', en: 'Total Population' }, unit: { ar: 'أشخاص', en: 'Persons' } },
      'EG.GDP.PUSE.KO.PP.KD': { name: { ar: 'استهلاك الطاقة بالنسبة للناتج المحلي الإجمالي', en: 'Energy consumption per GDP' }, unit: { ar: 'كيلو جرام مكافئ نفط لكل 1000 دولار أمريكي', en: 'kg of oil equivalent per $1000 GDP' } },
      'SH.STA.SMSS.ZS': { name: { ar: 'انتشار نقص التغذية', en: 'Prevalence of Undernourishment' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } },
      'SE.SEC.CUAT.LO.ZS': { name: { ar: 'معدل إتمام المرحلة الثانوية', en: 'Lower Secondary Completion Rate' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } },
      'NV.AGR.TOTL.ZS': { name: { ar: 'القيمة المضافة للزراعة', en: 'Agriculture, forestry, and fishing, value added (% of GDP)' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } },
      'IC.BUS.EASE.XQ': { name: { ar: 'سهولة ممارسة الأعمال التجارية', en: 'Ease of doing business index' }, unit: { ar: 'الرتبة', en: 'Rank' } },
    },
    format: 'json',
    description: { ar: 'بيانات التنمية العالمية من البنك الدولي', en: 'Global development data from World Bank' },
  },
  imf: {
    name: { ar: 'صندوق النقد الدولي', en: 'IMF' },
    baseUrl: "https://dataservices.imf.org/REST/SDMX_JSON.svc",
    sourceId: 'imf',
    description: { ar: 'بيانات الاقتصاد الكلي', en: 'Macroeconomic data' },
  },
  comtrade: {
    name: { ar: 'UN Comtrade', en: 'UN Comtrade' },
    baseUrl: "https://comtradeapi.un.org/public/v1",
    sourceId: 'comtrade',
    description: { ar: 'بيانات التجارة الدولية', en: 'International trade data' },
  },
  fred: {
    name: { ar: 'نظام معلومات الاحتياطي الفيدرالي', en: 'FRED (Federal Reserve Economic Data)' },
    baseUrl: "https://api.stlouisfed.org/fred/series/observations",
    sourceId: 'fred',
    apiKeyEnvVar: 'FRED_API_KEY',
    description: { ar: 'البيانات الاقتصادية من بنك الاحتياطي الفيدرالي في سانت لويس', en: 'Economic data from the St. Louis Federal Reserve Bank' },
  },
};

export const SUPPORTED_FILE_TYPES: { [key: string]: FileTypeInfo } = {
  'xlsx': { name: { ar: 'ملف إكسل', en: 'Excel File' }, icon: 'fa-file-excel', mimeTypes: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel'] },
  'xls': { name: { ar: 'ملف إكسل', en: 'Excel File' }, icon: 'fa-file-excel', mimeTypes: ['application/vnd.ms-excel'] },
  'csv': { name: { ar: 'ملف CSV', en: 'CSV File' }, icon: 'fa-file-csv', mimeTypes: ['text/csv'] },
  'pdf': { name: { ar: 'ملف PDF', en: 'PDF Document' }, icon: 'fa-file-pdf', mimeTypes: ['application/pdf'] },
  'jpg': { name: { ar: 'صورة JPG', en: 'JPG Image' }, icon: 'fa-file-image', mimeTypes: ['image/jpeg'] },
  'jpeg': { name: { ar: 'صورة JPEG', en: 'JPEG Image' }, icon: 'fa-file-image', mimeTypes: ['image/jpeg'] },
  'png': { name: { ar: 'صورة PNG', en: 'PNG Image' }, icon: 'fa-file-image', mimeTypes: ['image/png'] },
  'txt': { name: { ar: 'ملف نصي', en: 'Text File' }, icon: 'fa-file-alt', mimeTypes: ['text/plain'] },
};

export const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10MB

export { COUNTRIES };
export { INDICATORS };

export const MODEL_CONFIGS: { [key in ChatModel]: ModelConfig } = { // Fix: Use ChatModel here
  basic: {
    name: { ar: 'النموذج الأساسي - تحليل اقتصادي', en: 'Basic Model - Economic Analysis' },
    geminiModel: 'gemini-2.5-flash',
    description: { ar: 'مناسب للتحليل الاقتصادي العام والإجابات السريعة.', en: 'Suitable for general economic analysis and quick answers.' },
  },
  advanced: {
    name: { ar: 'النموذج المتقدم - تنبؤات', en: 'Advanced Model - Forecasts' },
    geminiModel: 'gemini-2.5-pro',
    description: { ar: 'مصمم للتنبؤات والتحليلات المتقدمة التي تتطلب فهمًا أعمق للبيانات.', en: 'Designed for advanced forecasts and analyses requiring deeper data understanding.' },
  },
  strategic: {
    name: { ar: 'النموذج الاستراتيجي - تحليل طويل المدى', en: 'Strategic Model - Long-term Analysis' },
    geminiModel: 'gemini-2.5-pro',
    description: { ar: 'مثالي للتحليل الاقتصادي طويل المدى وتقديم الاستشارات الاستراتيجية.', en: 'Ideal for long-term economic analysis and strategic consulting.' },
  },
};

export const ANALYSIS_TOOLS: ToolConfig[] = [
  {
    name: { ar: 'تحليل اقتصادي سريع', en: 'Quick Economic Analysis' },
    icon: 'fas fa-chart-line',
    description: { ar: 'تحليل سريع للوضع الاقتصادي الحالي.', en: 'Quick analysis of the current economic situation.' },
    type: ToolType.ECONOMIC_ANALYSIS,
  },
  {
    name: { ar: 'استشارة استثمارية', en: 'Investment Consultation' },
    icon: 'fas fa-coins',
    description: { ar: 'توصيات استثمارية بناءً على الظروف الحالية.', en: 'Investment recommendations based on current conditions.' },
    type: ToolType.INVESTMENT_CONSULTATION,
  },
  {
    name: { ar: 'توقعات مستقبلية', en: 'Future Forecasts' },
    icon: 'fas fa-crystal-ball',
    description: { ar: 'توقعات للاتجاهات الاقتصادية والأسواق.', en: 'Forecasts for economic trends and markets.' },
    type: ToolType.FORECAST,
  },
  {
    name: { ar: 'اختبارات إحصائية', en: 'Statistical Tests' },
    icon: 'fas fa-chart-bar',
    description: { ar: 'إجراء اختبارات إحصائية متقدمة على البيانات.', en: 'Perform advanced statistical tests on data.' },
    type: ToolType.STATISTICAL_TESTS,
  },
  {
    name: { ar: 'تصورات البيانات', en: 'Data Visualizations' },
    icon: 'fas fa-chart-area',
    description: { ar: 'الحصول على وصف لتصورات البيانات الفعالة بناءً على السياق المقدم.', en: 'Get descriptions of effective data visualizations based on the provided context.' },
    type: ToolType.VISUALIZATIONS,
  },
  {
    name: { ar: 'بحث في المصادر الخارجية', en: 'Search External Sources' },
    icon: 'fas fa-search',
    description: { ar: 'البحث عن معلومات إضافية باستخدام Google Search.', en: 'Search for additional information using Google Search.' },
    type: ToolType.SEARCH_EXTERNAL,
  },
  {
    name: { ar: 'تصدير المحادثة', en: 'Export Conversation' },
    icon: 'fas fa-download',
    description: { ar: 'حفظ سجل المحادثة كنص.', en: 'Save conversation history as text.' },
    type: ToolType.EXPORT_CONVERSATION,
  },
];

export const INTELLECTUAL_PROPERTY_NOTICE = "copyright";