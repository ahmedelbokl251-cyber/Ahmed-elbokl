import React, { createContext, useContext, useState, ReactNode, useCallback, useEffect } from 'react';
import { translations } from './translations'; // Relative import for translations.ts
// Fix: Updated imports to use the newly defined Language and TranslatedString from './types'
import { Language, TranslatedString } from './types'; // Relative import for types.ts

// Define the Translator type here as its canonical definition
export type Translator = (key: keyof typeof translations | TranslatedString, params?: Record<string, string | number>) => string;

// Define the shape of our LanguageContext
interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translator; // Use the exported Translator type
}

// Create the context with a default undefined value
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// LanguageProvider component to wrap our app
export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    // Attempt to get language from local storage, default to 'ar'
    return (localStorage.getItem('appLanguage') as Language) || 'ar';
  });

  // Save language to local storage whenever it changes
  // Also update document direction for RTL/LTR
  useEffect(() => {
    localStorage.setItem('appLanguage', language);
    document.documentElement.setAttribute('lang', language);
    document.documentElement.setAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
  }, [language]);

  // Translation function
  const t: Translator = useCallback((key: keyof typeof translations | TranslatedString, params?: Record<string, string | number>): string => {
    let text: string | undefined;

    if (typeof key === 'object' && 'ar' in key && 'en' in key) {
      // If key is a TranslatedString object itself
      text = key[language];
    } else {
      // If key is a string (keyof typeof translations)
      text = translations[key as keyof typeof translations]?.[language];
    }
    
    // Fallback to English if translation not found for current language or key type
    if (!text && typeof key === 'object' && 'en' in key) {
      text = key['en'];
    } else if (!text) {
      text = translations[key as keyof typeof translations]?.['en'] || (key as string); // Fallback to key itself if no English translation either
    }

    if (params && text) { // Ensure text is defined before replacing
      for (const p in params) {
        text = text.replace(new RegExp(`\\{${p}\\}`, 'g'), String(params[p]));
      }
    }
    return text || (key as string); // Final fallback just in case
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook to use the language context
export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};