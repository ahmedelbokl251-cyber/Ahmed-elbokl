import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  MessageRole,
  UploadedFile,
  AllApiStatus,
  StandardEconomicDataItem, // Changed from WorldBankDataItem
  ChatModel,
  ToolType,
  GroundingUrl,
  Language,
  TranslatedString,
  NotificationProps,
  DataSourceInfo,
  ChatMessage, // Explicitly import ChatMessage
  TextPart, // Import TextPart for creating message parts
  DisplayMessage, // Import DisplayMessage for Conversation component
  MessagePart, // Import MessagePart
  ImagePart, // Import ImagePart
  Conversation as ConversationType,
  ChartPart, // Import ChartPart
  DataFetchOptions, // Fix: Import DataFetchOptions
  ApiStatus, // Fix: Import ApiStatus
} from './types';
// Fix: Import Translator from LanguageContext
import { Translator, useLanguage } from './LanguageContext';
// Fix: Import Type and FunctionResponse from @google/genai
import { GoogleGenAI, GenerateContentResponse, GenerateContentParameters, FunctionCall, Modality, Tool, FunctionDeclaration, Part, FunctionResponse, Type, LiveServerMessage } from "@google/genai";

import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Conversation from './components/Conversation';
import MessageInput from './components/MessageInput';
import Notification from './components/Notification';
import Footer from './components/Footer';
import {
  // Fix: Added missing exports from services/geminiService.ts
  generateContentStream,
  analyzeFilesWithGemini,
  checkWorldBankAPI,
  checkComtradeAPI,
  checkIMFAPI,
  checkFREDAPI, // Added FRED API check
  fetchWorldBankData,
  fetchFREDData, // Added FRED data fetch
  fetchEconomicDataFunctionDeclaration,
  decode,
  decodeAudioData,
  encode,
  createBlob,
} from './services/geminiService';
import { fileToBase64 } from './utils/converters';
import { MODEL_CONFIGS, REAL_DATA_SOURCES, MAX_FILE_SIZE_BYTES, SUPPORTED_FILE_TYPES, ANALYSIS_TOOLS } from './constants';
// FIX: Added missing import for 'translations' to resolve 'Cannot find name' error.
import { translations } from './translations';
import {
  calculateRealStatistics,
  generateRealInsight,
  generateRealRecommendation,
  getCountryName,
  getGroundingUrls,
  stripHtml,
  getIndicatorName,
  getUnitName,
  getTodayDateString,
  getFiveYearsAgoDateString,
} from './utils/helpers';
// Fix: Imported formatNumber from formatters.ts
import { formatNumber } from './utils/formatters';
// The generateRealDataAnalysis is only used in EconomicDataFetcher
import { generateRealDataAnalysis } from './services/economicDataService';


const App: React.FC = () => {
  const { t, language } = useLanguage();

  // --- State Variables ---
  const [allConversations, setAllConversations] = useState<Record<string, ConversationType>>({});
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [fetchedEconomicData, setFetchedEconomicData] = useState<StandardEconomicDataItem[] | null>(null); // Changed from WorldBankDataItem
  const [fetchedDataCountryCode, setFetchedDataCountryCode] = useState<string | null>(null);
  const [fetchedDataIndicatorCode, setFetchedDataIndicatorCode] = useState<string | null>(null);
  const [fetchedDataSourceId, setFetchedDataSourceId] = useState<string | null>(null); // New state for data source
  const [currentModel, setCurrentModel] = useState<ChatModel>('basic');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [apiStatus, setApiStatus] = useState<AllApiStatus>({
    worldbank: { connected: false },
    imf: { connected: false },
    comtrade: { connected: false },
    fred: { connected: false }, // Added FRED API status
  });
  const [isVoiceRecording, setIsVoiceRecording] = useState<boolean>(false);

  // --- Ref Variables for Live API ---
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null); // This ref is not used in the provided code, but kept for context
  const audioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const audioSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const audioPlayingSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set<AudioBufferSourceNode>());

  // --- Derived State ---
  const conversationHistory = currentConversationId ? allConversations[currentConversationId]?.history || [] : [];

  // --- Helper Callbacks (ordered by dependency) ---

  // Fix: Manual implementation of findLastIndex for ChatMessage[]
  const findLastIndex = useCallback((arr: ChatMessage[], predicate: (value: ChatMessage, index: number, obj: ChatMessage[]) => unknown) => {
    for (let i = arr.length - 1; i >= 0; i--) {
      if (predicate(arr[i], i, arr)) {
        return i;
      }
    }
    return -1;
  }, []);

  // Fix: Updated signature to accept `MessagePart[]` for internal messages,
  // in addition to `string` or Gemini's `Part[]`.
  const addMessage = useCallback((role: MessageRole, content: string | Part[] | MessagePart[], rawResponse?: GenerateContentResponse, groundingUrls?: GroundingUrl[], isStreaming: boolean = false) => {
    if (!currentConversationId) return;

    setAllConversations(prev => {
        const currentConversation = prev[currentConversationId];
        if (!currentConversation) return prev;

        const history = currentConversation.history;

        // Helper to convert Part[] (from Gemini) to MessagePart[] (our internal type) for storage
        const convertToMessagePartsFromGemini = (partsFromGemini: Part[]): MessagePart[] => {
            return partsFromGemini.flatMap(part => {
                if ('text' in part && part.text !== undefined) {
                    return { type: 'text', content: part.text, isStreaming } as TextPart;
                }
                if ('inlineData' in part && part.inlineData !== undefined) {
                    return { type: 'image', content: part.inlineData.data, mimeType: part.inlineData.mimeType } as ImagePart;
                }
                return []; // Ignore other types from Gemini Part[] that are not TextPart or ImagePart
            });
        };

        let newParts: MessagePart[] = [];
        if (typeof content === 'string') {
            newParts = [{ type: 'text', content, isStreaming } as TextPart];
        } else if (Array.isArray(content)) {
            // Check if content is already MessagePart[] (our internal type)
            if (content.length > 0 && 'type' in content[0] && (content[0] as MessagePart).type !== undefined) {
                newParts = content as MessagePart[];
            } else {
                // Assume it's Gemini's Part[] and convert
                newParts = convertToMessagePartsFromGemini(content as Part[]);
            }
        } else {
            console.error("Invalid content type for addMessage:", content);
            return prev;
        }

        const newMessage: ChatMessage = { id: `${role}-${Date.now()}`, role, parts: newParts, timestamp: new Date(), rawResponse, groundingUrls };
        const updatedHistory = [...history, newMessage];
        const updatedConversation = { ...currentConversation, history: updatedHistory, timestamp: new Date() };
        return { ...prev, [currentConversationId]: updatedConversation };
    });
}, [currentConversationId, setAllConversations]);

  // Fix: Updated signature to accept `MessagePart[]` for internal messages,
  // in addition to `string` or Gemini's `Part[]`.
  const updateLastStreamingMessage = useCallback((newContent: string | Part[] | MessagePart[], newRawResponse?: GenerateContentResponse, newGroundingUrls?: GroundingUrl[], isStreaming: boolean = true) => {
    if (!currentConversationId) return;

    setAllConversations(prev => {
        const currentConversation = prev[currentConversationId];
        if (!currentConversation) return prev;

        const history = currentConversation.history;

        const convertToMessagePartsFromGemini = (partsFromGemini: Part[]): MessagePart[] => {
            return partsFromGemini.flatMap(part => {
                if ('text' in part && part.text !== undefined) { return { type: 'text', content: part.text, isStreaming } as TextPart; }
                if ('inlineData' in part && part.inlineData !== undefined) { return { type: 'image', content: part.inlineData.data, mimeType: part.inlineData.mimeType } as ImagePart; }
                return [];
            });
        };

        const lastModelMessageIndex = findLastIndex(history, msg => msg.role === MessageRole.MODEL);

        if (lastModelMessageIndex === -1) {
            // If no previous model message, add a new one
            let newParts: MessagePart[] = [];
            if (typeof newContent === 'string') { newParts = [{ type: 'text', content: newContent, isStreaming } as TextPart]; }
            else if (Array.isArray(newContent)) {
                if (newContent.length > 0 && 'type' in newContent[0] && (newContent[0] as MessagePart).type !== undefined) {
                    newParts = newContent as MessagePart[];
                } else {
                    newParts = convertToMessagePartsFromGemini(newContent as Part[]);
                }
            }
            const newMessage: ChatMessage = { id: `ai-${Date.now()}`, role: MessageRole.MODEL, parts: newParts, timestamp: new Date(), rawResponse: newRawResponse, groundingUrls: newGroundingUrls };
            const updatedHistory = [...history, newMessage];
            const updatedConversation = { ...currentConversation, history: updatedHistory };
            return { ...prev, [currentConversationId]: updatedConversation };
        }

        const lastModelMessage = { ...history[lastModelMessageIndex] };
        let updatedParts: MessagePart[] = [...lastModelMessage.parts]; // Start with existing parts

        if (typeof newContent === 'string') {
            const existingTextPartIndex = updatedParts.findIndex(p => p.type === 'text' && (p as TextPart).isStreaming);
            if (existingTextPartIndex !== -1) {
                // If an existing streaming text part is found, append to its content
                updatedParts = updatedParts.map((p, index) =>
                    index === existingTextPartIndex ? { ...p, content: (p as TextPart).content + newContent, isStreaming } : p
                );
            } else {
                // Otherwise, add a new streaming text part
                updatedParts.push({ type: 'text', content: newContent, isStreaming } as TextPart);
            }
        } else if (Array.isArray(newContent)) {
            // If newContent is an array, replace or append as appropriate
            if (newContent.length > 0 && 'type' in newContent[0] && (newContent[0] as MessagePart).type !== undefined) {
                // If it's already MessagePart[], assume it's a full replacement for content
                updatedParts = newContent as MessagePart[];
            } else {
                // Assume it's Gemini's Part[] and convert, then append/replace as needed.
                // For streaming, typically only text chunks arrive, so this might need refinement
                // if other parts stream. For now, it replaces the content if multimodal parts are received.
                updatedParts = convertToMessagePartsFromGemini(newContent as Part[]);
            }
        }

        const updatedMessage: ChatMessage = { ...lastModelMessage, parts: updatedParts, rawResponse: newRawResponse || lastModelMessage.rawResponse, groundingUrls: newGroundingUrls || lastModelMessage.groundingUrls };
        const updatedHistory = [...history.slice(0, lastModelMessageIndex), updatedMessage, ...history.slice(lastModelMessageIndex + 1)];
        const updatedConversation = { ...currentConversation, history: updatedHistory };
        return { ...prev, [currentConversationId]: updatedConversation };
    });
}, [currentConversationId, findLastIndex, setAllConversations]);

  // Moved onRenameConversation definition here
  const onRenameConversation = useCallback((id: string, newTitle: string) => {
    setAllConversations(prev => {
      const updated = { ...prev };
      if (updated[id]) {
        updated[id] = { ...updated[id], title: newTitle };
      }
      return updated;
    });
    window.showNotification(t('chatRenamed'), 'success');
  }, [setAllConversations, t]);


  const getGeminiConfig = useCallback((modelName: string) => {
    const config: GenerateContentParameters['config'] = {};
    if (modelName.includes('gemini-2.5')) {
      if (modelName === 'gemini-2.5-pro') {
        config.thinkingConfig = { thinkingBudget: 32768 };
      } else if (modelName.includes('gemini-2.5-flash')) {
        config.thinkingConfig = { thinkingBudget: 24576 };
      }
    }
    return config;
  }, []);

  // Fix: Moved processGeminiResponse declaration to resolve "used before declaration" errors.
  const processGeminiResponse = useCallback(async (
    responseGenerator: AsyncGenerator<GenerateContentResponse>,
    isFirstCall: boolean,
    initialRawResponse?: GenerateContentResponse,
    currentPrompt?: string,
    // Fix: Removed historyForChainedCalls as it's not directly used to build the content inside this function.
    // The caller (handleFunctionCall or handleSendMessage) should assemble the full contents.
  ): Promise<{ type: 'text' | 'functionCall'; content?: string; rawResponse?: GenerateContentResponse; groundingUrls?: GroundingUrl[]; calls?: FunctionCall[]; currentPrompt?: string }> => {
    setIsProcessing(true);
    let fullResponseContent = '';
    let accumulatedRawResponse: GenerateContentResponse | undefined = initialRawResponse;
    let currentGroundingUrls: GroundingUrl[] | undefined;
    let functionCalls: FunctionCall[] = [];

    // Add an empty, streaming message placeholder
    if (isFirstCall) {
      addMessage(MessageRole.MODEL, '', undefined, undefined, true);
    }

    try {
      for await (const chunk of responseGenerator) {
        // Accumulate raw response
        if (!accumulatedRawResponse) {
          accumulatedRawResponse = chunk;
        } else {
          // Merge parts from current chunk into accumulatedRawResponse
          const newParts = chunk.candidates?.[0]?.content?.parts || [];
          if (newParts.length > 0) {
            if (!accumulatedRawResponse.candidates?.[0]?.content?.parts) {
              accumulatedRawResponse.candidates = [{ ...chunk.candidates?.[0], content: { parts: newParts } }];
            } else {
              accumulatedRawResponse.candidates[0].content.parts.push(...newParts);
            }
          }
        }

        // Extract text content
        const chunkText = chunk.text;
        if (chunkText) {
          fullResponseContent += chunkText;
        }

        // Fix: functionCalls are directly on the response chunk, not nested under candidates.
        if (chunk.functionCalls) {
            functionCalls.push(...chunk.functionCalls);
        }

        // Extract grounding URLs from each chunk
        const chunkGroundingUrls = getGroundingUrls(chunk);
        if (chunkGroundingUrls.length > 0) {
          if (!currentGroundingUrls) {
            currentGroundingUrls = [];
          }
          currentGroundingUrls.push(...chunkGroundingUrls);
        }
        
        // Update the last message with streaming content
        if (fullResponseContent || (currentGroundingUrls && currentGroundingUrls.length > 0)) {
            updateLastStreamingMessage(fullResponseContent, accumulatedRawResponse, currentGroundingUrls, true);
        }
      }

      // After streaming, update the last message to mark it as not streaming
      updateLastStreamingMessage(fullResponseContent, accumulatedRawResponse, currentGroundingUrls, false);

      if (functionCalls.length > 0) {
        // For function calls, return the function call type and details
        return { type: 'functionCall', calls: functionCalls, rawResponse: accumulatedRawResponse, groundingUrls: currentGroundingUrls, currentPrompt };
      } else {
        // For text-only responses, return the full content
        return { type: 'text', content: fullResponseContent, rawResponse: accumulatedRawResponse, groundingUrls: currentGroundingUrls, currentPrompt };
      }
    } catch (error: any) { // Fix: Catch clause variable type annotation changed to 'any'
      console.error("Error processing Gemini stream:", error);
      window.showNotification(t('geminiApiError', { message: error.message }), 'error');
      // If an error occurs during streaming, ensure the last message is finalized without streaming
      updateLastStreamingMessage(fullResponseContent + `\n\n**${t('anErrorOccurred', { message: error.message })}**`, accumulatedRawResponse, currentGroundingUrls, false);
      return { type: 'text', content: fullResponseContent, rawResponse: accumulatedRawResponse, currentPrompt };
    } finally {
      setIsProcessing(false);
    }
  }, [addMessage, updateLastStreamingMessage, setIsProcessing, t]);


  // Initial welcome message (now dynamically translated)
  const initialAiWelcomeMessage = useCallback((): ChatMessage => ({ // Fix: return type to ChatMessage
    id: `ai-welcome-${Date.now()}`,
    role: MessageRole.MODEL,
    parts: [{ type: 'text', content: t('welcomeMessage', {
      worldBankName: REAL_DATA_SOURCES.worldbank.name[language],
      comtradeName: REAL_DATA_SOURCES.comtrade.name[language],
      imfName: REAL_DATA_SOURCES.imf.name[language],
      fredName: REAL_DATA_SOURCES.fred.name[language], // Added FRED name
    }) } as TextPart], // Fix: Explicitly cast to TextPart
    timestamp: new Date(),
  }), [t, language]);

  const generateConversationTitle = useCallback(async (initialPrompt: string) => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const response = await ai.models.generateContent({
        model: MODEL_CONFIGS[currentModel].geminiModel,
        contents: [{ role: 'user', parts: [{ text: t('generateTitlePrompt', { prompt: initialPrompt }) }] }],
        config: {
          maxOutputTokens: 20, // Keep title short
          temperature: 0.5,
        },
      });
      const title = response.text.trim().replace(/['"`.]/g, ''); // Clean up title
      return title.length > 0 ? title : t('untitledChat');
    } catch (error: any) { // Fix: Corrected 'error' to 'any'
      console.error('Failed to generate conversation title:', error);
      return t('untitledChat');
    }
  }, [t, currentModel]); // Fix: Added currentModel to dependencies


  const createNewConversation = useCallback(async (initialPrompt?: string) => {
    const newId = `conv-${Date.now()}`;
    let title = t('untitledChat');
    if (initialPrompt) {
        title = await generateConversationTitle(initialPrompt);
    }
    const newConversation: ConversationType = {
      id: newId,
      title: title,
      history: [initialAiWelcomeMessage()],
      timestamp: new Date(),
    };
    setAllConversations(prev => ({...prev, [newId]: newConversation}));
    setCurrentConversationId(newId);
    return newId;
  }, [t, generateConversationTitle, initialAiWelcomeMessage, setAllConversations, setCurrentConversationId]);


  const handleFunctionCall = useCallback(async (functionCalls: FunctionCall[], initialPrompt: string, historyForChainedCalls: ChatMessage[]) => {
    setIsProcessing(true);
    let toolResponseContent = '';
    const ai = new GoogleGenAI({apiKey: process.env.API_KEY as string});

    for (const functionCall of functionCalls) {
      addMessage(MessageRole.TOOL, t('executingFunction', { name: functionCall.name }));
      console.log('Executing function:', functionCall);

      try {
        if (functionCall.name === fetchEconomicDataFunctionDeclaration.name) {
          // Fix: Explicitly cast args to DataFetchOptions using unknown intermediate
          const args = functionCall.args as unknown as DataFetchOptions;
          let fetchedData: StandardEconomicDataItem[] = [];

          if (args.dataSource === REAL_DATA_SOURCES.worldbank.sourceId) {
            // World Bank requires countryCode
            if (!args.countryCode) {
                throw new Error(t('pleaseSelectCountry'));
            }
            fetchedData = await fetchWorldBankData(args.countryCode, args.indicatorCode, args.startDate, args.endDate, t, language);
          } else if (args.dataSource === REAL_DATA_SOURCES.fred.sourceId) {
            // FRED does not always require countryCode, but indicatorCode (series_id) is always required
            fetchedData = await fetchFREDData(args.indicatorCode, args.startDate, args.endDate, t, language);
          } else {
            throw new Error(t('unknownDataSource', { dataSource: args.dataSource }));
          }

          setFetchedEconomicData(fetchedData);
          setFetchedDataCountryCode(args.countryCode || null);
          setFetchedDataIndicatorCode(args.indicatorCode);
          setFetchedDataSourceId(args.dataSource); // Store the data source ID

          if (fetchedData.length > 0) {
            toolResponseContent = generateRealDataAnalysis(fetchedData, language, t, args);
            window.showNotification(t('functionExecutedSuccess', { name: functionCall.name }), 'success');
          } else {
            toolResponseContent = t('noDataFoundForAnalysis');
            window.showNotification(t('noDataFound'), 'warning');
          }

          // Generate a chart part
          const countryName = getCountryName(args.countryCode || '', language, t) || t('notApplicable');
          const indicatorName = getIndicatorName(args.indicatorCode, args.dataSource, language, t) || args.indicatorCode;
          const unit = getUnitName(args.indicatorCode, args.dataSource, language, t) || '';
          const chartPart: ChartPart = {
            type: 'chart',
            chartType: 'line',
            title: t('economicDataChartTitle', { indicator: indicatorName, country: countryName, period: `${args.startDate.substring(0,4)}-${args.endDate.substring(0,4)}`}),
            data: {
              labels: fetchedData.map(d => d.year),
              datasets: [{
                label: `${indicatorName} (${unit})`,
                data: fetchedData.map(d => d.value),
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.5)',
                tension: 0.1,
              }],
            },
            options: {
              scales: {
                y: {
                  beginAtZero: false,
                  title: {
                    display: true,
                    text: unit,
                  },
                },
                x: {
                    title: {
                        display: true,
                        text: t('yearCol'),
                    },
                },
              },
            },
          };
          // Add the chart message directly
          addMessage(MessageRole.MODEL, [chartPart]);


        } else {
          // Handle other function calls if they exist
          toolResponseContent = t('unsupportedToolCall', { name: functionCall.name });
          window.showNotification(toolResponseContent, 'error');
        }

        // Construct the full history including the tool call and tool response
        const newHistoryPartForGemini: Part[] = [
            { functionCall: functionCall }, // The model's function call
            { functionResponse: { name: functionCall.name, response: { result: toolResponseContent } } } // Our response to the function call
        ];

        // Convert ChatMessage[] history to Content[] for Gemini
        // Fix: `flatMap` should return `Content` objects directly, not arrays of `Part` objects.
        const currentContentsForChaining: import('@google/genai').Content[] = historyForChainedCalls.flatMap(chatMsg => {
            if (chatMsg.id.startsWith('ai-welcome')) {
                return [];
            }
            const role = chatMsg.role === MessageRole.USER ? 'user' : 'model';
            const parts: Part[] = chatMsg.parts.flatMap(part => {
                if (part.type === 'text') {
                    return { text: (part as TextPart).content }; // Fix: Use part.content here
                }
                if (part.type === 'image') {
                    return { inlineData: { data: part.content, mimeType: part.mimeType } }; // Return single Part
                }
                return []; // Ignore ChartPart and other custom parts for Gemini history
            });
            return { role, parts }; // Return a Content object
        });
        
        // Add the new function call/response to the current contents
        // This is a Content object with role 'tool' which contains functionCall/functionResponse parts
        currentContentsForChaining.push({ role: 'tool', parts: newHistoryPartForGemini });
        
        // Continue the conversation with the tool response
        const responseGenerator = await ai.models.generateContentStream({ // Fix: Added 'await'
            model: MODEL_CONFIGS[currentModel].geminiModel,
            contents: currentContentsForChaining,
            config: { // Fix: tools moved inside config
              tools: [{ functionDeclarations: [fetchEconomicDataFunctionDeclaration] }],
              ...getGeminiConfig(MODEL_CONFIGS[currentModel].geminiModel),
            },
        });

        const geminiFollowUp = await processGeminiResponse(responseGenerator, false, undefined, initialPrompt);
        // toolResponseContent = geminiFollowUp.content || ''; // Update with Gemini's new response

        if (geminiFollowUp.type === 'functionCall' && geminiFollowUp.calls) {
            console.log("Chained function call detected:", geminiFollowUp.calls);
            // Recursively handle chained function calls
            // Pass the updated history for the recursive call
            await handleFunctionCall(geminiFollowUp.calls, initialPrompt, conversationHistory); // Pass original history for recursion
        }

      } catch (error: any) {
        console.error('Error in function call:', error);
        toolResponseContent = t('functionExecutionError', { name: functionCall.name, message: error.message });
        window.showNotification(toolResponseContent, 'error');
        addMessage(MessageRole.MODEL, toolResponseContent);
      }
    }
    setIsProcessing(false);
  }, [addMessage, updateLastStreamingMessage, t, language, setFetchedEconomicData, setFetchedDataCountryCode, setFetchedDataIndicatorCode, setFetchedDataSourceId, getGeminiConfig, currentModel, processGeminiResponse, conversationHistory, setIsProcessing]);

  const handleSendMessage = useCallback(async (message: string, currentContextHistory: ChatMessage[] = conversationHistory) => {
    if (isProcessing) return;

    if (!process.env.API_KEY) {
      window.showNotification(t('apiKeyError'), 'error');
      return;
    }

    // Generate title if it's a new chat (only initial welcome message exists) and there's a user prompt
    if (currentConversationId && allConversations[currentConversationId]?.history.length === 1 && allConversations[currentConversationId]?.history[0].id.startsWith('ai-welcome')) {
        const newTitle = await generateConversationTitle(message);
        setAllConversations(prev => {
            const updated = { ...prev };
            if (updated[currentConversationId]) {
                updated[currentConversationId] = { ...updated[currentConversationId], title: newTitle };
            }
            return updated;
        });
    }

    addMessage(MessageRole.USER, message);
    setIsProcessing(true);

    try {
      if (window.aistudio && !(await window.aistudio.hasSelectedApiKey())) {
        window.showNotification(t('apiKeyError'), 'warning');
        await window.aistudio.openSelectKey();
        setIsProcessing(false);
        return;
      }

      const ai = new GoogleGenAI({apiKey: process.env.API_KEY as string});

      // Prepare contents for Gemini API, converting our ChatMessage to Gemini's Content structure
      // Fix: The `contents` array for `generateContentStream` expects an array of `Content` objects.
      // Each `Content` object must have a `role` and `parts: Part[]`.
      const contents: import('@google/genai').Content[] = currentContextHistory.flatMap(chatMsg => {
        // Skip the initial welcome message from the actual Gemini history
        if (chatMsg.id.startsWith('ai-welcome')) {
          return [];
        }

        const role = chatMsg.role === MessageRole.USER ? 'user' : 'model';
        const parts: Part[] = chatMsg.parts.flatMap(part => {
          if (part.type === 'text') {
            return { text: part.content }; // Return single Part
          }
          if (part.type === 'image') {
            return { inlineData: { data: part.content, mimeType: part.mimeType } }; // Return single Part
          }
          return []; // Ignore ChartPart for Gemini history
        });
        return { role, parts }; // Return a Content object
      });

      // Add the current user message to the contents
      contents.push({ role: 'user', parts: [{ text: message }] });

      const modelName = MODEL_CONFIGS[currentModel].geminiModel;
      const config = getGeminiConfig(modelName);

      const responseGenerator = await ai.models.generateContentStream({ // Fix: Added 'await'
        model: modelName,
        contents,
        config: { // Fix: tools moved inside config
          tools: [{ functionDeclarations: [fetchEconomicDataFunctionDeclaration] }],
          ...config,
        },
      });

      const processedResponse = await processGeminiResponse(responseGenerator, true, undefined, message); // Pass message as currentPrompt
      
      if (processedResponse.type === 'functionCall' && processedResponse.calls) {
        await handleFunctionCall(processedResponse.calls, message, conversationHistory);
      }
    } catch (error: any) {
      console.error('Error sending message:', error);
      window.showNotification(t('anErrorOccurred', { message: error.message }), 'error');
      // If error, add message about failure and mark last streaming message as done
      updateLastStreamingMessage(t('anErrorOccurred', { message: error.message }), undefined, undefined, false);
    } finally {
      setIsProcessing(false);
    }
  }, [isProcessing, addMessage, updateLastStreamingMessage, t, currentConversationId, allConversations, generateConversationTitle, setAllConversations, setIsProcessing, getGeminiConfig, currentModel, processGeminiResponse, handleFunctionCall, conversationHistory]);

  const handleDataFetch = useCallback((data: StandardEconomicDataItem[] | null, countryCode: string, indicatorCode: string, dataSource: string) => {
    setFetchedEconomicData(data);
    setFetchedDataCountryCode(countryCode);
    setFetchedDataIndicatorCode(indicatorCode);
    setFetchedDataSourceId(dataSource);
  }, [setFetchedEconomicData, setFetchedDataCountryCode, setFetchedDataIndicatorCode, setFetchedDataSourceId]);

  const handleAnalyzeFiles = useCallback(async () => {
    if (uploadedFiles.filter(f => !f.error && !f.isUploading).length === 0) {
      window.showNotification(t('noFilesToAnalyze'), 'warning');
      return;
    }
    setIsProcessing(true);
    addMessage(MessageRole.MODEL, t('analyzingFiles'));

    try {
      if (window.aistudio && !(await window.aistudio.hasSelectedApiKey())) {
        window.showNotification(t('apiKeyError'), 'warning');
        await window.aistudio.openSelectKey();
        setIsProcessing(false);
        return;
      }

      const ai = new GoogleGenAI({apiKey: process.env.API_KEY as string});
      const modelName = MODEL_CONFIGS[currentModel].geminiModel;
      const config = getGeminiConfig(modelName);

      const validFiles = uploadedFiles.filter(f => f.base64 && !f.error);
      const fileNames = validFiles.map(f => f.file.name).join(', ');
      const prompt = t('fileAnalysisPrompt', { numberOfFiles: validFiles.length, fileNames: fileNames, language: t('langCode') });

      const responseGenerator = await analyzeFilesWithGemini(ai, prompt, validFiles, modelName, t, language); // Fix: Added 'await'
      const processedResponse = await processGeminiResponse(responseGenerator, true); // First call, so true

      if (processedResponse.type === 'functionCall' && processedResponse.calls) {
        await handleFunctionCall(processedResponse.calls, prompt, conversationHistory);
      } else {
        window.showNotification(t('filesAnalyzedSuccess'), 'success');
        setUploadedFiles(prev => prev.map(f => ({ ...f, analyzed: true })));
      }
    } catch (error: any) {
      console.error('Error analyzing files:', error);
      window.showNotification(t('failedToAnalyzeFiles', { message: error.message }), 'error');
    } finally {
      setIsProcessing(false);
    }
  }, [uploadedFiles, isProcessing, addMessage, setUploadedFiles, t, language, currentModel, getGeminiConfig, processGeminiResponse, handleFunctionCall, conversationHistory, setIsProcessing]);

  const handleToolClick = useCallback(async (toolType: ToolType) => {
    if (isProcessing) return;

    if (!process.env.API_KEY) {
      window.showNotification(t('apiKeyError'), 'error');
      return;
    }

    let prompt = '';
    let aiMessage = '';
    const currentContextHistory = conversationHistory;

    // Helper to get conversation context
    // Fix: Explicitly return `Content[]`
    const getConversationContext = (): import('@google/genai').Content[] => {
        // Exclude initial welcome message for model context
        const relevantHistory = currentContextHistory.filter(msg => !msg.id.startsWith('ai-welcome'));
        return relevantHistory.flatMap(chatMsg => {
            const role = chatMsg.role === MessageRole.USER ? 'user' : 'model';
            const parts: Part[] = chatMsg.parts.flatMap(part => {
                if (part.type === 'text') return { text: part.content }; // Return single Part
                if (part.type === 'image') return { inlineData: { data: part.content, mimeType: part.mimeType } }; // Return single Part
                return [];
            });
            return { role, parts }; // Fix: Return Content object
        });
    };

    // Helper to get file context
    // Fix: Explicitly return `Part[]`
    const getFileContext = (): import('@google/genai').Part[] => {
        return uploadedFiles.filter(f => f.base64 && !f.error).flatMap(file => {
          // Fix: Check for file extension validity and mimeType correctly.
          const fileExtension = file.file.name.split('.').pop() || '';
          const fileTypeInfo = SUPPORTED_FILE_TYPES[fileExtension];

          if (fileTypeInfo && fileTypeInfo.mimeTypes.some(mt => file.mimeType.includes(mt))) {
            return { inlineData: { data: file.base64!, mimeType: file.mimeType } }; // Return single Part
          } else {
            return { text: `[File: ${file.file.name} (Type: ${file.mimeType}) - ${t('unsupportedFileTypeForDirectAnalysis')}]` }; // Return single Part
          }
        });
    };

    // Helper to get data context
    // Fix: Explicitly return `Part[]`
    const getDataContext = (): import('@google/genai').Part[] => {
        if (fetchedEconomicData && fetchedEconomicData.length > 0 && fetchedDataCountryCode && fetchedDataIndicatorCode && fetchedDataSourceId) {
            const dataText = JSON.stringify(fetchedEconomicData.map(d => ({ date: d.date, value: d.value, source: d.source, year: d.year })), null, 2);
            const countryName = getCountryName(fetchedDataCountryCode, language, t);
            const indicatorName = getIndicatorName(fetchedDataIndicatorCode, fetchedDataSourceId, language, t);
            return [
                { text: `\n\n${t('consideringRecentEconomicData')}: ${indicatorName} in ${countryName} from ${fetchedEconomicData[0].year} to ${fetchedEconomicData[fetchedEconomicData.length - 1].year}.\n` },
                { text: `\`\`\`json\n${dataText}\n\`\`\`` }
            ];
        }
        return [];
    };

    // Combine all contexts for the current prompt
    // Fix: `contextParts` should be `Content[]` for history, and then user's parts.
    const conversationHistoryForPrompt: import('@google/genai').Content[] = getConversationContext();
    const filePartsForPrompt: import('@google/genai').Part[] = getFileContext();
    const dataPartsForPrompt: import('@google/genai').Part[] = getDataContext();

    // If only the welcome message exists in history, and no files/data, then no context.
    const hasContext = conversationHistoryForPrompt.length > 0 || filePartsForPrompt.length > 0 || dataPartsForPrompt.length > 0;


    switch (toolType) {
      case ToolType.ECONOMIC_ANALYSIS:
        prompt = t('promptEconomicAnalysis');
        aiMessage = t('quickEconomicAnalysis');
        break;
      case ToolType.INVESTMENT_CONSULTATION:
        prompt = t('promptInvestmentConsultation');
        aiMessage = t('investmentConsultation');
        break;
      case ToolType.FORECAST:
        if (!fetchedEconomicData || fetchedEconomicData.length === 0 || !fetchedDataCountryCode || !fetchedDataIndicatorCode || !fetchedDataSourceId) {
          window.showNotification(t('noPromptForForecast'), 'warning');
          return;
        }
        const dataText = JSON.stringify(fetchedEconomicData.map(d => ({ date: d.date, value: d.value, year: d.year })), null, 2);
        const countryName = getCountryName(fetchedDataCountryCode, language, t);
        const indicatorName = getIndicatorName(fetchedDataIndicatorCode, fetchedDataSourceId, language, t);
        const modelType = MODEL_CONFIGS[currentModel].name[language];
        prompt = t('forecastPrompt', { modelType, indicator: indicatorName, country: countryName, data: dataText, language: t('langCode') });
        aiMessage = t('runningForecasts', { modelType });
        break;
      case ToolType.STATISTICAL_TESTS:
        prompt = t('promptStatisticalTestsWithContext');
        aiMessage = t('statisticalTestsResponse');
        break;
      case ToolType.VISUALIZATIONS:
        prompt = t('promptVisualizationsWithContext');
        aiMessage = t('visualizationsResponse');
        break;
      case ToolType.SEARCH_EXTERNAL:
        prompt = t('searchExternalPrompt');
        aiMessage = t('searchExternalResponse');
        break;
      case ToolType.EXPORT_CONVERSATION:
        // Handled separately, no Gemini call
        if (!currentConversationId || !allConversations[currentConversationId]) {
          window.showNotification(t('noConversationToExport'), 'warning');
          return;
        }
        const conversationToExport = allConversations[currentConversationId];
        let exportContent = `Conversation Title: ${conversationToExport.title}\n\n`;
        conversationToExport.history.forEach(msg => {
            const sender = msg.role === MessageRole.USER ? t('you') : t('appName');
            const content = msg.parts.map(part => {
                if (part.type === 'text') return stripHtml(part.content);
                if (part.type === 'image') return `[${t('image')}: ${part.mimeType}]`;
                if (part.type === 'chart') return `[${t('chart')}: ${part.title}]`;
                return '';
            }).join('\n');
            exportContent += `${sender} (${msg.timestamp.toLocaleString()}):\n${content}\n\n`;
        });

        const blob = new Blob([exportContent], { type: 'text/plain;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${conversationToExport.title || t('untitledChat')}.txt`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.showNotification(t('exportConversationSuccess'), 'success');
        return; // Exit after export
      default:
        window.showNotification(t('unsupportedTool'), 'error');
        return;
    }

    addMessage(MessageRole.USER, prompt); // Add the tool prompt as a user message
    addMessage(MessageRole.MODEL, aiMessage, undefined, undefined, true); // Add AI's processing message
    setIsProcessing(true);

    try {
      const ai = new GoogleGenAI({apiKey: process.env.API_KEY as string});
      const modelName = MODEL_CONFIGS[currentModel].geminiModel;
      const config = getGeminiConfig(modelName);

      // Fix: Build requestContents with conversation history + file parts + data parts + current prompt
      const requestContents: import('@google/genai').Content[] = [ // Fix: Explicitly type as Content[]
        ...conversationHistoryForPrompt,
        { role: 'user', parts: [...filePartsForPrompt, ...dataPartsForPrompt, { text: prompt }] }
      ];

      let tools: Tool[] = [];
      if (toolType === ToolType.SEARCH_EXTERNAL) {
        tools.push({ googleSearch: {} });
      } else if (toolType === ToolType.ECONOMIC_ANALYSIS || toolType === ToolType.INVESTMENT_CONSULTATION || toolType === ToolType.FORECAST) {
        // Tools can be used for economic analysis potentially leading to data fetches
        tools.push({ functionDeclarations: [fetchEconomicDataFunctionDeclaration] });
      }
      // Other tools (STATISTICAL_TESTS, VISUALIZATIONS) do not currently use Gemini's tool calling

      const responseGenerator = await ai.models.generateContentStream({ // Fix: Added 'await'
        model: modelName,
        contents: requestContents,
        config: { // Fix: tools moved inside config
          ...(tools.length > 0 ? { tools } : {}), // Only pass tools if any are defined
          ...config,
        },
      });

      const processedResponse = await processGeminiResponse(responseGenerator, false, undefined, prompt); // Not first call, initial prompt is what we just set
      
      if (processedResponse.type === 'functionCall' && processedResponse.calls) {
        await handleFunctionCall(processedResponse.calls, prompt, conversationHistory); // Pass the original prompt and history for chained calls
      }
    } catch (error: any) {
      console.error('Error in quick analysis:', error);
      window.showNotification(t('errorInQuickAnalysis', { message: error.message }), 'error');
      // Update the last message to reflect the error
      updateLastStreamingMessage(aiMessage + `\n\n**${t('anErrorOccurred', { message: error.message })}**`, undefined, undefined, false);
    } finally {
      setIsProcessing(false);
    }
  }, [isProcessing, uploadedFiles, fetchedEconomicData, fetchedDataCountryCode, fetchedDataIndicatorCode, fetchedDataSourceId, addMessage, updateLastStreamingMessage, t, language, currentModel, currentConversationId, allConversations, getGeminiConfig, processGeminiResponse, handleFunctionCall, conversationHistory, setIsProcessing]);

  const handleAnalyzeScenario = useCallback(async (description: string, assumptions: string) => {
    if (isProcessing) return;

    if (!process.env.API_KEY) {
      window.showNotification(t('apiKeyError'), 'error');
      return;
    }

    if (!description.trim() || !assumptions.trim()) {
      window.showNotification(t('scenarioDescriptionAndAssumptionsRequired'), 'warning');
      return;
    }

    addMessage(MessageRole.USER, `${t('scenarioDescriptionLabel')}: ${description}\n${t('scenarioAssumptionsLabel')}: ${assumptions}`);
    addMessage(MessageRole.MODEL, t('analyzingScenario'), undefined, undefined, true);
    setIsProcessing(true);

    try {
        if (window.aistudio && !(await window.aistudio.hasSelectedApiKey())) {
            window.showNotification(t('apiKeyError'), 'warning');
            await window.aistudio.openSelectKey();
            setIsProcessing(false);
            return;
        }

        const ai = new GoogleGenAI({apiKey: process.env.API_KEY as string});
        const modelName = MODEL_CONFIGS[currentModel].geminiModel;
        const config = getGeminiConfig(modelName);

        let dataContext = '';
        if (fetchedEconomicData && fetchedEconomicData.length > 0 && fetchedDataCountryCode && fetchedDataIndicatorCode && fetchedDataSourceId) {
            const countryName = getCountryName(fetchedDataCountryCode, language, t);
            const indicatorName = getIndicatorName(fetchedDataIndicatorCode, fetchedDataSourceId, language, t);
            dataContext = t('consideringRecentEconomicData') + ` (${indicatorName} in ${countryName} from ${fetchedEconomicData[0].year}-${fetchedEconomicData[fetchedEconomicData.length - 1].year}). Data: \`\`\`json\n${JSON.stringify(fetchedEconomicData.map(d => ({ date: d.date, value: d.value })), null, 2)}\n\`\`\``;
        }

        const prompt = t('scenarioAnalysisPrompt', {
            description: description,
            assumptions: assumptions,
            dataContext: dataContext,
            language: t('langCode'),
        });

        // Fix: The `contents` array for `generateContentStream` expects an array of `Content` objects.
        // Each `Content` object must have a `role` and `parts: Part[]`.
        const contents: import('@google/genai').Content[] = conversationHistory.flatMap(chatMsg => {
          if (chatMsg.id.startsWith('ai-welcome')) return []; // Exclude welcome message
          const role = chatMsg.role === MessageRole.USER ? 'user' : 'model';
          const parts: Part[] = chatMsg.parts.flatMap(part => {
              if (part.type === 'text') return { text: part.content }; // Return single Part
              if (part.type === 'image') return { inlineData: { data: part.content, mimeType: part.mimeType } }; // Return single Part
              return []; // Ignore ChartPart for Gemini history
          });
          return { role, parts }; // Return a Content object
        }).concat({ role: 'user', parts: [{ text: prompt }] });

        const responseGenerator = await ai.models.generateContentStream({ // Fix: Added 'await'
            model: modelName,
            contents,
            config: { // Fix: tools moved inside config
              tools: [{ functionDeclarations: [fetchEconomicDataFunctionDeclaration] }], // Scenario analysis might trigger data fetches
              ...config,
            },
        });

        const processedResponse = await processGeminiResponse(responseGenerator, false, undefined, prompt); // Not first call, initial prompt is what we just set

        if (processedResponse.type === 'functionCall' && processedResponse.calls) {
            await handleFunctionCall(processedResponse.calls, prompt, conversationHistory);
        } else {
            window.showNotification(t('scenarioAnalyzed'), 'success');
        }
    } catch (error: any) {
        console.error('Error analyzing scenario:', error);
        window.showNotification(t('failedToAnalyzeScenario', { message: error.message }), 'error');
        updateLastStreamingMessage(t('analyzingScenario') + `\n\n**${t('anErrorOccurred', { message: error.message })}**`, undefined, undefined, false);
    } finally {
        setIsProcessing(false);
    }
  }, [isProcessing, addMessage, updateLastStreamingMessage, fetchedEconomicData, fetchedDataCountryCode, fetchedDataIndicatorCode, fetchedDataSourceId, t, language, currentModel, getGeminiConfig, processGeminiResponse, handleFunctionCall, conversationHistory, setIsProcessing]);


  const startVoiceChat = useCallback(async () => {
    if (isVoiceRecording) return;
    setIsVoiceRecording(true);
    setIsProcessing(true); // Indicate processing during voice chat setup and response

    try {
      if (!process.env.API_KEY) {
        throw new Error(t('apiKeyError'));
      }

      if (window.aistudio && !(await window.aistudio.hasSelectedApiKey())) {
        window.showNotification(t('apiKeyError'), 'warning');
        await window.aistudio.openSelectKey();
        setIsProcessing(false);
        setIsVoiceRecording(false);
        return;
      }

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error(t('voiceChatUnavailable'));
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Fix: Replaced webkitAudioContext with AudioContext
      audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 }); // Fix: Using webkitAudioContext fallback
      // Fix: Replaced webkitAudioContext with AudioContext
      const outputAudioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 }); // Fix: Using webkitAudioContext fallback
      
      const source = audioContextRef.current.createMediaStreamSource(stream);
      audioSourceRef.current = source; // Store reference to close later
      scriptProcessorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);

      scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
        const pcmBlob = createBlob(inputData);
        sessionPromiseRef.current?.then((session) => {
          session.sendRealtimeInput({ media: pcmBlob });
        });
      };

      source.connect(scriptProcessorRef.current);
      scriptProcessorRef.current.connect(audioContextRef.current.destination);

      const ai = new GoogleGenAI({apiKey: process.env.API_KEY as string});

      const conversationHistoryForLive: import('@google/genai').Content[] = conversationHistory.flatMap(chatMsg => {
        if (chatMsg.id.startsWith('ai-welcome')) return [];
        const role = chatMsg.role === MessageRole.USER ? 'user' : 'model';
        const parts: Part[] = chatMsg.parts.flatMap(part => {
            if (part.type === 'text') return { text: part.content }; // Return single Part
            return []; // Live API is primarily audio-in/audio-out for now, skip images/charts
        });
        return { role, parts };
      });

      sessionPromiseRef.current = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        // Fix: `history` moved outside of `config` as per guideline example and error.
        // It's removed here, relying on systemInstruction and subsequent inputs for context.
        // history: conversationHistoryForLive, 
        // You must provide callbacks for onopen, onmessage, onerror, and onclose.
        callbacks: {
          onopen: () => {
            console.debug('Live session opened');
            window.showNotification(t('listening'), 'info');
            setIsProcessing(false); // No longer setting up, now listening
            nextStartTimeRef.current = outputAudioContext.currentTime; // Reset start time
            audioPlayingSourcesRef.current.clear(); // Clear any previous sources
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data) {
              const base64EncodedAudioString = message.serverContent.modelTurn.parts[0].inlineData.data;
              if (base64EncodedAudioString) {
                // Fix: Check nextStartTimeRef.current for null/undefined
                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
                const audioBuffer = await decodeAudioData(
                  decode(base64EncodedAudioString),
                  outputAudioContext,
                  24000,
                  1,
                );
                const audioSource = outputAudioContext.createBufferSource();
                audioSource.buffer = audioBuffer;
                audioSource.connect(outputAudioContext.destination); // Connect directly to destination
                audioSource.addEventListener('ended', () => {
                  audioPlayingSourcesRef.current.delete(audioSource);
                });

                audioSource.start(nextStartTimeRef.current);
                nextStartTimeRef.current = nextStartTimeRef.current + audioBuffer.duration;
                audioPlayingSourcesRef.current.add(audioSource);
                setIsProcessing(true); // Model is speaking
                window.showNotification(t('speaking'), 'info');
              }
            } else if (message.serverContent?.interrupted) {
              for (const source of audioPlayingSourcesRef.current.values()) {
                source.stop();
              }
              audioPlayingSourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }

            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              if (text) {
                // Update last message with model's transcription, keep it streaming
                updateLastStreamingMessage(text, undefined, undefined, true);
              }
            } else if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              if (text) {
                // Add user's transcription as a new user message
                addMessage(MessageRole.USER, text);
              }
            }

            if (message.serverContent?.turnComplete) {
                // Finalize the last model streaming message, if any
                if (conversationHistory.length > 0) {
                    const lastMsg = conversationHistory[conversationHistory.length - 1];
                    if (lastMsg.role === MessageRole.MODEL && lastMsg.parts.some(p => p.type === 'text' && (p as TextPart).isStreaming)) {
                        updateLastStreamingMessage((lastMsg.parts.find(p => p.type === 'text') as TextPart)?.content || '', undefined, undefined, false);
                    }
                }
                setIsProcessing(false); // Turn complete, model finished speaking
                window.showNotification(t('listening'), 'info'); // Go back to listening
            }

            if (message.toolCall) {
              // Extract tools from here and call handleFunctionCall,
              // passing the current conversation history.
              // Note: Live API tool_calls might not be handled directly by history,
              // but rather trigger an action. The model will then respond via audio.
              await handleFunctionCall(message.toolCall.functionCalls, t('functionCall'), conversationHistory);
            }
          },
          onerror: (e: ErrorEvent) => {
            console.error('Live session error:', e);
            window.showNotification(t('voiceChatError', { message: e.message }), 'error');
            stopVoiceChat(); // Attempt to stop on error
          },
          onclose: (e: CloseEvent) => {
            console.debug('Live session closed:', e);
            window.showNotification(t('voiceChatStopped'), 'info');
            stopVoiceChat();
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: t('voiceChatSystemInstruction'),
          inputAudioTranscription: {}, // Enable transcription for user input audio.
          outputAudioTranscription: {}, // Enable transcription for model output audio.
          tools: [{ functionDeclarations: [fetchEconomicDataFunctionDeclaration] }], // Include tools
        },
      });

    } catch (error: any) {
      console.error('Error starting voice chat:', error);
      if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
        window.showNotification(t('microphonePermissionDenied'), 'error');
      } else {
        window.showNotification(t('voiceChatError', { message: error.message }), 'error');
      }
      setIsVoiceRecording(false);
      setIsProcessing(false);
    }
  }, [isVoiceRecording, setIsVoiceRecording, setIsProcessing, t, conversationHistory, addMessage, updateLastStreamingMessage, handleFunctionCall, language, sessionPromiseRef, audioContextRef, scriptProcessorRef, audioSourceRef, nextStartTimeRef, audioPlayingSourcesRef]);

  const stopVoiceChat = useCallback(async () => {
    if (!isVoiceRecording) return;

    if (sessionPromiseRef.current) {
      const session = await sessionPromiseRef.current;
      session.close();
      sessionPromiseRef.current = null;
    }

    if (audioSourceRef.current) {
        audioSourceRef.current.mediaStream.getTracks().forEach(track => track.stop());
        audioSourceRef.current.disconnect();
        audioSourceRef.current = null;
    }
    if (scriptProcessorRef.current) {
        scriptProcessorRef.current.disconnect();
        scriptProcessorRef.current = null;
    }
    if (audioContextRef.current) {
        await audioContextRef.current.close();
        audioContextRef.current = null;
    }

    // Stop any currently playing audio
    for (const source of audioPlayingSourcesRef.current.values()) {
        source.stop();
    }
    audioPlayingSourcesRef.current.clear();
    nextStartTimeRef.current = 0;

    setIsVoiceRecording(false);
    setIsProcessing(false); // Stop processing after voice chat ends
    window.showNotification(t('voiceChatStopped'), 'info');
  }, [isVoiceRecording, t, sessionPromiseRef, audioSourceRef, scriptProcessorRef, audioContextRef, audioPlayingSourcesRef, nextStartTimeRef, setIsVoiceRecording, setIsProcessing]);

  const onNewChat = useCallback(() => {
    if (isProcessing && !window.confirm(t('confirmNewChat'))) {
      return;
    }
    createNewConversation();
    setUploadedFiles([]);
    setFetchedEconomicData(null);
    setFetchedDataCountryCode(null);
    setFetchedDataIndicatorCode(null);
    setFetchedDataSourceId(null);
    window.showNotification(t('newChatStarted'), 'success');
  }, [isProcessing, t, createNewConversation, setUploadedFiles, setFetchedEconomicData, setFetchedDataCountryCode, setFetchedDataIndicatorCode, setFetchedDataSourceId]);


  const onLoadConversation = useCallback((id: string) => {
    setCurrentConversationId(id);
    window.showNotification(t('chatLoaded'), 'success');
  }, [setCurrentConversationId, t]);

  const onDeleteConversation = useCallback((id: string) => {
    if (window.confirm(t('confirmDeleteChat'))) {
      setAllConversations(prev => {
        const updated = { ...prev };
        delete updated[id];
        return updated;
      });
      if (currentConversationId === id) {
        createNewConversation(); // Create new chat if current one is deleted
      }
      window.showNotification(t('chatDeleted'), 'success');
    }
  }, [t, currentConversationId, createNewConversation, setAllConversations]);

  const toggleSidebar = useCallback(() => {
    setIsSidebarOpen(prev => !prev);
  }, []);

  // --- Effects ---

  // Load conversation history from localStorage on mount
  useEffect(() => {
    const savedConversationsRaw = localStorage.getItem('chat_elbokl_all_conversations');
    const lastActiveId = localStorage.getItem('chat_elbokl_last_active_id');

    if (savedConversationsRaw) {
      try {
        const savedConversations = JSON.parse(savedConversationsRaw);
        // Date objects need to be revived
        Object.values(savedConversations).forEach((conv: any) => {
            conv.timestamp = new Date(conv.timestamp);
            conv.history.forEach((msg: ChatMessage) => {
                msg.timestamp = new Date(msg.timestamp);
            });
        });

        setAllConversations(savedConversations);

        if (lastActiveId && savedConversations[lastActiveId]) {
          setCurrentConversationId(lastActiveId);
        } else if (Object.keys(savedConversations).length > 0) {
          // Fallback to the most recent conversation if last active is invalid
          const mostRecentConv = Object.values(savedConversations).sort((a: any, b: any) => b.timestamp.getTime() - a.timestamp.getTime())[0] as ConversationType;
          setCurrentConversationId(mostRecentConv.id);
        } else {
          createNewConversation();
        }
      } catch (error) {
        console.error('Failed to parse saved conversations:', error);
        createNewConversation();
      }
    } else {
      createNewConversation();
    }
  }, [createNewConversation, setAllConversations, setCurrentConversationId]);

  // Save conversation history to localStorage whenever it changes
  useEffect(() => {
    if (Object.keys(allConversations).length > 0) {
        localStorage.setItem('chat_elbokl_all_conversations', JSON.stringify(allConversations));
    }
    if (currentConversationId) {
        localStorage.setItem('chat_elbokl_last_active_id', currentConversationId);
    }
  }, [allConversations, currentConversationId]);

  // Check all APIs on mount
  useEffect(() => {
    const checkAllAPIs = async () => {
      const wbStatus = await checkWorldBankAPI(t, language);
      const ctStatus = await checkComtradeAPI(t, language);
      const imfStatus = await checkIMFAPI(t, language);
      const fredStatus = await checkFREDAPI(t, language); // Added FRED API check
      setApiStatus({ worldbank: wbStatus, comtrade: ctStatus, imf: imfStatus, fred: fredStatus });
    };
    checkAllAPIs();
  }, [t, language, setApiStatus]);


  // Cleanup effect for voice chat on unmount
  useEffect(() => {
    return () => {
      stopVoiceChat();
    };
  }, [stopVoiceChat]);


  // Filter conversations for Sidebar display
  const conversationsArray = Object.values(allConversations).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

  // Convert ChatMessage[] to DisplayMessage[] for the Conversation component
  const displayMessages: DisplayMessage[] = conversationHistory.map(msg => ({
    id: msg.id,
    sender: msg.role === MessageRole.USER ? 'user' : 'ai',
    content: msg.parts.map(p => (p.type === 'text' ? p.content : '')).join(' '), // Flatten content for DisplayMessage
    timestamp: msg.timestamp,
    groundingUrls: msg.groundingUrls,
    isStreaming: msg.parts.some(p => p.type === 'text' && (p as TextPart).isStreaming),
    rawParts: msg.parts,
  }));

  return (
    <div className="flex h-screen bg-gray-100 antialiased text-gray-900">
      <Notification />
      <div className={`fixed inset-y-0 right-0 w-80 bg-gray-50 z-50 md:relative md:translate-x-0 transition-transform duration-300 ease-in-out border-l border-gray-200 ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <Sidebar
          currentModel={currentModel}
          onModelChange={setCurrentModel}
          apiStatus={apiStatus}
          setApiStatus={setApiStatus}
          uploadedFiles={uploadedFiles}
          setUploadedFiles={setUploadedFiles}
          onAnalyzeFiles={handleAnalyzeFiles}
          onNewChat={onNewChat}
          onDataFetch={handleDataFetch}
          onToolClick={handleToolClick}
          isProcessing={isProcessing}
          setIsProcessing={setIsProcessing}
          onAnalyzeScenario={handleAnalyzeScenario}
          fetchedEconomicData={fetchedEconomicData}
          fetchedDataCountryCode={fetchedDataCountryCode}
          fetchedDataIndicatorCode={fetchedDataIndicatorCode}
          onToggleSidebar={toggleSidebar}
          conversationHistory={conversationHistory} // Pass conversation history for context in tools
          conversations={conversationsArray}
          currentConversationId={currentConversationId}
          onLoadConversation={onLoadConversation}
          onDeleteConversation={onDeleteConversation}
          onRenameConversation={onRenameConversation}
        />
      </div>

      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <Header
          currentModel={currentModel}
          apiStatus={apiStatus}
          onToggleSidebar={toggleSidebar}
        />

        <Conversation messages={displayMessages} isTyping={isProcessing} />

        <MessageInput
          onSendMessage={handleSendMessage}
          uploadedFiles={uploadedFiles}
          isProcessing={isProcessing}
          onStartVoiceChat={startVoiceChat}
          onStopVoiceChat={stopVoiceChat}
          isVoiceRecording={isVoiceRecording}
        />
        <Footer />
      </div>
    </div>
  );
};

export default App;