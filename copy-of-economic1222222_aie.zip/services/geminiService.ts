import { GoogleGenAI, GenerateContentResponse, GenerateContentParameters, Part, Tool, Modality, FunctionDeclaration, Type, LiveServerMessage, Blob, FunctionResponse } from "@google/genai";
import { REAL_DATA_SOURCES, MAX_FILE_SIZE_BYTES, SUPPORTED_FILE_TYPES } from '../constants';
import { StandardEconomicDataItem, AllApiStatus, ApiStatus, UploadedFile, Language, DataFetchOptions, CountryOption, IndicatorOption } from '../types';
import { fileToBase64 } from '../utils/converters';
import { translations } from '../translations';
import { COUNTRIES } from '../countries';
import { INDICATORS } from '../indicators';
// Fix: Corrected import path for Translator
import { Translator } from '../LanguageContext';


// Define allowed MIME types for direct multimodal analysis (not structured data like Excel/CSV)
const multimodalAllowedMimeTypes = ['image/jpeg', 'image/png', 'text/plain', 'application/pdf'];


/**
 * Helper function to generate content stream from Gemini.
 * Centralizes the Gemini client initialization and stream logic.
 * This function is now simplified, assuming `GoogleGenAI` is instantiated by the caller.
 * (Note: The @google/genai guideline advises direct instantiation for each call for Veo,
 * but for text models, a single instance can be reused. For consistency with the guideline's
 * general "create new instance right before API call" advice, we'll assume instantiation
 * will happen where `generateContentStream` is called, and this function just wraps the API call).
 */
export async function* generateContentStream(ai: GoogleGenAI, params: {
  modelName: string;
  requestContents: GenerateContentParameters['contents'];
  config?: GenerateContentParameters['config'];
}): AsyncGenerator<GenerateContentResponse> {
  const stream = await ai.models.generateContentStream({
    model: params.modelName,
    contents: params.requestContents,
    config: params.config,
  });

  for await (const chunk of stream) {
    yield chunk;
  }
}

/**
 * Checks the connectivity status of the World Bank API.
 * @param t - Translator function.
 * @param language - Current language.
 * @returns An ApiStatus object indicating connectivity.
 */
export async function checkWorldBankAPI(t: Translator, language: Language): Promise<ApiStatus> {
  try {
    const testCountry = 'US'; // Using US for a general test
    const testIndicator = 'NY.GDP.MKTP.CD'; // GDP indicator
    const testYear = new Date().getFullYear().toString();
    const url = `${REAL_DATA_SOURCES.worldbank.baseUrl}${testCountry}/indicator/${testIndicator}?date=${testYear}&format=json&per_page=1`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`${response.status} - ${response.statusText}`);
    }
    const data = await response.json();
    if (data && data[1] && data[1].length > 0) {
      return { connected: true };
    }
    return { connected: false, message: t('noDataFound') };
  } catch (error: any) {
    console.error('World Bank API check failed:', error);
    return { connected: false, message: t('apiConnectionError', { message: error.message }) };
  }
}

/**
 * Checks the connectivity status of the FRED API.
 * @param t - Translator function.
 * @param language - Current language.
 * @returns An ApiStatus object indicating connectivity.
 */
export async function checkFREDAPI(t: Translator, language: Language): Promise<ApiStatus> {
  const apiKey = process.env.FRED_API_KEY;
  if (!apiKey) {
    return { connected: false, message: t('fredApiKeyMissing') };
  }
  try {
    const testSeries = 'GDP'; // Using GDP for a general test
    const url = `${REAL_DATA_SOURCES.fred.baseUrl}?series_id=${testSeries}&api_key=${apiKey}&file_type=json&limit=1`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`${response.status} - ${response.statusText}`);
    }
    const data = await response.json();
    if (data && data.seriess && data.seriess.length > 0) {
      return { connected: true };
    }
    return { connected: false, message: t('noDataFound') };
  } catch (error: any) {
    console.error('FRED API check failed:', error);
    return { connected: false, message: t('apiConnectionError', { message: error.message }) };
  }
}

/**
 * Checks the connectivity status of the Comtrade API.
 * Currently returns false as it's not implemented.
 * @param t - Translator function.
 * @param language - Current language.
 * @returns An ApiStatus object indicating connectivity.
 */
export async function checkComtradeAPI(t: Translator, language: Language): Promise<ApiStatus> {
  return { connected: false, message: t('notImplemented', { apiName: 'UN Comtrade' }) };
}

/**
 * Checks the connectivity status of the IMF API.
 * Currently returns false as it's not implemented.
 * @param t - Translator function.
 * @param language - Current language.
 * @returns An ApiStatus object indicating connectivity.
 */
export async function checkIMFAPI(t: Translator, language: Language): Promise<ApiStatus> {
  return { connected: false, message: t('notImplemented', { apiName: 'IMF' }) };
}

/**
 * Fetches economic data from the World Bank API.
 * @param countryCode - The country code (e.g., 'US').
 * @param indicatorCode - The indicator code (e.g., 'NY.GDP.MKTP.CD').
 * @param startDate - The start date for the data (e.g., '2010').
 * @param endDate - The end date for the data (e.g., '2020').
 * @param t - Translation function.
 * @param language - Current language.
 * @returns A promise that resolves to an array of StandardEconomicDataItem.
 */
export async function fetchWorldBankData(
  countryCode: string,
  indicatorCode: string,
  startDate: string, // now expects 'YYYY-MM-DD' but WB API uses 'YYYY' for date range. Adjusting.
  endDate: string, // now expects 'YYYY-MM-DD' but WB API uses 'YYYY' for date range. Adjusting.
  t: Translator,
  language: Language
): Promise<StandardEconomicDataItem[]> {
  const startYear = new Date(startDate).getFullYear();
  const endYear = new Date(endDate).getFullYear();
  const url = `${REAL_DATA_SOURCES.worldbank.baseUrl}${countryCode}/indicator/${indicatorCode}?date=${startYear}:${endYear}&format=json&per_page=1000`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(t('httpStatusError', { status: response.status, message: errorText }));
    }
    const data = await response.json();

    if (data && data[1]) {
      const indicatorMeta = INDICATORS.find(i => i.code === indicatorCode);
      const countryMeta = COUNTRIES.find(c => c.code === countryCode);

      // Filter out null values and map to our StandardEconomicDataItem
      const transformedData: StandardEconomicDataItem[] = data[1]
        .filter((item: any) => item.value !== null)
        .map((item: any) => ({
          date: `${item.date}-01-01`, // Convert year to YYYY-MM-DD format for consistency
          value: item.value,
          source: REAL_DATA_SOURCES.worldbank.sourceId,
          countryCode: item.country.id,
          countryName: countryMeta?.name,
          indicatorCode: item.indicator.id,
          indicatorName: indicatorMeta?.name,
          unit: indicatorMeta?.unit,
          year: item.date, // Consistent year field
        }))
        .sort((a: any, b: any) => parseInt(a.year) - parseInt(b.year)); // Sort by year
      return transformedData;
    }
    return [];
  } catch (error: any) {
    console.error('Failed to fetch World Bank data:', error);
    throw new Error(t('failedToFetchData', { message: error.message }));
  }
}

/**
 * Fetches economic data from the FRED API.
 * @param indicatorCode - The FRED series ID (e.g., 'GDP', 'CPIAUCSL').
 * @param startDate - The start date for the data (e.g., '2010-01-01').
 * @param endDate - The end date for the data (e.g., '2020-12-31').
 * @param t - Translation function.
 * @param language - Current language.
 * @returns A promise that resolves to an array of StandardEconomicDataItem.
 */
export async function fetchFREDData(
  indicatorCode: string,
  startDate: string,
  endDate: string,
  t: Translator,
  language: Language
): Promise<StandardEconomicDataItem[]> {
  const apiKey = process.env.FRED_API_KEY;
  if (!apiKey) {
    throw new Error(t('fredApiKeyMissing'));
  }

  const indicatorMeta = INDICATORS.find(i => i.fredCode === indicatorCode);
  if (!indicatorMeta) {
    throw new Error(t('invalidFredIndicatorCode'));
  }

  const url = `${REAL_DATA_SOURCES.fred.baseUrl}?series_id=${indicatorCode}&api_key=${apiKey}&file_type=json&observation_start=${startDate}&observation_end=${endDate}`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(t('httpStatusError', { status: response.status, message: errorText }));
    }
    const data = await response.json();

    if (data && data.observations) {
      const transformedData: StandardEconomicDataItem[] = data.observations
        .filter((item: any) => item.value !== '.' && item.value !== null) // Filter out missing values
        .map((item: any) => ({
          date: item.date,
          value: parseFloat(item.value),
          source: REAL_DATA_SOURCES.fred.sourceId,
          indicatorCode: indicatorCode,
          indicatorName: indicatorMeta?.name,
          unit: indicatorMeta?.unit,
          year: item.date.substring(0, 4), // Extract year
        }))
        .sort((a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime());
      return transformedData;
    }
    return [];
  } catch (error: any) {
    console.error('Failed to fetch FRED data:', error);
    throw new Error(t('failedToFetchData', { message: error.message }));
  }
}


/**
 * Function declaration for fetching economic data from World Bank or FRED.
 * This is used for Gemini's function calling feature.
 */
export const fetchEconomicDataFunctionDeclaration: FunctionDeclaration = {
  name: 'fetchEconomicData',
  parameters: {
    type: Type.OBJECT,
    description: 'Fetch historical economic data from specified API (World Bank or FRED) for a given country (for World Bank) and indicator over a date range. The `startDate` and `endDate` should be in YYYY-MM-DD format. Country code is optional for FRED if the indicator is not country-specific.',
    properties: {
      dataSource: {
        type: Type.STRING,
        description: `The data source to fetch from. Must be one of: ${Object.values(REAL_DATA_SOURCES).map(s => s.sourceId).filter(s => s !== 'imf' && s !== 'comtrade').join(', ')}.`,
        enum: Object.values(REAL_DATA_SOURCES).map(s => s.sourceId).filter(s => s !== 'imf' && s !== 'comtrade'), // Exclude unimplemented APIs for function calling
      },
      countryCode: {
        type: Type.STRING,
        description: `The 2-letter country code (ISO 3166-1 alpha-2) for which to fetch data. Required for World Bank. Must be one of: ${COUNTRIES.map(c => c.code).join(', ')}.`,
        enum: COUNTRIES.map(c => c.code),
        // Fix: Removed 'optional: true' as it's not a valid property for Schema.
        // Optionality is determined by its absence in the 'required' array.
      },
      indicatorCode: {
        type: Type.STRING,
        description: `The indicator code to fetch. For World Bank, this is like 'NY.GDP.MKTP.CD'. For FRED, this is the series ID like 'GDP' or 'CPIAUCSL'. Must be one of: ${INDICATORS.map(i => i.code).concat(INDICATORS.map(i => i.fredCode!).filter(Boolean)).join(', ')}.`,
        enum: INDICATORS.map(i => i.code).concat(INDICATORS.map(i => i.fredCode!).filter(Boolean)), // Combine WB and FRED indicator codes
      },
      startDate: {
        type: Type.STRING,
        description: 'The start date for the data in YYYY-MM-DD format. E.g., "2010-01-01".',
      },
      endDate: {
        type: Type.STRING,
        description: 'The end date for the data in YYYY-MM-DD format. E.g., "2020-12-31".',
      },
    },
    required: ['dataSource', 'indicatorCode', 'startDate', 'endDate'],
  },
  // Fix: Explicitly define the return type (optional but good practice for documentation)
  // response: {
  //   type: Type.ARRAY,
  //   items: {
  //     type: Type.OBJECT,
  //     properties: {
  //       date: { type: Type.STRING },
  //       value: { type: Type.NUMBER },
  //       source: { type: Type.STRING },
  //       countryCode: { type: Type.STRING, optional: true },
  //       indicatorCode: { type: Type.STRING },
  //       unit: { type: Type.STRING, optional: true },
  //       year: { type: Type.STRING },
  //     }
  //   }
  // }
};

// --- Live API Audio Utilities ---
export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}
// --- End Live API Audio Utilities ---


export const getFileMimeType = (file: UploadedFile): string => {
  const fileExtension = file.file.name.split('.').pop()?.toLowerCase();
  const mimeType = file.mimeType || (fileExtension ? (SUPPORTED_FILE_TYPES[fileExtension]?.mimeTypes[0] || 'application/octet-stream') : 'application/octet-stream');
  return mimeType;
};

export async function* analyzeFilesWithGemini(
  ai: GoogleGenAI, // Pass the AI instance directly
  prompt: string,
  files: UploadedFile[],
  modelName: string,
  t: Translator,
  language: Language,
): AsyncGenerator<GenerateContentResponse> {
  // Create content parts for the prompt and all uploaded files
  const contents: Part[] = [{ text: prompt }];

  for (const file of files) {
    if (file.base64 && file.mimeType) {
      if (multimodalAllowedMimeTypes.includes(file.mimeType)) {
        contents.push({
          inlineData: {
            data: file.base64,
            mimeType: file.mimeType,
          },
        });
      } else {
        // For unsupported multimodal MIME types (e.g., Excel/CSV for direct structured data),
        // send a text placeholder and log a warning.
        console.warn(`File ${file.file.name} has unsupported MIME type for direct multimodal analysis: ${file.mimeType}. Sending as text placeholder.`);
        // Show specific warning for Excel/CSV as they are "supported" for upload but not direct multimodal analysis.
        const fileExtension = file.file.name.split('.').pop()?.toLowerCase();
        if (fileExtension === 'xlsx' || fileExtension === 'xls' || fileExtension === 'csv') {
          contents.push({ text: `[File: ${file.file.name} (Type: ${file.mimeType}) - ${t('excelFileWarning')}]` });
        } else {
          contents.push({ text: `[File: ${file.file.name} (Type: ${file.mimeType}) - ${t('unsupportedFileTypeForDirectAnalysis')}]` });
        }
      }
    } else if (file.error) {
      // Log or handle files with errors, but don't send them to Gemini
      console.warn(`Skipping file ${file.file.name} due to upload error: ${file.error}`);
    } else {
      console.warn(`File ${file.file.name} is missing base64 data or mimeType.`);
      // If base64 is not ready, push an alert or handle differently
      contents.push({ text: `[Error: Failed to process file ${file.file.name}]` });
    }
  }

  // analyzeFilesWithGemini typically doesn't use tools like googleSearch or fetchEconomicDataFunctionDeclaration
  // for the initial file analysis itself, as its purpose is to analyze the file content.
  // If tools were needed based on file content, they would be passed here as top-level.
  const stream = await ai.models.generateContentStream({
    model: modelName,
    // Fix: The correct property name is `contents`, and its value should be an array of `Content` objects
    // for a new turn. Each `Content` object has a `role` and `parts`.
    contents: [{ role: 'user', parts: contents }], // Correct format for single turn, multi-part request.
    config: {
      // Configure thinkingBudget for 2.5 series models for complex analysis
      thinkingConfig: { thinkingBudget: modelName === 'gemini-2.5-pro' ? 32768 : 24576 }
    }
  });

  for await (const chunk of stream) {
    yield chunk;
  }
}