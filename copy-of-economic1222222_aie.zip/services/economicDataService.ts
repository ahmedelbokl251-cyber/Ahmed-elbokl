// services/economicDataService.ts
// Fix: Updated imports to use the newly defined types from '../types'
import { EconomicDataItem, DataFetchOptions, Language, TranslatedString, StandardEconomicDataItem } from '../types';
import { REAL_DATA_SOURCES } from '../constants';
import { translations } from '../translations';
import { formatNumber } from '../utils/formatters';
import { COUNTRIES } from '../countries';
import { getCountryName, getIndicatorName, getUnitName } from '../utils/helpers'; // Import new helpers

// Helper type for the translator function
type Translator = (key: keyof typeof translations | TranslatedString, params?: Record<string, string | number>) => string;

// The actual fetchWorldBankData is now in geminiService.ts and is used for both direct and function calls.
// This file will now focus only on generating the analysis from already fetched data.

/**
 * Generates an analytical response based on fetched economic data.
 * @param data - Array of EconomicDataItem.
 * @param language - Current language for the analysis.
 * @param t - Translation function.
 * @param dataOptions - Options used to fetch data for context.
 * @returns A formatted string containing the analysis.
 */
export const generateRealDataAnalysis = (
  data: StandardEconomicDataItem[], // Use StandardEconomicDataItem
  language: Language,
  t: Translator,
  dataOptions: DataFetchOptions
): string => {
  if (data.length === 0) {
    return t('noDataFoundForAnalysis'); // Assuming this key exists in translations
  }

  // Dynamically get indicator, country, and source info based on dataOptions.dataSource
  const dataSourceInfo = REAL_DATA_SOURCES[dataOptions.dataSource];
  const indicatorInfo = getIndicatorName(dataOptions.indicatorCode, dataOptions.dataSource, language, t);
  const countryInfo = dataOptions.countryCode ? getCountryName(dataOptions.countryCode, language, t) : undefined;
  const unit = getUnitName(dataOptions.indicatorCode, dataOptions.dataSource, language, t) || '';

  const indicatorName = indicatorInfo || dataOptions.indicatorCode;
  const countryName = countryInfo || t('notApplicable'); // For FRED indicators that might not be country-specific
  const sourceName = dataSourceInfo ? dataSourceInfo.name[language] : t('unknownSource');
  
  const startDate = data[0].year;
  const endDate = data[data.length - 1].year;
  const period = `${startDate}-${endDate}`;

  // Basic Statistics
  const values = data.map(item => item.value).filter(val => val !== null) as number[];
  if (values.length === 0) {
    return t('noDataFoundForAnalysis');
  }

  const latestValue = data[data.length - 1].value;
  const latestYear = data[data.length - 1].year;
  const averageValue = values.reduce((sum, val) => sum + val, 0) / values.length;
  const maxValue = Math.max(...values);
  const minValue = Math.min(...values);

  // Trend Analysis (simple linear approximation or comparison)
  let trend = t('stable');
  if (data.length > 1) {
    const firstValue = data[0].value;
    const lastValue = data[data.length - 1].value;
    if (firstValue !== null && lastValue !== null && firstValue !== 0) {
      const change = ((lastValue - firstValue) / firstValue) * 100;

      if (change > 10) trend = t('strongUpward');
      else if (change > 0) trend = t('upward');
      else if (change < -10) trend = t('strongDownward');
      else if (change < 0) trend = t('downward');
    }
  }

  // Analytical Insights
  const insights: string[] = [];

  // Insight 1: Latest data point
  insights.push(
    t('latestDataFor', {
      indicator: indicatorName,
      country: countryName,
      value: formatNumber(latestValue, language, t) + (unit ? ` ${unit}` : ''),
      year: latestYear,
    })
  );

  // Insight 2: Change from start to end
  if (data.length > 1) {
    const firstValue = data[0].value;
    const lastValue = data[data.length - 1].value;
    if (firstValue !== null && lastValue !== null && firstValue !== 0) {
      const changePercentage = ((lastValue - firstValue) / firstValue * 100).toFixed(2);
      const status = parseFloat(changePercentage) >= 0 ? t('improvement') : t('decline');
      insights.push(
        t('performanceChange', {
          change: changePercentage,
          status: status,
        })
      );
    }
  }

  // Insight 3: Overall trend
  insights.push(
    t('overallTrend', { period: period, trend: trend })
  );

  // Insight 4: Current value comparison to average
  const valueStatus = latestValue !== null && latestValue !== undefined && latestValue > averageValue ? t('higher') : t('lower');
  insights.push(
    t('currentValueComparison', { valueStatus: valueStatus })
  );

  // Recommendations based on indicator and trend (simplified example)
  const recommendations: string[] = [];
  if (dataOptions.indicatorCode.includes('GDP')) { // GDP
    if (trend === t('upward') || trend === t('strongUpward')) {
      recommendations.push(t('continueCurrentGrowthPolicies'));
    } else {
      recommendations.push(t('stimulusPoliciesNeeded'));
    }
  } else if (dataOptions.indicatorCode.includes('CPI') || dataOptions.indicatorCode.includes('Inflation')) { // Inflation
    if (latestValue !== null && latestValue !== undefined && latestValue > 5) { // Assuming >5% is high inflation
      recommendations.push(t('monitorInflationActions'));
    } else {
      recommendations.push(t('inflationAcceptable'));
    }
  } else if (dataOptions.indicatorCode.includes('UEM') || dataOptions.indicatorCode.includes('Unemployment')) { // Unemployment
    if (latestValue !== null && latestValue !== undefined && latestValue > 7) { // Assuming >7% is high unemployment
      recommendations.push(t('employmentProgramsNeeded'));
    } else {
      recommendations.push(t('unemploymentAcceptable'));
    }
  } else if (dataOptions.indicatorCode.includes('INR') || dataOptions.indicatorCode.includes('Interest Rates') || dataOptions.indicatorCode.includes('FEDFUNDS')) { // Interest Rates
    if (latestValue !== null && latestValue !== undefined && latestValue > 3) recommendations.push(t('highInterestRatesImpact'));
    else recommendations.push(t('lowInterestRatesBenefit'));
  } else if (dataOptions.indicatorCode.includes('EXP')) { // Exports
    if (trend.includes(t('upward'))) recommendations.push(t('boostExportsPolicies'));
    else recommendations.push(t('reviewTradePolicies'));
  } else if (dataOptions.indicatorCode.includes('IMP')) { // Imports
    if (trend.includes(t('strongUpward'))) recommendations.push(t('encourageLocalProduction'));
    else recommendations.push(t('balanceImports'));
  }
  recommendations.push(t('monitorContinuously'));


  const dataSample = data.slice(-5).map(item => `| ${item.year} | ${formatNumber(item.value, language, t)} ${unit} |`).join('\n');

  return `
<div class="analysis-box mt-3">
  <h4>${t('realDataAnalysis')}</h4>
  <p>${t('sourceInformation')}</p>
  <ul>
    <li>**${t('source')}**: ${sourceName}</li>
    ${dataOptions.countryCode ? `<li>**${t('country')}**: ${countryName}</li>` : ''}
    <li>**${t('indicator')}**: ${indicatorName}</li>
    <li>**${t('period')}**: ${period}</li>
    <li>**${t('numberOfDataPoints')}**: ${data.length}</li>
  </ul>

  <p>${t('basicStatistics')}</p>
  <ul>
    <li>**${t('latestValue')}**: ${formatNumber(latestValue, language, t)} ${unit} (${latestYear})</li>
    <li>**${t('average')}**: ${formatNumber(averageValue, language, t)} ${unit}</li>
    <li>**${t('maximum')}**: ${formatNumber(maxValue, language, t)} ${unit}</li>
    <li>**${t('minimum')}**: ${formatNumber(minValue, language, t)} ${unit}</li>
    <li>**${t('trend')}**: ${trend}</li>
  </ul>

  <p>${t('dataSample')}</p>
  | ${t('yearCol')} | ${t('valueCol')} |
  |---|---|
  ${dataSample}

  <p>${t('analyticalInsights')}</p>
  <ul>
    ${insights.map(insight => `<li>${insight}</li>`).join('\n')}
  </ul>

  <p>${t('recommendationsText')}</p>
  <ul>
    ${recommendations.map(rec => `<li>${rec}</li>`).join('\n')}
  </ul>

  <small class="reference">${t('fileAnalysisDisclaimer')} ${new Date().toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}.</small>
</div>
`;
};