import React, { useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { Message } from './Message'; // Assuming Message component is in the same directory

interface ChatWindowProps {
  messages: ChatMessage[];
  isLoading: boolean;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    // Scroll to bottom when messages or loading state changes, ensuring new content is visible
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-white rounded-lg shadow-inner max-h-[calc(100vh-14rem)] md:max-h-[calc(100vh-10rem)] scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
      {messages.map((message) => (
        <Message key={message.id} message={message} />
      ))}
      {isLoading && (
        <div className="flex justify-start">
          <div className="bg-gray-200 text-gray-800 p-3 rounded-xl max-w-[80%] md:max-w-[70%] text-sm shadow-md rounded-bl-none">
            <div className="flex items-center space-x-2">
              <span className="animate-spin h-4 w-4 border-2 border-blue-500 border-t-transparent rounded-full"></span>
              <span>Thinking...</span>
            </div>
          </div>
        </div>
      )}
      <div ref={messagesEndRef} />
    </div>
  );
};