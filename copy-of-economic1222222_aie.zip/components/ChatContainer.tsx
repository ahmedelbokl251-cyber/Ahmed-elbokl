// components/ChatContainer.tsx
import React, { useEffect, useRef } from 'react';
// Fix: Renamed Message to ChatMessage to avoid conflict and use the correct type
import { ChatMessage } from '../types';
// Fix: Changed default import to named import for Message component
import { Message } from './Message';
import { useLanguage } from '../LanguageContext'; // Fix: Corrected import path

interface ChatContainerProps {
  messages: ChatMessage[];
  isProcessing: boolean;
}

const ChatContainer: React.FC<ChatContainerProps> = ({ messages, isProcessing }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { t } = useLanguage();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isProcessing]); // Scroll to bottom when messages or processing state changes

  return (
    <div className="conversation" role="log" aria-live="polite" aria-label={t('conversationHistory')}>
      {messages.map((message) => (
        <Message key={message.id} message={message} />
      ))}
      {isProcessing && (
        <div className="ai-message">
          <div className="message-bubble ai-bubble typing-indicator">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-6 h-6 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center" aria-hidden="true">
                <i className="fas fa-robot text-white text-xs"></i>
              </div>
              <span className="font-semibold text-gray-800">{t('appName')}</span>
            </div>
            <div className="typing-dots">
              <span className="typing-dot"></span>
              <span className="typing-dot"></span>
              <span className="typing-dot"></span>
            </div>
          </div>
        </div>
      )}
      <div ref={messagesEndRef} aria-hidden="true" />
    </div>
  );
};

export default ChatContainer;