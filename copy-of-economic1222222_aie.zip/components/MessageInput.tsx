import React, { useState, useRef, useEffect } from 'react';
// Fix: Updated import to use the newly defined UploadedFile from '../types'
import { UploadedFile } from '../types';
import { useLanguage } from '../LanguageContext';

interface MessageInputProps {
  onSendMessage: (message: string) => void;
  uploadedFiles: UploadedFile[];
  isProcessing: boolean;
  onStartVoiceChat: () => Promise<void>;
  onStopVoiceChat: () => Promise<void>;
  isVoiceRecording: boolean;
}

const MessageInput: React.FC<MessageInputProps> = ({ onSendMessage, uploadedFiles, isProcessing, onStartVoiceChat, onStopVoiceChat, isVoiceRecording }) => {
  const { t } = useLanguage();
  const [message, setMessage] = useState<string>('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea logic
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'; // Reset height
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`; // Set to scroll height
    }
  }, [message]);

  const handleSendMessage = () => {
    if (message.trim() && !isProcessing) {
      onSendMessage(message.trim());
      setMessage('');
      // Reset textarea height after sending
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    } else if (!message.trim()) {
      // Fix: Used window.showNotification correctly
      window.showNotification(t('pleaseEnterMessage'), 'warning'); // Use translated message
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
  };

  const fileCount = uploadedFiles.filter(f => !f.error && !f.isUploading).length;

  const handleVoiceButtonClick = async () => {
    if (isVoiceRecording) {
      await onStopVoiceChat();
    } else {
      await onStartVoiceChat();
    }
  };

  return (
    <div className="relative p-4 md:p-5 bg-white border-t border-gray-200 flex-shrink-0">
      <div className="max-w-3xl mx-auto relative flex items-end">
        {/* Voice Chat Button */}
        <button
          className={`absolute right-2 bottom-2 w-9 h-9 flex items-center justify-center rounded-full transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed
            ${isVoiceRecording ? 'bg-red-500 hover:bg-red-600' : 'bg-blue-500 hover:bg-blue-600'} text-white`}
          onClick={handleVoiceButtonClick}
          disabled={isProcessing}
          title={isVoiceRecording ? t('stopVoiceChat') : t('startVoiceChat')}
          aria-label={isVoiceRecording ? t('stopVoiceChat') : t('startVoiceChat')}
        >
          <i className={`fas ${isVoiceRecording ? 'fa-microphone-slash' : 'fa-microphone'} text-sm`}></i>
        </button>

        <textarea
          ref={textareaRef}
          className="flex-1 min-h-[48px] max-h-[150px] overflow-y-auto custom-scrollbar p-3 pr-12 pl-12 border border-gray-300 rounded-3xl resize-none focus:outline-none focus:border-[var(--primary)] focus:shadow-[0_0_0_2px_rgba(16,163,127,0.1)] transition-all duration-200 text-right text-gray-800 disabled:bg-gray-50 disabled:opacity-70 disabled:cursor-not-allowed"
          placeholder={t('messageInputPlaceholder')}
          value={message}
          onChange={handleInputChange}
          onKeyPress={handleKeyPress}
          rows={1}
          disabled={isProcessing || isVoiceRecording} // Disable text input while voice recording
        />
        <button
          className="absolute left-2 bottom-2 w-9 h-9 flex items-center justify-center rounded-full bg-[var(--primary)] text-white transition-colors duration-200 hover:bg-[var(--secondary)] disabled:opacity-50 disabled:cursor-not-allowed"
          onClick={handleSendMessage}
          disabled={!message.trim() || isProcessing || isVoiceRecording}
          aria-label={t('sendMessage')}
        >
          <i className="fas fa-paper-plane text-sm"></i>
        </button>
      </div>
      {fileCount > 0 && (
        <div className="flex items-center gap-2 mt-2 mr-3 text-xs text-gray-600">
          <i className="fas fa-paperclip"></i>
          <span>{fileCount} {fileCount === 1 ? t('fileUploaded') : t('filesUploadedPlural')}</span>
        </div>
      )}
    </div>
  );
};

export default MessageInput;