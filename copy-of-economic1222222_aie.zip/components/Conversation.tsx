// Fix: Updated imports to use the newly defined DisplayMessage from '../types'
import React, { useRef, useEffect } from 'react';
import { DisplayMessage } from '../types';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';

interface ConversationProps {
  messages: DisplayMessage[]; // Fix: Use DisplayMessage type
  isTyping: boolean; // Indicates if a new response is actively being processed/streamed
}

const Conversation: React.FC<ConversationProps> = ({ messages, isTyping }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]); // Scroll whenever messages or typing status changes

  // Determine if the last message is an AI streaming message to show typing indicator
  // Fix: Check the isStreaming property on the DisplayMessage itself
  const lastMessage = messages[messages.length - 1];
  const showTypingIndicator = isTyping && lastMessage?.sender === 'ai' && lastMessage?.isStreaming;


  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-white custom-scrollbar">
      {messages.map((message) => (
        <MessageBubble key={message.id} message={message} />
      ))}
      {showTypingIndicator && <TypingIndicator />}
      <div ref={messagesEndRef} />
    </div>
  );
};

export default Conversation;