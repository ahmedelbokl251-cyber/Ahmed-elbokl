import React from 'react';
import { useLanguage } from '../LanguageContext';

const TypingIndicator: React.FC = () => {
  const { t } = useLanguage();
  return (
    <div className="flex w-full mb-6 mr-auto">
      <div className="flex items-center p-3 md:p-4 bg-[var(--ai-bubble)] text-gray-700 rounded-xl rounded-bl-sm border border-gray-200 shadow-sm">
        <div className="w-8 h-8 md:w-9 md:h-9 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center flex-shrink-0">
          <i className="fas fa-robot text-white text-xs md:text-sm"></i>
        </div>
        <div className="flex items-center mr-3">
            <span className="text-sm md:text-base text-gray-600 ml-2">{t('aiWrites')}</span>
            <div className="flex space-x-1.5 pt-1"> {/* Increased spacing and slight padding-top for alignment */}
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.15s' }}></div> {/* Adjusted delay */}
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></div>  {/* Adjusted delay */}
            </div>
        </div>
      </div>
    </div>
  );
};

export default TypingIndicator;