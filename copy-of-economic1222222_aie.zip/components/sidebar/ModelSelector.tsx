import React from 'react';
// Fix: Updated import to use the newly defined ChatModel from '../../types'
import { ChatModel } from '../../types';
import { MODEL_CONFIGS } from '../../constants';
import { useLanguage } from '../../LanguageContext';

interface ModelSelectorProps {
  currentModel: ChatModel;
  onModelChange: (model: ChatModel) => void;
  isProcessing: boolean;
}

const ModelSelector: React.FC<ModelSelectorProps> = ({ currentModel, onModelChange, isProcessing }) => {
  const { t, language } = useLanguage();
  return (
    <div className="bg-white rounded-lg p-4 mb-5 shadow-sm">
      <h3 className="font-semibold text-gray-700 mb-3">🤖 {t('availableModels')}</h3>
      <select
        className="w-full p-2.5 border border-gray-300 rounded-lg text-sm text-right disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:border-[var(--primary)] focus:ring-1 focus:ring-[var(--primary)]"
        value={currentModel}
        onChange={(e) => onModelChange(e.target.value as ChatModel)}
        disabled={isProcessing}
      >
        {Object.entries(MODEL_CONFIGS).map(([key, config]) => (
          <option key={key} value={key}>
            {config.name[language]}
          </option>
        ))}
      </select>
      <p className="text-xs text-gray-500 mt-2">{MODEL_CONFIGS[currentModel].description[language]}</p>
    </div>
  );
};

export default ModelSelector;