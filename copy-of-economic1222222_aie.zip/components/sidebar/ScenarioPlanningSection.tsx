// components/sidebar/ScenarioPlanningSection.tsx
import React, { useState, useCallback } from 'react';
import { useLanguage } from '../../LanguageContext';
import { StandardEconomicDataItem, Language } from '../../types'; // Updated to StandardEconomicDataItem
import { getCountryName, getIndicatorName } from '../../utils/helpers'; // Import getIndicatorName
import { REAL_DATA_SOURCES } from '../../constants';

interface ScenarioPlanningSectionProps {
  onAnalyzeScenario: (description: string, assumptions: string) => Promise<void>;
  isProcessing: boolean;
  fetchedEconomicData: StandardEconomicDataItem[] | null; // Updated type
  fetchedDataCountryCode: string | null;
  fetchedDataIndicatorCode: string | null;
}

const ScenarioPlanningSection: React.FC<ScenarioPlanningSectionProps> = ({
  onAnalyzeScenario,
  isProcessing,
  fetchedEconomicData,
  fetchedDataCountryCode,
  fetchedDataIndicatorCode,
}) => {
  const { t, language } = useLanguage();
  const [scenarioDescription, setScenarioDescription] = useState<string>('');
  const [scenarioAssumptions, setScenarioAssumptions] = useState<string>('');

  const handleAnalyzeClick = useCallback(async () => {
    if (!scenarioDescription.trim() || !scenarioAssumptions.trim()) {
      window.showNotification(t('scenarioDescriptionAndAssumptionsRequired'), 'warning');
      return;
    }
    await onAnalyzeScenario(scenarioDescription, scenarioAssumptions);
  }, [scenarioDescription, scenarioAssumptions, onAnalyzeScenario, t]);

  const hasRecentData = fetchedEconomicData && fetchedEconomicData.length > 0;
  let dataContextDescription = '';
  if (hasRecentData && fetchedDataCountryCode && fetchedDataIndicatorCode) {
    const countryName = getCountryName(fetchedDataCountryCode, language, t);
    // Assuming we have fetchedDataSourceId in App.tsx to pass here for correct indicator name lookup
    // For now, defaulting to worldbank if not explicitly passed
    const dataSourceId = fetchedEconomicData[0].source; // Get source from data itself
    const indicatorName = getIndicatorName(fetchedDataIndicatorCode, dataSourceId, language, t);

    dataContextDescription = t('consideringRecentEconomicData') + `: ${indicatorName} - ${countryName} (${fetchedEconomicData[0].year}-${fetchedEconomicData[fetchedEconomicData.length - 1].year}).`;
  }

  return (
    <div className="bg-white rounded-lg p-4 mb-5 shadow-sm">
      <h3 className="font-semibold text-gray-700 mb-3">🔮 {t('scenarioPlanning')}</h3>

      <div className="mb-3">
        <label htmlFor="scenario-description" className="block text-sm font-medium text-gray-700 mb-1">{t('scenarioDescriptionLabel')}</label>
        <textarea
          id="scenario-description"
          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm text-right focus:outline-none focus:border-[var(--primary)] focus:ring-1 focus:ring-[var(--primary)] disabled:opacity-50 disabled:cursor-not-allowed resize-y min-h-[80px]"
          placeholder={t('scenarioDescriptionPlaceholder')}
          value={scenarioDescription}
          onChange={(e) => setScenarioDescription(e.target.value)}
          disabled={isProcessing}
          aria-label={t('scenarioDescriptionLabel')}
        ></textarea>
      </div>

      <div className="mb-3">
        <label htmlFor="scenario-assumptions" className="block text-sm font-medium text-gray-700 mb-1">{t('scenarioAssumptionsLabel')}</label>
        <textarea
          id="scenario-assumptions"
          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm text-right focus:outline-none focus:border-[var(--primary)] focus:ring-1 focus:ring-[var(--primary)] disabled:opacity-50 disabled:cursor-not-allowed resize-y min-h-[80px]"
          placeholder={t('scenarioAssumptionsPlaceholder')}
          value={scenarioAssumptions}
          onChange={(e) => setScenarioAssumptions(e.target.value)}
          disabled={isProcessing}
          aria-label={t('scenarioAssumptionsLabel')}
        ></textarea>
      </div>

      {hasRecentData && (
        <p className="text-xs text-gray-600 mb-3 flex items-center gap-1">
          <i className="fas fa-info-circle text-blue-500"></i>
          {dataContextDescription}
        </p>
      )}

      <button
        className="w-full py-2.5 px-3 bg-[var(--primary)] text-white rounded-lg text-sm font-medium transition-colors duration-200 hover:bg-[var(--secondary)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        onClick={handleAnalyzeClick}
        disabled={isProcessing || !scenarioDescription.trim() || !scenarioAssumptions.trim()}
      >
        {isProcessing && <i className="fas fa-spinner fa-spin"></i>}
        <i className="fas fa-chart-pie"></i>
        {t('analyzeScenarioButton')}
      </button>
    </div>
  );
};

export default ScenarioPlanningSection;