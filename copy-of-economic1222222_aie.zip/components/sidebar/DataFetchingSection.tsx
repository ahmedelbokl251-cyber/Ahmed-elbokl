// components/sidebar/DataFetchingSection.tsx
import React, { useState, useEffect, useRef, useCallback } from 'react';
import flatpickr from 'flatpickr';
import { Arabic } from 'flatpickr/dist/l10n/ar';
import { AllApiStatus, DataFetchOptions, StandardEconomicDataItem, Language, MessageSender, NotificationProps, ApiStatus } from '../../types';
import { REAL_DATA_SOURCES } from '../../constants';
import { translations } from '../../translations';
import { formatNumber } from '../../utils/formatters';
import { fetchWorldBankData, checkWorldBankAPI, checkComtradeAPI, checkIMFAPI, fetchFREDData, checkFREDAPI } from '../../services/geminiService';
import { generateRealDataAnalysis } from '../../services/economicDataService';
import { useLanguage, Translator } from '../../LanguageContext'; // Import Translator
import { COUNTRIES } from '../../countries';
import { INDICATORS } from '../../indicators';
import { getCountryName, getIndicatorName, getUnitName, getTodayDateString, getFiveYearsAgoDateString } from '../../utils/helpers'; // Import new helpers

interface DataFetchingSectionProps {
  apiStatus: AllApiStatus;
  setApiStatus: React.Dispatch<React.SetStateAction<AllApiStatus>>;
  onDataFetch: (data: StandardEconomicDataItem[] | null, countryCode: string, indicatorCode: string, dataSource: string) => void;
  isProcessing: boolean;
  setIsProcessing: React.Dispatch<React.SetStateAction<boolean>>;
}

const DataFetchingSection: React.FC<DataFetchingSectionProps> = ({
  apiStatus,
  setApiStatus,
  onDataFetch,
  isProcessing,
  setIsProcessing,
}) => {
  const { t, language } = useLanguage();
  const [selectedCountryCode, setSelectedCountryCode] = useState('');
  const [selectedIndicatorCode, setSelectedIndicatorCode] = useState('');
  const [selectedDataSourceId, setSelectedDataSourceId] = useState<string>(REAL_DATA_SOURCES.worldbank.sourceId); // Default to World Bank
  const startDateRef = useRef<HTMLInputElement>(null);
  const endDateRef = useRef<HTMLInputElement>(null);
  const [dataPreview, setDataPreview] = useState<string | null>(dataPreviewPlaceholder(t, language)); // Initialize with placeholder

  // Helper function for placeholder to avoid re-rendering issues
  function dataPreviewPlaceholder(t: Translator, language: Language) {
    return `<div class="text-xs text-gray-700 text-center">${t('selectCountryAndIndicatorForPreview')}</div>`;
  }

  const updateDataPreview = useCallback(() => {
    const country = selectedCountryCode;
    const indicatorCode = selectedIndicatorCode;
    const dataSource = REAL_DATA_SOURCES[selectedDataSourceId];

    if (dataSource && indicatorCode && (selectedDataSourceId === REAL_DATA_SOURCES.fred.sourceId || country)) {
      const countryInfo = COUNTRIES.find(c => c.code === country);
      const indicatorInfo = INDICATORS.find(i => 
        (selectedDataSourceId === REAL_DATA_SOURCES.worldbank.sourceId && i.code === indicatorCode) || 
        (selectedDataSourceId === REAL_DATA_SOURCES.fred.sourceId && i.fredCode === indicatorCode)
      );

      if (indicatorInfo) {
        setDataPreview(`
          <div class="text-xs font-medium mb-2 text-gray-700">${t('dataPreview')}:</div>
          ${selectedDataSourceId === REAL_DATA_SOURCES.worldbank.sourceId && countryInfo ? `
          <div class="flex justify-between py-1 border-b border-gray-200">
              <span class="text-gray-600">${t('country')}:</span>
              <span class="font-medium">${countryInfo.name[language]}</span>
          </div>` : ''}
          <div class="flex justify-between py-1 border-b border-gray-200">
              <span class="text-gray-600">${t('indicator')}:</span>
              <span class="font-medium">${indicatorInfo.name[language]}</span>
          </div>
          <div class="flex justify-between py-1 border-b border-gray-200">
              <span class="text-gray-600">${t('unit')}:</span>
              <span class="font-medium">${indicatorInfo.unit[language]}</span>
          </div>
          <div class="flex justify-between py-1">
              <span class="text-gray-600">${t('source')}:</span>
              <span class="font-medium">${dataSource.name[language]}</span>
          </div>
        `);
      } else {
        setDataPreview(dataPreviewPlaceholder(t, language));
      }
    } else {
      setDataPreview(dataPreviewPlaceholder(t, language));
    }
  }, [selectedCountryCode, selectedIndicatorCode, selectedDataSourceId, language, t]);


  const initDatePickers = useCallback(() => {
    if (startDateRef.current) {
      flatpickr(startDateRef.current, {
        locale: language === 'ar' ? Arabic : 'en',
        dateFormat: 'Y-m-d',
        defaultDate: getFiveYearsAgoDateString(),
        maxDate: 'today',
        onClose: () => updateDataPreview(),
      });
    }
    if (endDateRef.current) {
      flatpickr(endDateRef.current, {
        locale: language === 'ar' ? Arabic : 'en',
        dateFormat: 'Y-m-d',
        defaultDate: getTodayDateString(),
        maxDate: 'today',
        onClose: () => updateDataPreview(),
      });
    }
  }, [language, updateDataPreview]);

  useEffect(() => {
    initDatePickers();
  }, [language, initDatePickers]);


  useEffect(() => {
    updateDataPreview();
  }, [selectedCountryCode, selectedIndicatorCode, selectedDataSourceId, updateDataPreview]);


  const handleFetchRealEconomicData = useCallback(async () => {
    const countryCode = selectedCountryCode;
    const indicatorCode = selectedIndicatorCode;
    const dataSourceId = selectedDataSourceId;
    const startDate = startDateRef.current?.value || '';
    const endDate = endDateRef.current?.value || '';

    if (!indicatorCode || !startDate || !endDate) {
      window.showNotification(t('pleaseSelectCountryAndIndicator'), 'warning');
      return;
    }

    // World Bank requires country code
    if (dataSourceId === REAL_DATA_SOURCES.worldbank.sourceId && !countryCode) {
      window.showNotification(t('pleaseSelectCountry'), 'warning');
      return;
    }

    // Check API status
    let status: ApiStatus;
    if (dataSourceId === REAL_DATA_SOURCES.worldbank.sourceId) {
      status = apiStatus.worldbank; // Use existing status from App.tsx
    } else if (dataSourceId === REAL_DATA_SOURCES.fred.sourceId) {
      status = apiStatus.fred; // Use existing status from App.tsx
    } else {
      status = { connected: false, message: t('unknownDataSource') };
    }

    if (!status.connected) {
      window.showNotification(t('apiConnectionUnavailable', { apiName: REAL_DATA_SOURCES[dataSourceId].name[language] }), 'error');
      return;
    }

    setIsProcessing(true);
    // Add a message indicating data fetching has started
    const temporaryMessageId = `ai-fetching-${Date.now()}`;
    window.showNotification(t('fetchingRealData'), 'info'); // Use global notification
    // onAddMessage('ai', t('fetchingRealData')); // This will be handled in App.tsx

    try {
      const dataOptions: DataFetchOptions = { countryCode, indicatorCode, startDate, endDate, dataSource: dataSourceId };
      let data: StandardEconomicDataItem[] = [];

      if (dataSourceId === REAL_DATA_SOURCES.worldbank.sourceId) {
        data = await fetchWorldBankData(countryCode, indicatorCode, startDate, endDate, t, language);
      } else if (dataSourceId === REAL_DATA_SOURCES.fred.sourceId) {
        data = await fetchFREDData(indicatorCode, startDate, endDate, t, language);
      }

      onDataFetch(data, countryCode, indicatorCode, dataSourceId); // Fix: Corrected typo from onDataFetched to onDataFetch

      if (data && data.length > 0) {
        // The analysis and message adding is now handled in App.tsx after onDataFetch
        window.showNotification(t('fetchedDataPoints', { count: data.length }), 'success');
      } else {
        window.showNotification(t('noDataFound'), 'warning');
      }
    } catch (error: any) {
      window.showNotification(t('failedToFetchData', { message: error.message }), 'error');
      // onAddMessage('ai', t('failedToFetchData', { message: error.message })); // Handled in App.tsx
    } finally {
      setIsProcessing(false);
    }
  }, [selectedCountryCode, selectedIndicatorCode, selectedDataSourceId, apiStatus, language, setIsProcessing, onDataFetch, t, updateDataPreview, startDateRef, endDateRef]); // Fix: Corrected typo from onDataFetched to onDataFetch

  const selectDataSource = (sourceKey: string) => {
    setSelectedDataSourceId(sourceKey);
    setSelectedIndicatorCode(''); // Reset indicator when source changes
    if (sourceKey === REAL_DATA_SOURCES.fred.sourceId) {
      setSelectedCountryCode(''); // Reset country code for FRED as it's often not country-specific
    }
    window.showNotification(t('sourceSelected', { sourceName: REAL_DATA_SOURCES[sourceKey].name[language] }), 'info');
  };

  const getStatusClasses = (status: ApiStatus) =>
    status.connected ? 'bg-green-500' : 'bg-red-500';

  return (
    <div className="bg-white rounded-lg p-4 mb-5 shadow-sm" role="group" aria-labelledby="real-economic-data-sources-heading">
      <h3 id="real-economic-data-sources-heading" className="font-semibold text-gray-700 mb-3">🌐 {t('realEconomicDataSources')}</h3>

      <div className="flex gap-2 mb-4" role="group" aria-label={t('dateRangeSelection')}>
        <label htmlFor="startDate" className="sr-only">{t('startDate')}</label>
        <input
          type="text"
          className="flex-1 p-2 border border-gray-300 rounded-lg text-sm text-right focus:outline-none focus:border-[var(--primary)] focus:ring-1 focus:ring-[var(--primary)]"
          id="startDate"
          placeholder={t('startDate')}
          ref={startDateRef}
          onChange={updateDataPreview}
          aria-label={t('startDate')}
          disabled={isProcessing}
        />
        <label htmlFor="endDate" className="sr-only">{t('endDate')}</label>
        <input
          type="text"
          className="flex-1 p-2 border border-gray-300 rounded-lg text-sm text-right focus:outline-none focus:border-[var(--primary)] focus:ring-1 focus:ring-[var(--primary)]"
          id="endDate"
          placeholder={t('endDate')}
          ref={endDateRef}
          onChange={updateDataPreview}
          aria-label={t('endDate')}
          disabled={isProcessing}
        />
      </div>

      {selectedDataSourceId === REAL_DATA_SOURCES.worldbank.sourceId && (
        <>
          <label htmlFor="country-selector" className="sr-only">{t('selectCountry')}</label>
          <select
            id="country-selector"
            className="w-full p-2.5 border border-gray-300 rounded-lg text-sm mb-3 text-right focus:outline-none focus:border-[var(--primary)] focus:ring-1 focus:ring-[var(--primary)] disabled:opacity-50 disabled:cursor-not-allowed"
            value={selectedCountryCode}
            onChange={(e) => setSelectedCountryCode(e.target.value)}
            disabled={isProcessing}
            aria-label={t('selectCountry')}
          >
            <option value="">{t('selectCountry')}</option>
            {COUNTRIES.map((country) => (
              <option key={country.code} value={country.code}>
                {country.name[language]}
              </option>
            ))}
          </select>
        </>
      )}


      <label htmlFor="indicator-selector" className="sr-only">{t('selectIndicator')}</label>
      <select
        id="indicator-selector"
        className="w-full p-2.5 border border-gray-300 rounded-lg text-sm mb-3 text-right focus:outline-none focus:border-[var(--primary)] focus:ring-1 focus:ring-[var(--primary)] disabled:opacity-50 disabled:cursor-not-allowed"
        value={selectedIndicatorCode}
        onChange={(e) => setSelectedIndicatorCode(e.target.value)}
        disabled={isProcessing}
        aria-label={t('selectIndicator')}
      >
        <option value="">{t('selectIndicator')}</option>
        {INDICATORS.filter(indicator => 
          (selectedDataSourceId === REAL_DATA_SOURCES.worldbank.sourceId && indicator.code) ||
          (selectedDataSourceId === REAL_DATA_SOURCES.fred.sourceId && indicator.fredCode)
        ).map((indicator) => (
          <option key={indicator.code + (indicator.fredCode || '')} value={selectedDataSourceId === REAL_DATA_SOURCES.worldbank.sourceId ? indicator.code : indicator.fredCode}>
            {indicator.name[language]} ({selectedDataSourceId === REAL_DATA_SOURCES.worldbank.sourceId ? indicator.code : indicator.fredCode})
          </option>
        ))}
      </select>

      <div
        className={`flex items-center justify-between p-3 mb-2 rounded-lg cursor-pointer transition-all duration-200 hover:bg-green-50
          ${selectedDataSourceId === REAL_DATA_SOURCES.worldbank.sourceId ? 'bg-green-100 border-r-4 border-[var(--primary)]' : 'bg-gray-50 border border-gray-200'}`}
        onClick={() => selectDataSource(REAL_DATA_SOURCES.worldbank.sourceId)}
        role="button"
        tabIndex={0}
        aria-label={REAL_DATA_SOURCES.worldbank.name[language]}
      >
        <div>
          <div className="font-medium text-sm text-gray-800">{REAL_DATA_SOURCES.worldbank.name[language]}</div>
          <div className="text-xs text-gray-500">{REAL_DATA_SOURCES.worldbank.description[language]}</div>
        </div>
        <div className="flex items-center gap-1">
          <div className={`w-2 h-2 rounded-full ${getStatusClasses(apiStatus.worldbank)}`}></div>
          <span className="text-xs text-gray-600">{apiStatus.worldbank.connected ? t('connected') : t('disconnected')}</span>
        </div>
      </div>

      <div
        className={`flex items-center justify-between p-3 mb-2 rounded-lg cursor-pointer transition-all duration-200 hover:bg-green-50
          ${selectedDataSourceId === REAL_DATA_SOURCES.fred.sourceId ? 'bg-green-100 border-r-4 border-[var(--primary)]' : 'bg-gray-50 border border-gray-200'}`}
        onClick={() => selectDataSource(REAL_DATA_SOURCES.fred.sourceId)}
        role="button"
        tabIndex={0}
        aria-label={REAL_DATA_SOURCES.fred.name[language]}
      >
        <div>
          <div className="font-medium text-sm text-gray-800">{REAL_DATA_SOURCES.fred.name[language]}</div>
          <div className="text-xs text-gray-500">{REAL_DATA_SOURCES.fred.description[language]}</div>
        </div>
        <div className="flex items-center gap-1">
          <div className={`w-2 h-2 rounded-full ${getStatusClasses(apiStatus.fred)}`}></div>
          <span className="text-xs text-gray-600">{apiStatus.fred.connected ? t('connected') : t('disconnected')}</span>
        </div>
      </div>

      <div
        className={`flex items-center justify-between p-3 mb-2 rounded-lg cursor-pointer transition-all duration-200 hover:bg-green-50
          ${selectedDataSourceId === REAL_DATA_SOURCES.imf.sourceId ? 'bg-green-100 border-r-4 border-[var(--primary)]' : 'bg-gray-50 border border-gray-200'}`}
        onClick={() => selectDataSource(REAL_DATA_SOURCES.imf.sourceId)}
        role="button"
        tabIndex={0}
        aria-label={REAL_DATA_SOURCES.imf.name[language]}
      >
        <div>
          <div className="font-medium text-sm text-gray-800">{REAL_DATA_SOURCES.imf.name[language]}</div>
          <div className="text-xs text-gray-500">{REAL_DATA_SOURCES.imf.description[language]}</div>
        </div>
        <div className="flex items-center gap-1">
          <div className={`w-2 h-2 rounded-full ${getStatusClasses(apiStatus.imf)}`}></div>
          <span className="text-xs text-gray-600">{apiStatus.imf.connected ? t('connected') : t('disconnected')}</span>
        </div>
      </div>

      <div
        className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all duration-200 hover:bg-green-50
          ${selectedDataSourceId === REAL_DATA_SOURCES.comtrade.sourceId ? 'bg-green-100 border-r-4 border-[var(--primary)]' : 'bg-gray-50 border border-gray-200'}`}
        onClick={() => selectDataSource(REAL_DATA_SOURCES.comtrade.sourceId)}
        role="button"
        tabIndex={0}
        aria-label={REAL_DATA_SOURCES.comtrade.name[language]}
      >
        <div>
          <div className="font-medium text-sm text-gray-800">{REAL_DATA_SOURCES.comtrade.name[language]}</div>
          <div className="text-xs text-gray-500">{REAL_DATA_SOURCES.comtrade.description[language]}</div>
        </div>
        <div className="flex items-center gap-1">
          <div className={`w-2 h-2 rounded-full ${getStatusClasses(apiStatus.comtrade)}`}></div>
          <span className="text-xs text-gray-600">{apiStatus.comtrade.connected ? t('connected') : t('disconnected')}</span>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-3 mt-4 max-h-40 overflow-y-auto custom-scrollbar text-gray-700 border border-gray-200">
        {dataPreview ? (
          <div dangerouslySetInnerHTML={{ __html: dataPreview }}></div>
        ) : (
          <div className="text-xs text-gray-500 text-center py-4">{t('selectCountryAndIndicatorForPreview')}</div>
        )}
      </div>

      <button
        className="w-full py-2.5 px-3 mt-3 bg-[var(--primary)] text-white rounded-lg text-sm font-medium transition-colors duration-200 hover:bg-[var(--secondary)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        onClick={handleFetchRealEconomicData}
        disabled={isProcessing}
      >
        {isProcessing && <i className="fas fa-spinner fa-spin"></i>}
        <i className="fas fa-download"></i>
        {t('fetchRealEconomicDataButton')}
      </button>

      <div className="flex items-center gap-1 text-xs text-gray-600 mt-3">
        <i className="fas fa-shield-alt text-green-600"></i>
        <span>{t('dataCredibility')}: <span className="text-green-600 font-medium">{t('credibilityHigh')}</span></span>
      </div>
    </div>
  );
};

export default DataFetchingSection;