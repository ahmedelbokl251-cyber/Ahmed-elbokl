
import React, { useState, useRef, useCallback, useMemo } from 'react';
// Fix: Updated import to use the newly defined UploadedFile from '../../types'
import { UploadedFile } from '../../types';
import { MAX_FILE_SIZE_BYTES, SUPPORTED_FILE_TYPES } from '../../constants';
import { formatFileSize } from '../../utils/formatters';
import { useLanguage } from '../../LanguageContext';

interface FileUploaderSectionProps {
  uploadedFiles: UploadedFile[];
  setUploadedFiles: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
  onAnalyzeFiles: () => void;
  isProcessing: boolean;
}

const FileUploaderSection: React.FC<FileUploaderSectionProps> = ({
  uploadedFiles,
  setUploadedFiles,
  onAnalyzeFiles,
  isProcessing,
}) => {
  const { t, language } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const [totalUploadProgress, setTotalUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState<boolean>(false);

  const handleFiles = useCallback(async (files: File[]) => {
    if (isUploading) {
      // Fix: Used window.showNotification correctly
      window.showNotification(t('alreadyUploading'), 'info');
      return;
    }
    setIsUploading(true);
    setTotalUploadProgress(0);

    const newFilesToAdd: UploadedFile[] = [];
    for (const file of files) {
      if (file.size > MAX_FILE_SIZE_BYTES) { // 10MB limit
        // Fix: Used window.showNotification correctly
        window.showNotification(t('fileTooLarge', { fileName: file.name, maxSize: formatFileSize(MAX_FILE_SIZE_BYTES, language, t) }), 'error');
        continue;
      }

      // Determine mimeType more robustly
      const fileExtension = file.name.split('.').pop()?.toLowerCase();
      const mimeType = file.type || (fileExtension ? (SUPPORTED_FILE_TYPES[fileExtension]?.mimeTypes[0] || 'application/octet-stream') : 'application/octet-stream');
      
      const supported = Object.values(SUPPORTED_FILE_TYPES).some(type =>
        type.mimeTypes.includes(mimeType) || (fileExtension && Object.keys(SUPPORTED_FILE_TYPES).includes(fileExtension))
      );

      if (!supported) {
        // Fix: Used window.showNotification correctly
        window.showNotification(t('fileTypeNotSupported', { fileName: file.name }), 'error');
        continue;
      }

      const fileId = `file_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      newFilesToAdd.push({ id: fileId, file, uploadTime: new Date(), analyzed: false, isUploading: true, uploadProgress: 0, mimeType });
    }

    if (newFilesToAdd.length > 0) {
      setUploadedFiles(prev => [...prev, ...newFilesToAdd]);
      
      // Simulate individual file upload progress and convert to Base64
      for (const fileObj of newFilesToAdd) {
        const interval = setInterval(() => {
          setUploadedFiles(prev => prev.map(f =>
            f.id === fileObj.id ? { ...f, uploadProgress: Math.min((f.uploadProgress || 0) + Math.random() * 20, 100) } : f
          ));
        }, 150);

        try {
          const base64Data = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
              if (typeof reader.result === 'string') {
                resolve(reader.result.split(',')[1]); // Get base64 part
              } else {
                reject(new Error(t('failedToReadFile')));
              }
            };
            reader.onerror = error => reject(error);
            reader.readAsDataURL(fileObj.file);
          });
          
          setUploadedFiles(prev => prev.map(f =>
            f.id === fileObj.id ? { ...f, base64: base64Data as string, isUploading: false, uploadProgress: 100 } : f
          ));
          // Fix: Used window.showNotification correctly
          window.showNotification(t('fileUploadedSuccess', { fileName: fileObj.file.name }), 'success');
        } catch (error: any) {
          console.error(`Failed to process file ${fileObj.file.name}:`, error);
          setUploadedFiles(prev => prev.map(f =>
            f.id === fileObj.id ? { ...f, isUploading: false, error: t('failedToUploadFile', { fileName: fileObj.file.name, message: error.message }), uploadProgress: 0 } : f
          ));
          // Fix: Used window.showNotification correctly
          window.showNotification(t('failedToUploadFile', { fileName: fileObj.file.name, message: error.message }), 'error');
        } finally {
          clearInterval(interval);
        }
      }
    }

    setIsUploading(false);
    setTotalUploadProgress(0); // Reset progress bar
  }, [setUploadedFiles, isUploading, t, language]);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(Array.from(e.target.files));
      e.target.value = ''; // Clear input to allow re-uploading same file
    }
  }, [handleFiles]);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  }, [handleFiles]);

  const removeFile = useCallback((fileId: string) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== fileId));
    // Fix: Used window.showNotification correctly
    window.showNotification(t('fileRemoved'), 'info');
  }, [setUploadedFiles, t]);

  const acceptedFileTypes = useMemo(() => {
    const mimeTypes = Object.values(SUPPORTED_FILE_TYPES).map(type => type.mimeTypes).flat();
    const extensions = Object.keys(SUPPORTED_FILE_TYPES).map(ext => `.${ext}`);
    return [...new Set([...mimeTypes, ...extensions])].join(',');
  }, []);

  return (
    <div className="bg-white rounded-lg p-4 mb-5 shadow-sm">
      <h3 className="font-semibold text-gray-700 mb-3">📁 {t('fileUploadAndAnalysis')}</h3>

      <div
        className={`border-2 border-dashed rounded-lg p-5 text-center cursor-pointer transition-all duration-200
          ${isDragOver ? 'border-[var(--primary)] bg-green-50 scale-[1.01]' : 'border-gray-300 bg-white hover:border-[var(--primary)] hover:bg-green-50'}
          ${isUploading || isProcessing ? 'opacity-60 cursor-not-allowed' : ''}`}
        onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        role="button"
        tabIndex={0}
        aria-label={t('dragAndDropFiles')}
      >
        <div className="flex flex-col items-center">
          <i className="fas fa-cloud-upload-alt text-3xl text-gray-400 mb-3"></i>
          <p className="font-medium text-gray-700">{t('dragAndDropFiles')}</p>
          <p className="text-sm text-gray-500 mt-1">{t('orClickToSelect')}</p>
          <p className="text-xs text-gray-400 mt-2">{t('supportedFileTypes')}</p>
        </div>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          multiple
          accept={acceptedFileTypes}
          onChange={handleFileChange}
          disabled={isUploading || isProcessing}
        />
      </div>

      {isUploading && (
        <div className="w-full h-1.5 bg-gray-200 rounded-full mt-3 overflow-hidden">
          <div
            className="h-full bg-[var(--primary)] transition-all duration-300 ease-out"
            style={{ width: `${totalUploadProgress}%` }}
          ></div>
        </div>
      )}

      <div className="mt-4 max-h-40 overflow-y-auto custom-scrollbar border border-gray-200 rounded-lg p-2 bg-gray-50">
        {uploadedFiles.length === 0 ? (
          <div className="text-center text-gray-500 text-sm py-4">{t('noFilesUploaded')}</div>
        ) : (
          uploadedFiles.map((fileObj) => {
            // Find specific FileTypeInfo based on mimeType
            const fileTypeInfo = Object.values(SUPPORTED_FILE_TYPES).find(type =>
              type.mimeTypes.some(mt => fileObj.mimeType.includes(mt))
            ) || SUPPORTED_FILE_TYPES['txt']; // Fallback to text file type
            
            return (
              <div key={fileObj.id} className="flex items-center justify-between p-2 bg-white rounded-md mb-2 shadow-sm border border-gray-200">
                <div className="flex items-center">
                  <div className="w-6 h-6 flex items-center justify-center ml-2 text-[var(--primary)]">
                    <i className={`fas ${fileTypeInfo.icon}`}></i>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <div className="font-medium text-sm text-gray-800 truncate">{fileObj.file.name}</div>
                    <div className="text-xs text-gray-500">
                      {formatFileSize(fileObj.file.size, language, t)} • {fileTypeInfo.name[language]}
                      {fileObj.isUploading && ` (${Math.round(fileObj.uploadProgress || 0)}%)`}
                      {fileObj.error && ` (${fileObj.error})`}
                    </div>
                  </div>
                </div>
                <button
                  className="w-7 h-7 flex items-center justify-center rounded-md text-red-500 hover:bg-red-50 transition-colors duration-200"
                  onClick={() => removeFile(fileObj.id)}
                  disabled={isProcessing || isUploading}
                  aria-label={t('removeFile')}
                >
                  <i className="fas fa-times text-sm"></i>
                </button>
              </div>
            );
          })
        )}
      </div>

      <button
        className="w-full py-2.5 px-3 mt-3 bg-[var(--primary)] text-white rounded-lg text-sm font-medium transition-colors duration-200 hover:bg-[var(--secondary)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        onClick={onAnalyzeFiles}
        disabled={uploadedFiles.filter(f => !f.error && !f.isUploading).length === 0 || isProcessing || isUploading}
      >
        {isProcessing && <i className="fas fa-spinner fa-spin"></i>}
        <i className="fas fa-chart-line"></i>
        {t('analyzeUploadedFilesButton')}
      </button>
    </div>
  );
};

export default FileUploaderSection;