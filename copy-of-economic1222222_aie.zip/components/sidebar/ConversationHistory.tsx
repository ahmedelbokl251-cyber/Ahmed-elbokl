// components/sidebar/ConversationHistory.tsx
import React, { useState } from 'react';
import { Conversation } from '../../types';
import { useLanguage } from '../../LanguageContext';

interface ConversationHistoryProps {
  conversations: Conversation[];
  currentConversationId: string | null;
  onLoadConversation: (id: string) => void;
  onDeleteConversation: (id: string) => void;
  onRenameConversation: (id: string, newTitle: string) => void;
  isProcessing: boolean;
}

const ConversationHistory: React.FC<ConversationHistoryProps> = ({
  conversations,
  currentConversationId,
  onLoadConversation,
  onDeleteConversation,
  onRenameConversation,
  isProcessing,
}) => {
  const { t } = useLanguage();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');

  const handleStartRename = (conv: Conversation) => {
    setEditingId(conv.id);
    setRenameValue(conv.title);
  };

  const handleCancelRename = () => {
    setEditingId(null);
    setRenameValue('');
  };

  const handleConfirmRename = (e: React.FormEvent, id: string) => {
    e.preventDefault();
    if (renameValue.trim()) {
      onRenameConversation(id, renameValue.trim());
    }
    handleCancelRename();
  };

  return (
    <div className="bg-white rounded-lg p-4 mb-5 shadow-sm">
      <h3 className="font-semibold text-gray-700 mb-3">🕒 {t('conversationHistory')}</h3>
      <div className="max-h-48 overflow-y-auto custom-scrollbar -mr-2 pr-2">
        {conversations.length > 0 ? (
          conversations.map((conv) => (
            <div
              key={conv.id}
              className={`group flex items-center justify-between p-2 rounded-lg cursor-pointer mb-1 transition-colors duration-200
                ${currentConversationId === conv.id ? 'bg-green-100 text-[var(--primary)] font-semibold' : 'hover:bg-gray-100'}`
              }
            >
              {editingId === conv.id ? (
                <form onSubmit={(e) => handleConfirmRename(e, conv.id)} className="flex-grow">
                  <input
                    type="text"
                    value={renameValue}
                    onChange={(e) => setRenameValue(e.target.value)}
                    onBlur={handleCancelRename}
                    autoFocus
                    className="w-full p-1 border border-[var(--primary)] rounded-md text-sm text-right focus:outline-none focus:ring-1 focus:ring-[var(--primary)]"
                    aria-label={t('enterNewName')}
                  />
                </form>
              ) : (
                <div 
                  className="flex-grow truncate text-sm"
                  onClick={() => !isProcessing && onLoadConversation(conv.id)}
                >
                  {conv.title}
                </div>
              )}
              {editingId !== conv.id && (
                <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <button
                    onClick={() => handleStartRename(conv)}
                    className="p-1 text-gray-500 hover:text-blue-600"
                    aria-label={t('renameChat')}
                    title={t('renameChat')}
                    disabled={isProcessing}
                  >
                    <i className="fas fa-pen text-xs"></i>
                  </button>
                  <button
                    onClick={() => onDeleteConversation(conv.id)}
                    className="p-1 text-gray-500 hover:text-red-600"
                    aria-label={t('deleteChat')}
                    title={t('deleteChat')}
                    disabled={isProcessing}
                  >
                    <i className="fas fa-trash text-xs"></i>
                  </button>
                </div>
              )}
            </div>
          ))
        ) : (
          <p className="text-sm text-gray-500 text-center">{t('noConversations')}</p>
        )}
      </div>
    </div>
  );
};

export default ConversationHistory;
