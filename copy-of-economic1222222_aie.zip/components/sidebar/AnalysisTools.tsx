import React from 'react';
// Fix: Updated imports to use the newly defined ToolType from '../../types'
import { ToolType, UploadedFile, ChatMessage } from '../../types';
import { ANALYSIS_TOOLS } from '../../constants';
import { useLanguage } from '../../LanguageContext';

interface AnalysisToolsProps {
  onToolClick: (type: ToolType) => void;
  isProcessing: boolean;
  uploadedFiles: UploadedFile[];
  conversationHistory: ChatMessage[];
}

const AnalysisTools: React.FC<AnalysisToolsProps> = ({ onToolClick, isProcessing, uploadedFiles, conversationHistory }) => {
  const { t, language } = useLanguage();
  const buttonClasses = "w-full py-2.5 px-3 bg-gray-50 border border-gray-200 rounded-lg text-right text-sm font-medium mb-2 transition-all duration-200 hover:bg-green-50 hover:border-[var(--primary)] hover:text-[var(--primary)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-end gap-2";

  // Context exists if there are uploaded files or if the conversation has more than the initial welcome message.
  const hasContext = uploadedFiles.filter(f => !f.error).length > 0 || conversationHistory.length > 1;

  // Tools that should be disabled without context
  const contextRequiredTools: ToolType[] = [
    ToolType.ECONOMIC_ANALYSIS,
    ToolType.INVESTMENT_CONSULTATION,
    ToolType.FORECAST,
    ToolType.STATISTICAL_TESTS,
    ToolType.VISUALIZATIONS,
    ToolType.SEARCH_EXTERNAL, // Search can also be considered context-free, but let's enable it for now.
  ];

  return (
    <div className="bg-white rounded-lg p-4 shadow-sm">
      <h3 className="font-semibold text-gray-700 mb-3">🛠️ {t('analysisTools')}</h3>
      {ANALYSIS_TOOLS.map((tool) => {
        const isContextRequired = contextRequiredTools.includes(tool.type);
        const isDisabled = isProcessing || (isContextRequired && !hasContext);

        // Specific override for SEARCH_EXTERNAL to always be enabled unless processing
        const finalDisabled = tool.type === ToolType.SEARCH_EXTERNAL ? isProcessing : isDisabled;

        return (
            <button
            key={tool.type}
            className={buttonClasses}
            onClick={() => onToolClick(tool.type)}
            disabled={finalDisabled}
            title={finalDisabled && !isProcessing ? t('noContextForAnalysis') : tool.description[language]}
            >
            <i className={`${tool.icon}`}></i>
            {tool.name[language]}
            </button>
        );
      })}
    </div>
  );
};

export default AnalysisTools;