import React, { useRef, useEffect } from 'react';
import { Chart, registerables } from 'chart.js';
import { ChartPart } from '../types';

Chart.register(...registerables); // Register all available Chart.js components

interface ChartComponentProps {
  chartPart: ChartPart;
}

const ChartComponent: React.FC<ChartComponentProps> = ({ chartPart }) => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (chartRef.current) {
      if (chartInstance.current) {
        chartInstance.current.destroy(); // Destroy existing chart before re-rendering
      }

      const ctx = chartRef.current.getContext('2d');
      if (ctx) {
        chartInstance.current = new Chart(ctx, {
          type: chartPart.chartType,
          data: chartPart.data,
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              title: {
                display: true,
                text: chartPart.title,
                font: {
                  size: 16
                }
              },
              legend: {
                display: chartPart.options?.plugins?.legend?.display ?? true,
                position: chartPart.options?.plugins?.legend?.position ?? 'top',
              },
              tooltip: {
                mode: chartPart.options?.plugins?.tooltip?.mode ?? 'index',
                intersect: chartPart.options?.plugins?.tooltip?.intersect ?? false,
              },
            },
            scales: chartPart.options?.scales,
            ...chartPart.options, // Spread other options
          },
        });
      }
    }

    // Cleanup function to destroy chart instance on component unmount
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
        chartInstance.current = null;
      }
    };
  }, [chartPart]); // Re-render chart if chartPart data changes

  return (
    <div style={{ height: '300px', width: '100%' }}> {/* Fixed height for chart */}
      <canvas ref={chartRef}></canvas>
    </div>
  );
};

export default ChartComponent;