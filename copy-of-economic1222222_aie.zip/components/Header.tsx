import React from 'react';
// Fix: Updated imports to use the newly defined types from '../types'
import { AllApiStatus, ChatModel, ApiStatus } from '../types';
import { MODEL_CONFIGS } from '../constants';
import { useLanguage } from '../LanguageContext';

interface HeaderProps {
  currentModel: ChatModel;
  apiStatus: AllApiStatus;
  onToggleSidebar: () => void;
}

const Header: React.FC<HeaderProps> = ({ currentModel, apiStatus, onToggleSidebar }) => {
  const { t, language } = useLanguage();
  const modelInfo = MODEL_CONFIGS[currentModel];
  
  // Fix: Explicitly cast values to ApiStatus to ensure 'connected' property is recognized
  const connectedAPIs = Object.values(apiStatus).filter((status: ApiStatus) => status.connected).length;
  const totalAPIs = Object.keys(apiStatus).length;

  let overallStatusClasses = 'bg-red-100 text-red-700';
  let overallStatusText = t('noActiveConnections');

  if (connectedAPIs === totalAPIs) {
    overallStatusClasses = 'bg-green-100 text-green-700';
    overallStatusText = t('allApisActive');
  } else if (connectedAPIs > 0) {
    overallStatusClasses = 'bg-yellow-100 text-yellow-700';
    overallStatusText = t('activeApisCount', { connected: connectedAPIs, total: totalAPIs });
  }

  return (
    <div className="flex items-center justify-between p-3 md:p-4 bg-white border-b border-gray-200 flex-shrink-0">
      <div className="flex items-center gap-2 md:gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 text-gray-600 hover:text-gray-900 md:hidden"
          aria-label={t('toggleSidebar')}
        >
          <i className="fas fa-bars text-xl"></i>
        </button>
        <div className="w-8 h-8 md:w-9 md:h-9 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center">
          <i className="fas fa-brain text-white text-sm md:text-base"></i>
        </div>
        <div>
          <h1 className="font-semibold text-gray-800 text-sm md:text-base">{t('appName')}</h1>
          <p className="text-xs text-gray-500 hidden sm:block">{t('appDescription')}</p>
        </div>
      </div>
      <div className="flex items-center gap-3 md:gap-4">
        <div className="text-left md:text-right hidden sm:block"> {/* Hide on extra small screens */}
          <div className="text-xs text-gray-500">{modelInfo.name[language]}</div>
          <div className="text-xs text-green-600">● {t('systemActive')}</div>
        </div>
        <div className={`real-api-status flex items-center gap-1 p-2 rounded-full text-xs font-medium ${overallStatusClasses}`}>
            <span dangerouslySetInnerHTML={{ __html: overallStatusText }}></span>
        </div>
      </div>
    </div>
  );
};

export default Header;