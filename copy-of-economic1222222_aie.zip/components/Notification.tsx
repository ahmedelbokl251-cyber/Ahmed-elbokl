import React, { useEffect, useState, useCallback } from 'react';
// Fix: Updated import to use the newly defined NotificationProps from '../types'
import { NotificationProps } from '../types';

interface NotificationState extends NotificationProps {
  id: string;
  isVisible: boolean; // New state to control CSS transition
}

const Notification: React.FC = () => {
  const [notifications, setNotifications] = useState<NotificationState[]>([]);

  // Function to show a new notification
  const showNotification = useCallback((message: string, type: 'success' | 'error' | 'warning' | 'info') => {
    const id = Date.now().toString();
    // Fix: NotificationState correctly extends NotificationProps, so message and type are known properties.
    // The previous error was a type system misunderstanding due to NotificationProps not being defined.
    const newNotification: NotificationState = { id, message, type, isVisible: false };

    setNotifications(prev => [...prev, newNotification]);

    // Show notification with a slight delay for CSS transition
    setTimeout(() => {
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, isVisible: true } : n));
    }, 100);

    // Notification disappears after 4 seconds (plus transition out time)
    setTimeout(() => {
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, isVisible: false } : n));
      // Remove from DOM after transition
      setTimeout(() => {
        setNotifications(prev => prev.filter(n => n.id !== id));
      }, 500); // Allow 500ms for transition-out
    }, 4000);
  }, []); // useCallback to memoize showNotification

  // Expose showNotification globally
  useEffect(() => {
    // Fix: Property 'showNotification' now exists on type 'Window & typeof globalThis' due to types.ts update
    window.showNotification = showNotification;
    return () => {
      // Clean up the global function when the component unmounts
      delete window.showNotification;
    };
  }, [showNotification]);

  return (
    <div className="fixed top-4 right-4 z-[1000] flex flex-col items-end space-y-3">
      {notifications.map(notification => (
        <div
          key={notification.id}
          className={`
            p-3 md:p-4 rounded-lg text-white text-sm shadow-xl min-w-[250px] max-w-[350px]
            transform transition-all duration-300 ease-out
            ${notification.isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}
            ${notification.type === 'success' ? 'bg-[var(--primary)]' : ''}
            ${notification.type === 'error' ? 'bg-red-600' : ''}
            ${notification.type === 'warning' ? 'bg-yellow-500' : ''}
            ${notification.type === 'info' ? 'bg-blue-500' : ''}
          `}
        >
          {notification.message}
        </div>
      ))}
    </div>
  );
};

export default Notification;