// components/FileUploadArea.tsx
import React, { useRef, useState, useCallback, useMemo, useEffect } from 'react';
// Fix: Updated imports to use the newly defined types from '../types'
import { UploadedFile, Language } from '../types';
import { useLanguage } from '../LanguageContext';
import { MAX_FILE_SIZE_BYTES, SUPPORTED_FILE_TYPES } from '../constants'; // Import new constants
import { formatFileSize } from '../utils/formatters';


interface FileUploadAreaProps {
  uploadedFiles: UploadedFile[];
  setUploadedFiles: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
  onFileDrop: (files: File[]) => void;
  removeFile: (fileId: string) => void;
  addNotification: (message: string, type: 'success' | 'error' | 'warning' | 'info') => void;
  isProcessing: boolean;
}

const FileUploadArea: React.FC<FileUploadAreaProps> = ({
  uploadedFiles,
  setUploadedFiles,
  onFileDrop,
  removeFile,
  addNotification,
  isProcessing,
}) => {
  const { t, language } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files.length > 0) {
      onFileDrop(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileDrop(Array.from(e.target.files));
      e.target.value = ''; // Clear input to allow re-uploading the same file
    }
  };

  const getFileIcon = useCallback((mimeType: string) => {
    // Find file type info by checking if mimeType includes any of the supported mimeTypes
    const fileTypeInfo = Object.values(SUPPORTED_FILE_TYPES).find(type =>
      type.mimeTypes.some(mt => mimeType.includes(mt))
    );
    return fileTypeInfo?.icon || 'fa-file';
  }, []);

  const totalUploadingProgress = useMemo(() => {
    if (uploadedFiles.length === 0 || !uploadedFiles.some(f => f.isUploading)) return 0;
    const uploadingFiles = uploadedFiles.filter(f => f.isUploading);
    const totalProgress = uploadingFiles.reduce((sum, file) => sum + (file.uploadProgress || 0), 0);
    return totalProgress / uploadingFiles.length;
  }, [uploadedFiles]);

  const hasUploadingFiles = useMemo(() => uploadedFiles.some(file => file.isUploading), [uploadedFiles]);

  return (
    <div className="model-section" role="group" aria-labelledby="file-upload-heading">
      <h3 id="file-upload-heading" className="font-semibold text-gray-800 mb-3">{t('fileUploadAndAnalysis')}</h3>

      <div
        className={`file-upload-area ${isDragOver ? 'dragover' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        role="button"
        tabIndex={0}
        aria-label={t('dragAndDropFiles')}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') fileInputRef.current?.click(); }}
      >
        <div className="file-upload-content">
          <i className="fas fa-cloud-upload-alt text-3xl text-gray-400 mb-3" aria-hidden="true"></i>
          <p className="font-medium text-gray-800">{t('dragAndDropFiles')}</p>
          <p className="text-sm text-gray-700 mt-1">{t('orClickToSelect')}</p>
          <p className="text-xs text-gray-600 mt-2">{t('supportedFileTypes')}</p>
        </div>
        {hasUploadingFiles && (
          <div className="file-upload-progress" style={{ display: 'block' }} role="progressbar" aria-valuenow={totalUploadingProgress} aria-valuemin={0} aria-valuemax={100} aria-label={t('uploadProgress')}>
            <div className="file-upload-progress-bar" style={{ width: `${totalUploadingProgress}%` }}></div>
          </div>
        )}
        <label htmlFor="file-input" className="sr-only">{t('selectFiles')}</label>
        <input
          type="file"
          id="file-input"
          className="file-input"
          multiple
          accept={Object.values(SUPPORTED_FILE_TYPES).map((type) => type.mimeTypes).flat().join(',')}
          onChange={handleFileInputChange}
          ref={fileInputRef}
          disabled={isProcessing}
        />
      </div>

      <div className="uploaded-files" role="region" aria-live="polite" aria-labelledby="uploaded-files-heading">
        <h4 id="uploaded-files-heading" className="sr-only">{t('uploadedFiles')}</h4>
        {uploadedFiles.length === 0 ? (
          <div className="text-center text-gray-700 text-sm py-4">{t('noFilesUploaded')}</div>
        ) : (
          uploadedFiles.map((fileObj) => {
            // Find specific FileTypeInfo based on mimeType
            const fileTypeInfo = Object.values(SUPPORTED_FILE_TYPES).find(type =>
              type.mimeTypes.some(mt => fileObj.mimeType.includes(mt))
            ) || SUPPORTED_FILE_TYPES['txt']; // Fallback to text file type

            return (
              <div className="file-item" key={fileObj.id} aria-label={`${t('file')} ${fileObj.file.name}`}>
                <div className="file-icon" aria-hidden="true">
                  <i className={`fas ${fileTypeInfo.icon}`}></i>
                </div>
                <div className="file-info">
                  <div className="file-name">{fileObj.file.name}</div>
                  <div className="file-size">
                    {formatFileSize(fileObj.file.size, language, t)}
                    {fileObj.isUploading && (
                      <span className="text-blue-500 mr-2"> ({Math.round(fileObj.uploadProgress || 0)}%)</span>
                    )}
                    {fileObj.error && (
                      <span className="text-red-500 mr-2"> ({fileObj.error})</span>
                    )}
                  </div>
                </div>
                <div className="file-actions">
                  <button
                    className="file-action-btn"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeFile(fileObj.id);
                    }}
                    title={t('fileRemoved')}
                    aria-label={`${t('removeFile')} ${fileObj.file.name}`}
                  >
                    <i className="fas fa-times text-red-500"></i>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default FileUploadArea;