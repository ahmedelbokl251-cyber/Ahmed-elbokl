import React from 'react';
import { INTELLECTUAL_PROPERTY_NOTICE } from '../constants';
import { useLanguage } from '../LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();
  return (
    <div className="flex-shrink-0 p-3 md:p-4 bg-gray-100 text-gray-600 text-xs text-center border-t border-gray-200">
      <p>{t(INTELLECTUAL_PROPERTY_NOTICE)}</p>
    </div>
  );
};

export default Footer;