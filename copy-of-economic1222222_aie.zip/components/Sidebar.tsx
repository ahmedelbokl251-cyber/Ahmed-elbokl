// components/Sidebar.tsx


import React from 'react';
import { ChatModel, AllApiStatus, UploadedFile, StandardEconomicDataItem, ToolType, ChatMessage, Conversation } from '../types';
import DataFetchingSection from './sidebar/DataFetchingSection';
import FileUploaderSection from './sidebar/FileUploaderSection';
import ModelSelector from './sidebar/ModelSelector';
import AnalysisTools from './sidebar/AnalysisTools';
import ScenarioPlanningSection from './sidebar/ScenarioPlanningSection'; // Import the new component
import ConversationHistory from './sidebar/ConversationHistory';
import { useLanguage } from '../LanguageContext';

interface SidebarProps {
  currentModel: ChatModel;
  onModelChange: (model: ChatModel) => void;
  apiStatus: AllApiStatus;
  setApiStatus: React.Dispatch<React.SetStateAction<AllApiStatus>>;
  uploadedFiles: UploadedFile[];
  setUploadedFiles: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
  onAnalyzeFiles: () => void;
  onNewChat: () => void;
  onDataFetch: (data: StandardEconomicDataItem[] | null, countryCode: string, indicatorCode: string, dataSource: string) => void;
  onToolClick: (type: ToolType) => void;
  isProcessing: boolean;
  setIsProcessing: React.Dispatch<React.SetStateAction<boolean>>;
  onAnalyzeScenario: (description: string, assumptions: string) => Promise<void>; // New prop
  fetchedEconomicData: StandardEconomicDataItem[] | null; // New prop
  fetchedDataCountryCode: string | null; // New prop
  fetchedDataIndicatorCode: string | null; // New prop
  onToggleSidebar: () => void;
  conversationHistory: ChatMessage[]; // New prop for context
  // Conversation History props
  conversations: Conversation[];
  currentConversationId: string | null;
  onLoadConversation: (id: string) => void;
  onDeleteConversation: (id: string) => void;
  onRenameConversation: (id: string, newTitle: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  currentModel,
  onModelChange,
  apiStatus,
  setApiStatus,
  uploadedFiles,
  setUploadedFiles,
  onAnalyzeFiles,
  onNewChat,
  onDataFetch,
  onToolClick,
  isProcessing,
  setIsProcessing,
  onAnalyzeScenario, // Destructure new prop
  fetchedEconomicData, // Destructure new prop
  fetchedDataCountryCode, // Destructure new prop
  fetchedDataIndicatorCode, // Destructure new prop
  onToggleSidebar,
  conversationHistory, // Destructure new prop
  // Conversation History props
  conversations,
  currentConversationId,
  onLoadConversation,
  onDeleteConversation,
  onRenameConversation,
}) => {
  const { t } = useLanguage();

  return (
    <div className="w-80 h-full bg-gray-50 border-r border-gray-200 p-4 overflow-y-auto custom-scrollbar flex-shrink-0 flex flex-col">
      <div className="flex items-center justify-between mb-5">
        <button
          className="py-3 bg-[var(--primary)] text-white rounded-lg font-medium transition-colors duration-200 hover:bg-[var(--secondary)] shadow-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 flex-grow"
          onClick={onNewChat}
          disabled={isProcessing}
        >
          <i className="fas fa-plus"></i>
          {t('newChatButton')}
        </button>
        <button
          onClick={onToggleSidebar}
          className="p-2 text-gray-500 hover:text-gray-800 md:hidden ml-2"
          aria-label={t('toggleSidebar')}
        >
          <i className="fas fa-times text-xl"></i>
        </button>
      </div>

      <ConversationHistory
        conversations={conversations}
        currentConversationId={currentConversationId}
        onLoadConversation={onLoadConversation}
        onDeleteConversation={onDeleteConversation}
        onRenameConversation={onRenameConversation}
        isProcessing={isProcessing}
      />

      <DataFetchingSection
        apiStatus={apiStatus}
        setApiStatus={setApiStatus}
        onDataFetch={onDataFetch}
        isProcessing={isProcessing}
        setIsProcessing={setIsProcessing}
      />

      <FileUploaderSection
        uploadedFiles={uploadedFiles}
        setUploadedFiles={setUploadedFiles}
        onAnalyzeFiles={onAnalyzeFiles}
        isProcessing={isProcessing}
      />

      <ModelSelector
        currentModel={currentModel}
        onModelChange={onModelChange}
        isProcessing={isProcessing}
      />

      <ScenarioPlanningSection
        onAnalyzeScenario={onAnalyzeScenario} // Pass new prop
        isProcessing={isProcessing}
        fetchedEconomicData={fetchedEconomicData} // Pass new prop
        fetchedDataCountryCode={fetchedDataCountryCode} // Pass new prop
        fetchedDataIndicatorCode={fetchedDataIndicatorCode} // Pass new prop
      />

      <AnalysisTools 
        onToolClick={onToolClick} 
        isProcessing={isProcessing}
        uploadedFiles={uploadedFiles}
        conversationHistory={conversationHistory}
      />
    </div>
  );
};

export default Sidebar;