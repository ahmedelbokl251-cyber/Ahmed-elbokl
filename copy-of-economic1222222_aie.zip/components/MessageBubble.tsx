import React from 'react';
// Fix: Updated imports to use the newly defined DisplayMessage and GroundingUrl from '../types'
import { DisplayMessage, GroundingUrl, TextPart, ImagePart, ChartPart } from '../types';
import MarkdownRenderer from './MarkdownRenderer';
import { useLanguage } from '../LanguageContext';
import ChartComponent from './ChartComponent'; // Import the new ChartComponent

interface MessageBubbleProps {
  message: DisplayMessage; // Fix: Use DisplayMessage type
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const { t, language } = useLanguage();
  const isUser = message.sender === 'user';
  const bubbleClasses = isUser
    ? 'bg-[var(--user-bubble)] text-white rounded-xl rounded-br-lg shadow-md' // Softer rounded corner
    : 'bg-[var(--ai-bubble)] text-gray-800 border border-gray-200 rounded-xl rounded-bl-lg shadow-sm'; // Softer rounded corner
  const messageAlignmentClasses = isUser ? 'ml-auto' : 'mr-auto';
  const avatarBg = isUser ? 'bg-blue-500' : 'bg-gradient-to-r from-green-500 to-green-600';
  const avatarIcon = isUser ? 'fas fa-user' : 'fas fa-robot';

  return (
    <div className={`flex w-full mb-6 ${messageAlignmentClasses}`}>
      <div className={`flex items-start gap-3 max-w-[85%] ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        {/* Avatar */}
        <div className={`w-8 h-8 md:w-9 md:h-9 ${avatarBg} rounded-full flex items-center justify-center flex-shrink-0 shadow-sm`}>
          <i className={`${avatarIcon} text-white text-xs md:text-sm`}></i>
        </div>

        {/* Message Content */}
        <div className={`p-3 md:p-4 ${bubbleClasses} flex flex-col`}>
          {!isUser && (
            <div className="flex items-center gap-2 mb-2">
              <span className="font-semibold text-gray-700 text-sm md:text-base">{t('appName')}</span>
            </div>
          )}
          {message.rawParts.map((part, index) => (
            <React.Fragment key={index}>
              {part.type === 'text' && (
                <MarkdownRenderer content={(part as TextPart).content} />
              )}
              {part.type === 'image' && (
                <img
                  src={`data:${(part as ImagePart).mimeType};base64,${(part as ImagePart).content}`}
                  alt="User Upload"
                  className="max-w-full h-auto rounded-lg mt-2 object-cover"
                />
              )}
              {part.type === 'chart' && (
                <div className="mt-4 p-2 bg-white rounded-lg shadow-inner">
                  <ChartComponent chartPart={part as ChartPart} />
                </div>
              )}
            </React.Fragment>
          ))}
          

          {message.groundingUrls && message.groundingUrls.length > 0 && (
            <div className="text-xs text-gray-600 mt-3 pt-2 border-t border-gray-200">
              <strong className="block mb-1 text-gray-700">{t('source')}:</strong>
              <ul className="list-disc pr-4 space-y-1">
                {message.groundingUrls.map((url, index) => (
                  <li key={index} className="truncate">
                    <a href={url.uri} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                      {url.title || new URL(url.uri).hostname}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className={`text-xs text-gray-400 mt-2 ${isUser ? 'text-left' : 'text-right'}`}>
            {message.timestamp.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', { hour: '2-digit', minute: '2-digit', hour12: true })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;