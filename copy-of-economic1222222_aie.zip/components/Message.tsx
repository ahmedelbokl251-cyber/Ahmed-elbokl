import React from 'react';
import { ChatMessage, MessageRole, TextPart, ImagePart, ChartPart } from '../types'; // Import all part types
import ChartComponent from './ChartComponent'; // Import the new ChartComponent

interface MessageProps {
  message: ChatMessage;
}

export const Message: React.FC<MessageProps> = ({ message }) => {
  const isUser = message.role === MessageRole.USER;
  const messageClass = isUser
    ? 'bg-blue-500 text-white self-end rounded-br-none'
    : 'bg-gray-200 text-gray-800 self-start rounded-bl-none';

  // Function to render markdown content using the globally available 'marked' library
  const renderMarkdown = (text: string) => {
    // Fix: Add a more robust runtime check for window.marked being a function
    if (typeof window.marked?.parse === 'function') { // Check if parse method exists
      // Marked.js produces HTML, which we inject safely.
      return { __html: window.marked.parse(text) };
    }
    // Fallback if marked.js is not loaded or not a function
    return { __html: `<p>${text}</p>` };
  };

  return (
    <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} break-words`}>
      <div
        className={`p-3 rounded-xl max-w-[80%] md:max-w-[70%] shadow-md ${messageClass}`}
      >
        {message.parts.map((part, index) => (
          <React.Fragment key={index}>
            {part.type === 'text' && (
              <div
                className="text-sm prose" // Tailwind Typography 'prose' class for basic markdown styling
                dangerouslySetInnerHTML={renderMarkdown((part as TextPart).content)}
              />
            )}
            {part.type === 'image' && (
              <img
                src={`data:${(part as ImagePart).mimeType};base64,${(part as ImagePart).content}`}
                alt="User Upload"
                className="max-w-full h-auto rounded-lg mt-2 object-cover"
              />
            )}
            {part.type === 'chart' && (
              <div className="mt-4 p-2 bg-white rounded-lg shadow-inner">
                <ChartComponent chartPart={part as ChartPart} />
              </div>
            )}
          </React.Fragment>
        ))}
        <div className="text-xs mt-1 opacity-75">
          {message.timestamp.toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
};