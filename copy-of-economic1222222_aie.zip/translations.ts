// Fix: Updated import to use the newly defined TranslatedString from './types'
import { TranslatedString } from './types';

export const translations: { [key: string]: TranslatedString } = {
  appName: { ar: 'Elbokl AI', en: 'Elbokl AI' },
  appDescription: { ar: 'تحليل اقتصادي، تنبؤ، وتخطيط سيناريوهات', en: 'Economic analysis, forecasting, & scenario planning' },
  newChatButton: { ar: 'محادثة جديدة', en: 'New Chat' },
  selectLanguage: { ar: 'اختر اللغة', en: 'Select Language' },
  toggleSidebar: { ar: 'تبديل الشريط الجانبي', en: 'Toggle Sidebar' },
  sidebar: { ar: 'الشريط الجانبي', en: 'Sidebar' },
  you: { ar: 'أنت', en: 'You' }, // For user messages sender name
  aiWrites: { ar: 'Elbokl AI يكتب', en: 'Elbokl AI is typing' },
  model: { ar: 'النموذج', en: 'Model' },

  basic: { ar: 'أساسي', en: 'Basic' },
  advanced: { ar: 'متقدم', en: 'Advanced' },
  strategic: { ar: 'استراتيجي', en: 'Strategic' },

  basicModelDescription: { ar: 'للاستفسارات العامة والمهام البسيطة', en: 'For general inquiries and simple tasks' },
  advancedModelDescription: { ar: 'لتحليل أعمق والمهام المعقدة', en: 'For deeper analysis and complex tasks' },
  strategicModelDescription: { ar: 'للتخطيط الاستراتيجي وصنع القرار', en: 'For strategic planning and decision-making' },

  availableModels: { ar: 'النماذج المتاحة', en: 'Available Models' },
  predictiveModelsAndScenarioPlanning: { ar: 'النماذج التنبؤية وتخطيط السيناريوهات', en: 'Predictive Models & Scenario Planning' },
  analysisTools: { ar: 'أدوات التحليل', en: 'Analysis Tools' },

  realEconomicDataSources: { ar: 'مصادر البيانات الاقتصادية الحقيقية', en: 'Real Economic Data Sources' },
  fetchingRealData: { ar: 'جلب البيانات الاقتصادية الحقيقية...', en: 'Fetching real economic data...' },
  pleaseSelectCountryAndIndicator: { ar: 'الرجاء اختيار الدولة والمؤشر.', en: 'Please select a country and an indicator.' },
  worldBankConnectionUnavailable: { ar: 'اتصال البنك الدولي غير متاح.', en: 'World Bank connection unavailable.' },
  failedToFetchData: { ar: 'فشل في جلب البيانات: {message}', en: 'Failed to fetch data: {message}' },
  fetchedDataPoints: { ar: 'تم جلب {count} نقطة بيانات', en: 'Fetched {count} data points' },
  dataPoints: { ar: 'نقطة بيانات', en: 'data points' },
  noDataFound: { ar: 'لم يتم العثور على بيانات', en: 'No data found' },
  source: { ar: 'المصدر', en: 'Source' },
  selected: { ar: 'تم الاختيار', en: 'Selected' },
  sourceSelected: { ar: 'المصدر {sourceName} تم اختياره.', en: 'Source {sourceName} selected.' },
  connected: { ar: 'متصل', en: 'Connected' },
  disconnected: { ar: 'غير متصل', en: 'Disconnected' },
  dataPreview: { ar: 'معاينة البيانات', en: 'Data Preview' },
  country: { ar: 'البلد', en: 'Country' },
  indicator: { ar: 'المؤشر', en: 'Indicator' },
  unit: { ar: 'الوحدة', en: 'Unit' },
  selectCountryAndIndicatorForPreview: { ar: 'اختر الدولة والمؤشر للمعاينة', en: 'Select country and indicator for preview' },
  fetchRealEconomicDataButton: { ar: 'جلب البيانات الاقتصادية الحقيقية', en: 'Fetch Real Economic Data' },
  dataCredibility: { ar: 'مصداقية البيانات', en: 'Data Credibility' },
  credibilityHigh: { ar: 'عالية', en: 'High' },
  selectCountry: { ar: 'اختر الدولة', en: 'Select Country' },
  selectIndicator: { ar: 'اختر المؤشر', en: 'Select Indicator' },
  startDate: { ar: 'تاريخ البدء', en: 'Start Date' },
  endDate: { ar: 'تاريخ الانتهاء', en: 'End Date' },
  httpStatusError: { ar: 'خطأ HTTP: {status} - {message}', en: 'HTTP Error: {status} - {message}' },
  invalidIndicatorOrCountry: { ar: 'مؤشر أو بلد غير صالح.', en: 'Invalid indicator or country.' },
  noDataFoundForAnalysis: { ar: 'لم يتم العثور على بيانات للتحليل.', en: 'No data found for analysis.' },
  notImplemented: { ar: '{apiName} API غير مدعوم حاليًا.', en: '{apiName} API not currently supported.' }, // New translation
  dateRangeSelection: { ar: 'تحديد النطاق الزمني', en: 'Date Range Selection' },
  worldBankDataSource: { ar: 'مصدر بيانات البنك الدولي', en: 'World Bank Data Source' },
  imfDataSource: { ar: 'مصدر بيانات صندوق النقد الدولي', en: 'IMF Data Source' },
  unComtradeDataSource: { ar: 'مصدر بيانات إحصائيات تجارة السلع للأمم المتحدة', en: 'UN Comtrade Data Source' },
  fredDataSource: { ar: 'مصدر بيانات الاحتياطي الفيدرالي', en: 'FRED Data Source' }, // New translation
  fredApiKeyMissing: { ar: 'مفتاح API الخاص بـ FRED مفقود. يرجى توفيره للوصول إلى البيانات.', en: 'FRED API Key is missing. Please provide it to access data.' }, // New translation
  invalidFredIndicatorCode: { ar: 'رمز مؤشر FRED غير صالح. يرجى اختيار رمز صحيح.', en: 'Invalid FRED indicator code. Please select a valid code.' }, // New translation
  unknownDataSource: { ar: 'مصدر بيانات غير معروف: {dataSource}.', en: 'Unknown data source: {dataSource}.' }, // New translation
  notApplicable: { ar: 'لا ينطبق', en: 'N/A' }, // New translation
  apiConnectionError: { ar: 'خطأ في اتصال API: {message}', en: 'API Connection Error: {message}' },
  apiKeyError: { ar: 'خطأ في مفتاح API. يرجى التأكد من اختيار مفتاح صالح.', en: 'API Key error. Please ensure a valid key is selected.' },
  quotaExceeded: { ar: 'تم تجاوز حصة API. يرجى التحقق من خطة الفواتير الخاصة بك أو المحاولة لاحقًا.', en: 'API quota exceeded. Please check your billing plan or try again later.' },
  quotaExceededDetails: { ar: 'تم تجاوز حصة API. قد تحتاج إلى ترقية خطة Gemini API أو الانتظار حتى تتم إعادة تعيين الحصة. حاول تحديد مفتاح API الخاص بك مرة أخرى.', en: 'API quota exceeded. You might need to upgrade your Gemini API plan or wait for the quota to reset. Try re-selecting your API key.' },
  learnMore: { ar: 'تعلم المزيد', en: 'Learn more' },


  fileUploadAndAnalysis: { ar: 'تحميل وتحليل الملفات', en: 'File Upload & Analysis' },
  fileUploadedSuccess: { ar: 'تم تحميل الملف بنجاح', en: 'File uploaded successfully' },
  fileRemoved: { ar: 'تمت إزالة الملف', en: 'File removed' },
  failedToUploadFile: { ar: 'فشل تحميل الملف {fileName}: {message}', en: 'Failed to upload file {fileName}: {message}' },
  fileTooLarge: { ar: 'حجم الملف كبير جداً: {fileName} (الحد الأقصى {maxSize})', en: 'File size too large: {fileName} (Max {maxSize})' },
  fileTypeNotSupported: { ar: 'نوع الملف غير مدعوم: {fileName}', en: 'File type not supported: {fileName}' },
  noFilesToAnalyze: { ar: 'لا توجد ملفات لتحليلها', en: 'No files to analyze' },
  filesAnalyzedSuccess: { ar: 'تم تحليل الملفات بنجاح.', en: 'Files analyzed successfully.' },
  failedToAnalyzeFiles: { ar: 'فشل تحليل الملفات: {message}', en: 'Failed to analyze files: {message}' },
  file: { ar: 'ملف', en: 'File' }, // For generic file type
  dragAndDropFiles: { ar: 'اسحب وأفلت الملفات هنا', en: 'Drag and drop files here', },
  orClickToSelect: { ar: 'أو انقر للاختيار', en: 'Or click to select' },
  supportedFileTypes: { ar: 'الأنواع المدعومة: PDF, CSV, Excel, Images, Text', en: 'Supported types: PDF, CSV, Excel, Images, Text' },
  noFilesUploaded: { ar: 'لم يتم تحميل أي ملفات', en: 'No files uploaded yet' },
  analyzeUploadedFilesButton: { ar: 'تحليل الملفات المحملة', en: 'Analyze Uploaded Files' },
  fileUploaded: { ar: 'ملف تم تحميله', en: 'file uploaded' },
  filesUploadedPlural: { ar: 'ملفات تم تحميلها', en: 'files uploaded' },
  uploadProgress: { ar: 'تقدم التحميل', en: 'Upload Progress' },
  selectFiles: { ar: 'اختر الملفات', en: 'Select files' },
  removeFile: { ar: 'إزالة الملف', en: 'Remove file' },
  uploadedFiles: { ar: 'الملفات المحملة', en: 'Uploaded Files' },
  fileAnalysisPrompt: {
    ar: `بصفتك محللاً اقتصاديًا خبيرًا، قم بتحليل الملفات المرفقة (بما في ذلك {numberOfFiles} ملفات: {fileNames}).
  قدم نظرة عامة على محتواها، واستخلص أي رؤى اقتصادية ذات صلة، وقدم توصيات أولية.
  تأكد من أن الاستجابة باللغة {language}.`,
    en: `As an expert economic analyst, analyze the attached files (including {numberOfFiles} files: {fileNames}).
  Provide an overview of their content, extract any relevant economic insights, and offer initial recommendations.
  Ensure the response is in {language}.`,
  },
  fileAnalyzedByGemini: { ar: 'تم التحليل بواسطة Elbokl AI', en: 'Analyzed by Elbokl AI' },
  unsupportedFileTypeForDirectAnalysis: { ar: 'هذا النوع من الملفات غير مدعوم للتحليل المباشر بواسطة Gemini. سيتم تضمين اسمه كمرجع نصي فقط.', en: 'This file type is not supported for direct multimodal analysis by Gemini. Its name will be included as a text reference only.' }, // New translation
  excelFileWarning: { ar: 'تحذير: ملفات Excel/CSV غير مدعومة للتحليل المباشر كبيانات منظمة بواسطة Gemini. سيتم تحليلها كمحتوى نصي. لنتائج أفضل، يرجى استخلاص البيانات الرئيسية أو تحويلها إلى نص قبل التحميل إذا أمكن.', en: 'Warning: Excel/CSV files are not supported for direct structured data analysis by Gemini. They will be analyzed as text content. For better results, please extract key data or convert to plain text if possible before uploading.' }, // New translation


  promptEconomicAnalysis: { ar: 'بصفتك محللاً اقتصاديًا خبيرًا، قدم تحليلًا اقتصاديًا سريعًا بناءً على السياق المقدم (والذي قد يتضمن ملفات مرفقة، سجل محادثة، وبيانات في الوقت الفعلي).', en: 'As an expert economic analyst, provide a quick economic analysis based on the provided context (which may include attached files, conversation history, and real-time data).' },
  promptInvestmentConsultation: { ar: 'بصفتك مستشارًا استثماريًا، قدم توصيات استثمارية بناءً على السياق المقدم (والذي قد يتضمن ملفات مرفقة، سجل محادثة، وبيانات في الوقت الفعلي).', en: 'As an investment consultant, provide investment recommendations based on the provided context (which may include attached files, conversation history, and real-time data).' },
  promptForecastWithContext: { ar: 'بصفتك محللاً اقتصاديًا، قدم توقعات للاتجاهات الاقتصادية بناءً على السياق المقدم (والذي قد يتضمن ملفات مرفقة، سجل محادثة، وبيانات في الوقت الفعلي).', en: 'As an economic analyst, provide a forecast of economic trends based on the provided context (which may include attached files, conversation history, and real-time data).' },
  promptStatisticalTestsWithContext: { ar: 'بناءً على السياق المقدم، صف الاختبارات الإحصائية (مثل تحليل الانحدار، اختبار الفرضيات) التي ستكون مناسبة. اشرح ما سيكشفه كل اختبار. لا تقم بتنفيذ العمليات الحسابية، فقط صف المنهجية.', en: 'Based on the provided context, describe which statistical tests (e.g., regression analysis, hypothesis testing) would be appropriate. Explain what each test would reveal. Do not perform the calculations, just describe the methodology.' },
  promptVisualizationsWithContext: { ar: 'بناءً على السياق المقدم، صف تصورات البيانات الأكثر فعالية (مثل الرسوم البيانية الشريطية، الرسوم البيانية الخطية) التي يمكن إنشاؤها. اشرح ما سيعرضه كل تصور. لا تحاول إنشاء رمز أو صورة فعلية، فقط صفها.', en: 'Based on the provided context, describe the most effective data visualizations (e.g., bar charts, line graphs) that could be created. Explain what each visualization would show. Do not attempt to generate code or an actual image, just describe them.' },
  noContextForAnalysis: { ar: 'يرجى تحميل ملف أو بدء محادثة لاستخدام أدوات التحليل.', en: 'Please upload a file or start a conversation to use the analysis tools.' },
  searchExternalPrompt: { ar: 'ابحث في الويب عن أحدث الأخبار والتقارير الاقتصادية.', en: 'Search the web for the latest economic news and reports.' },
  searchExternalSources: { ar: 'البحث في المصادر الخارجية', en: 'Search external sources' },
  statisticalTestsResponse: { ar: 'جاري تنفيذ الاختبارات الإحصائية...', en: 'Executing statistical tests...' },
  visualizationsResponse: { ar: 'جاري إنشاء تصورات للبيانات...', en: 'Generating data visualizations...' },
  generalAiResponseTitle: { ar: 'رد Elbokl AI', en: 'Elbokl AI Response' },
  confirmNewChat: { ar: 'هل أنت متأكد أنك تريد بدء محادثة جديدة؟ سيتم مسح المحادثة الحالية.', en: 'Are you sure you want to start a new chat? The current conversation will be cleared.' },
  switchModelSuccess: { ar: 'تم التبديل إلى النموذج {modelName} بنجاح', en: 'Switched model successfully to {modelName}' },
  anErrorOccurred: { ar: 'حدث خطأ: {message}', en: 'An error occurred: {message}' },
  errorInQuickAnalysis: { ar: 'خطأ في التحليل السريع: {message}', en: 'Error in quick analysis: {message}' },
  exportConversationSuccess: { ar: 'تم تصدير المحادثة بنجاح.', en: 'Conversation exported successfully.' },
  searchExternalResponse: { ar: 'جاري البحث في المصادر الخارجية...', en: 'Searching external sources...' },
  conversationHistory: { ar: 'سجل المحادثات', en: 'Conversation History' },

  // Economic Data Analysis strings
  realDataAnalysis: { ar: '**تحليل البيانات الاقتصادية الحقيقية**', en: '**Real Economic Data Analysis**' }, // Changed title
  sourceInformation: { ar: 'معلومات المصدر:', en: 'Source Information:' },
  period: { ar: 'الفترة', en: 'Period' },
  numberOfDataPoints: { ar: 'عدد نقاط البيانات', en: 'Number of Data Points' },
  basicStatistics: { ar: 'الإحصائيات الأساسية', en: 'Basic Statistics' },
  latestValue: { ar: 'أحدث قيمة', en: 'Latest Value' },
  average: { ar: 'المتوسط', en: 'Average' },
  maximum: { ar: 'الحد الأقصى', en: 'Maximum' },
  minimum: { ar: 'الحد الأدنى', en: 'Minimum' },
  trend: { ar: 'الاتجاه', en: 'Trend' },
  yearCol: { ar: 'السنة', en: 'Year' },
  valueCol: { ar: 'القيمة', en: 'Value' },
  // Fix: Corrected localization error in English translation.
  dataSample: { ar: 'عينة البيانات (آخر 5 سنوات)', en: 'Data Sample (last 5 years)' },
  analyticalInsights: { ar: 'رؤى تحليلية', en: 'Analytical Insights' },
  trustedSource: { ar: 'مصدر موثوق', en: 'Trusted Source' },
  // specific insights
  latestDataFor: { ar: 'أحدث البيانات لمؤشر {indicator} في {country} هي {value} في عام {year}.', en: 'The latest data for {indicator} in {country} is {value} in {year}.' },
  performanceChange: { ar: 'تغير الأداء بنسبة {change}%، مما يشير إلى {status}.', en: 'Performance changed by {change}%, indicating a {status}.' },
  improvement: { ar: 'تحسن', en: 'improvement' },
  decline: { ar: 'تدهور', en: 'decline' },
  overallTrend: { ar: 'الاتجاه العام خلال الفترة {period} هو {trend}.', en: 'The overall trend during {period} is {trend}.' },
  currentValueComparison: { ar: 'القيمة الحالية {valueStatus} من المتوسط التاريخي.', en: 'The current value is {valueStatus} than the historical average.' },
  higher: { ar: 'أعلى', en: 'higher' },
  lower: { ar: 'أقل', en: 'lower' },
  // trends
  stable: { ar: 'مستقر', en: 'stable' },
  upward: { ar: 'صعودي', en: 'upward' },
  strongUpward: { ar: 'صعودي قوي', en: 'strong upward' },
  downward: { ar: 'هبوطي', en: 'downward' },
  strongDownward: { ar: 'هبوطي قوي', en: 'strong downward' },
  // recommendations
  continueCurrentGrowthPolicies: { ar: 'يوصى بالاستمرار في سياسات النمو الحالية.', en: 'Recommended to continue current growth policies.' },
  stimulusPoliciesNeeded: { ar: 'قد تكون هناك حاجة إلى سياسات تحفيزية لتعزيز النمو.', en: 'Stimulus policies may be needed to boost growth.' },
  monitorInflationActions: { ar: 'يجب مراقبة التضخم واتخاذ إجراءات احترازية.', en: 'Inflation should be monitored and precautionary measures taken.' },
  inflationAcceptable: { ar: 'مستويات التضخم مقبولة.', en: 'Inflation levels are acceptable.' },
  employmentProgramsNeeded: { ar: 'هناك حاجة لبرامج لتعزيز التوظيف وتقليل البطالة.', en: 'Employment programs are needed to boost employment and reduce unemployment.' },
  unemploymentAcceptable: { ar: 'معدل البطالة مقبولة.', en: 'Unemployment levels are acceptable.' },
  monitorContinuously: { ar: 'مراقبة مستمرة مطلوبة.', en: 'Continuous monitoring is required.' },
  notEnoughDataForInsights: { ar: 'لا توجد بيانات كافية لتقديم رؤى لمؤشر {indicator} في {country}.', en: 'Not enough data available to provide insights for {indicator} in {country}.' }, // New translation
  noDataForRecommendations: { ar: 'لا توجد بيانات متاحة لتقديم توصيات.', en: 'No data available to provide recommendations.' }, // New translation
  highInterestRatesImpact: { ar: 'أسعار الفائدة المرتفعة قد تؤثر على الاستثمار والنمو الاقتصادي.', en: 'High interest rates may impact investment and economic growth.' }, // New translation
  lowInterestRatesBenefit: { ar: 'أسعار الفائدة المنخفضة يمكن أن تحفز الاقتراض والاستثمار.', en: 'Low interest rates can stimulate borrowing and investment.' }, // New translation
  boostExportsPolicies: { ar: 'يوصى بتعزيز سياسات دعم الصادرات لتحقيق نمو أكبر.', en: 'Policies supporting exports are recommended for further growth.' }, // New translation
  reviewTradePolicies: { ar: 'يجب مراجعة السياسات التجارية لتحسين أداء الصادرات.', en: 'Trade policies should be reviewed to improve export performance.' }, // New translation
  encourageLocalProduction: { ar: 'زيادة الواردات قد تتطلب تشجيع الإنتاج المحلي لتقليل الاعتماد الخارجي.', en: 'Increased imports might require encouraging local production to reduce external reliance.' }, // New translation
  balanceImports: { ar: 'يجب الحفاظ على توازن في الواردات لتجنب التأثيرات السلبية على الاقتصاد المحلي.', en: 'Imports should be kept balanced to avoid negative impacts on the local economy.' }, // New translation


  // File Analysis strings
  fileAnalysisTitle: { ar: '**تحليل الملفات المحملة**', en: '**Uploaded Files Analysis**' },
  analyzedFiles: { ar: 'الملفات التي تم تحليلها:', en: 'Analyzed Files:' },
  analysisStatistics: { ar: 'إحصائيات التحليل', en: 'Analysis Statistics' },
  numberOfFiles: { ar: 'عدد الملفات', en: 'Number of Files' },
  fileTypes: { ar: 'أنواع الملفات', en: 'File Types' },
  totalDataSize: { ar: 'الحجم الكلي للبيانات', en: 'Total Data Size' },
  totalAnalyzedRows: { ar: 'إجمالي الصفوف التي تم تحليلها', en: 'Total Analyzed Rows' },
  insightsExtracted: { ar: 'الرؤى المستخلصة', en: 'Insights Extracted' },
  dataQuality: { ar: 'جودة البيانات', en: 'Data Quality' },
  dataCompleteness: { ar: 'اكتمال البيانات', en: 'Data Completeness' },
  dataConsistency: { ar: 'اتساق البيانات', en: 'Data Consistency' },
  recommendationsText: { ar: 'توصيات', en: 'Recommendations' }, // Renamed to avoid conflict with `recommendations` key for insights
  fileAnalysisDisclaimer: { ar: 'يستند هذا التحليل إلى البيانات المتاحة وتم إنشاؤه بواسطة الذكاء الاصطناعي في', en: 'This analysis is based on available data and generated by AI on' },

  // Forecasting
  selectPredictiveModel: { ar: 'اختر النموذج التنبؤي', en: 'Select Predictive Model' },
  runForecastButton: { ar: 'تشغيل التنبؤ', en: 'Run Forecast' },
  runningForecasts: { ar: 'جاري تشغيل التنبؤات باستخدام {modelType}...', en: 'Running forecasts using {modelType}...' },
  forecastsGenerated: { ar: 'تم إنشاء التنبؤات بنجاح.', en: 'Forecasts generated successfully.' },
  failedToGenerateForecasts: { ar: 'فشل في إنشاء التنبؤات: {message}', en: 'Failed to generate forecasts: {message}' },
  noPromptForForecast: { ar: 'يرجى جلب بعض البيانات الاقتصادية أولاً لإنشاء التنبؤ.', en: 'Please fetch some economic data first to generate a forecast.' },
  forecastPrompt: {
    ar: `بصفتك محللاً اقتصاديًا، باستخدام نموذج {modelType}، قم بتحليل البيانات الاقتصادية التالية لمؤشر {indicator} في {country}، ثم قم بالتنبؤ بالقيم المستقبلية وتوضيح الاتجاهات الرئيسية. قدم تحليلًا مفصلاً والتنبؤات للسنوات الخمس القادمة. البيانات هي: \`\`\`json\n{data}\n\`\`\`
  تأكد من أن الاستجابة باللغة {language}.`,
    en: `As an economic analyst, using the {modelType} model, analyze the following economic data for the {indicator} indicator in {country}, then predict future values and explain key trends. Provide a detailed analysis and forecasts for the next five years. The data is: \`\`\`json\n{data}\n\`\`\`
  Ensure the response is in {language}.`,
  },

  // Scenario Planning
  scenarioPlanning: { ar: 'تخطيط السيناريوهات', en: 'Scenario Planning' },
  scenarioDescriptionLabel: { ar: 'وصف السيناريو', en: 'Scenario Description' },
  scenarioDescriptionPlaceholder: { ar: 'صف السيناريو الاقتصادي الذي ترغب في تحليله (على سبيل المثال: ارتفاع أسعار النفط العالمية).', en: 'Describe the economic scenario you want to analyze (e.g., global oil price surge).' },
  scenarioAssumptionsLabel: { ar: 'الافتراضات', en: 'Assumptions' },
  scenarioAssumptionsPlaceholder: { ar: 'اذكر الافتراضات الرئيسية للسيناريو (على سبيل المثال: ارتفاع بنسبة 20% في أسعار النفط لمدة عام).', en: 'State key assumptions for the scenario (e.g., 20% increase in oil prices for one year).' },
  analyzeScenarioButton: { ar: 'تحليل السيناريو', en: 'Analyze Scenario' },
  consideringRecentEconomicData: { ar: 'بالنظر إلى البيانات الاقتصادية الحديثة', en: 'Considering recent economic data' },
  scenarioAnalysisPrompt: {
    ar: `أنت محلل اقتصادي خبير. قم بتحليل السيناريو التالي بناءً على الوصف والافتراضات المقدمة.
  وصف السيناريو: {description}
  الافتراضات: {assumptions}
  {dataContext}
  قدم تحليلاً شاملاً للتأثيرات المحتملة على الاقتصاد الكلي، القطاعات الرئيسية، والتوصيات الاستراتيجية.
  تأكد من أن الاستجابة باللغة {language}.`,
    en: `You are an expert economic analyst. Analyze the following scenario based on the provided description and assumptions.
  Scenario Description: {description}
  Assumptions: {assumptions}
  {dataContext}
  Provide a comprehensive analysis of the potential impacts on the macroeconomy, key sectors, and strategic recommendations.
  Ensure the response is in {language}.`,
  },
  scenarioAnalyzed: { ar: 'تم تحليل السيناريو بنجاح.', en: 'Scenario analyzed successfully.' },
  failedToAnalyzeScenario: { ar: 'فشل تحليل السيناريو: {message}', en: 'Failed to analyze scenario: {message}' },
  scenarioDescriptionAndAssumptionsRequired: { ar: 'وصف السيناريو والافتراضات مطلوبة للتحليل.', en: 'Scenario description and assumptions are required for analysis.' },
  analyzingScenario: { ar: 'جاري تحليل السيناريو', en: 'Analyzing scenario' }, // New translation for scenario processing

  // Saved Scenarios
  manageSavedScenarios: { ar: 'إدارة السيناريوهات المحفوظة', en: 'إدارة السيناريوهات المحفوظة' },
  saveCurrentScenarioButton: { ar: 'حفظ السيناريو الحالي', en: 'Save Current Scenario' },
  enterScenarioName: { ar: 'أدخل اسمًا للسيناريو:', en: 'Enter a name for the scenario:' },
  scenarioSaved: { ar: 'تم حفظ السيناريو', en: 'Scenario saved' },
  selectSavedScenario: { ar: 'اختر سيناريو محفوظ', en: 'Select a saved scenario' },
  loadScenarioButton: { ar: 'تحميل السيناريو', en: 'Load Scenario' },
  deleteScenarioButton: { ar: 'حذف السيناريو', en: 'Delete Scenario' },
  noScenarioSelectedToLoad: { ar: 'لم يتم اختيار سيناريو لتحميله.', en: 'No scenario selected to load.' },
  scenarioLoaded: { ar: 'تم تحميل السيناريو', en: 'Scenario loaded' },
  noScenarioSelectedToDelete: { ar: 'لم يتم اختيار سيناريو لحذفه.', en: 'No scenario selected to delete.' },
  confirmDeleteScenario: { ar: 'هل أنت متأكد أنك تريد حذف السيناريو "{name}"؟', en: 'Are you sure you want to delete scenario "{name}"?' },
  scenarioDeleted: { ar: 'تم حذف السيناريو', en: 'Scenario deleted' },

  // Other UI texts
  messageInputPlaceholder: { ar: 'اطرح سؤالك الاقتصادي أو استفسارك الاستثماري...', en: 'Ask your economic or investment question...' },
  analyzingFiles: { ar: 'جاري تحليل الملفات...', en: 'Analyzing files...' },
  systemActive: { ar: 'النظام نشط', en: 'System Active' },
  copyright: { ar: 'جميع الحقوق محفوظة باسم ا.د/ احمد سعيد البكل © 2024 Elbokl AI.', en: 'Copyright © 2024 Prof. Dr. Ahmed Said Elbokl, Elbokl AI.' },
  exportConversation: { ar: 'تصدير المحادثة', en: 'Export Conversation' },
  quickEconomicAnalysis: { ar: 'تحليل اقتصادي سريع', en: 'Quick Economic Analysis' },
  investmentConsultation: { ar: 'استشارة استثمارية', en: 'Investment Consultation' },
  futureForecasts: { ar: 'توقعات مستقبلية', en: 'Future Forecasts' },
  statisticalTests: { ar: 'اختبارات إحصائية', en: 'Statistical Tests' },
  visualizations: { ar: 'تصورات البيانات', en: 'Data Visualizations' },
  sendMessage: { ar: 'إرسال رسالة', en: 'Send Message' },
  chatInputArea: { ar: 'منطقة إدخال الدردشة', en: 'Chat Input Area' },
  quickActionButtons: { ar: 'أزرار الإجراءات السريعة', en: 'Quick Action Buttons' },
  linkTo: { ar: 'رابط إلى', en: 'Link to' },

  // File size units
  bytes: { ar: 'بايت', en: 'Bytes' },
  kb: { ar: 'كيلو بايت', en: 'KB' },
  mb: { ar: 'ميجابايت', en: 'MB' },
  gb: { ar: 'جيجابايت', en: 'GB' },
  tb: { ar: 'تيرا بايت', en: 'TB' },
  trillion: { ar: 'تريليون', en: 'trillion' }, // Added for large numbers

  // Live API / Voice Chat
  startVoiceChat: { ar: 'بدء المحادثة الصوتية', en: 'Start Voice Chat' },
  stopVoiceChat: { ar: 'إيقاف المحادثة الصوتية', en: 'Stop Voice Chat' },
  listening: { ar: 'جاري الاستماع...', en: 'Listening...' },
  speaking: { ar: 'جاري التحدث...', en: 'Speaking...' },
  voiceChatUnavailable: { ar: 'الدردشة الصوتية غير متاحة في هذا المتصفح', en: 'Voice chat unavailable in this browser' },
  microphonePermissionDenied: { ar: 'تم رفض إذن الميكروفون', en: 'Microphone permission denied' },
  voiceChatError: { ar: 'خطأ في الدردشة الصوتية: {message}', en: 'Voice chat error: {message}' },
  microphoneInitFailed: { ar: 'فشل تهيئة الميكروفون', en: 'Microphone initialization failed' },
  functionCall: { ar: 'استدعاء دالة', en: 'Function Call' },
  executingFunction: { ar: 'جاري تنفيذ الدالة: {name}', en: 'Executing function: {name}' },
  functionExecutedSuccess: { ar: 'تم تنفيذ الدالة {name} بنجاح.', en: 'Function {name} executed successfully.' },
  functionExecutionError: { ar: 'خطأ في تنفيذ الدالة {name}: {message}', en: 'Error executing function {name}: {message}' },
  geminiApiError: { ar: 'خطأ في Gemini API: {message}', en: 'Gemini API Error: {message}' },
  unsupportedToolCall: { ar: 'Elbokl AI طلب أداة غير مدعومة: {name}', en: 'Elbokl AI requested an unsupported tool: {name}' },
  fetchingDataFromTool: { ar: 'جاري جلب البيانات من الأداة...', en: 'Fetching data from tool...' },
  analyzingToolResponse: { ar: 'جاري تحليل استجابة الأداة...', en: 'Analyzing tool response...' },
  unknownError: { ar: 'حدث خطأ غير معروف.', en: 'An unknown error occurred.' }, // New translation
  voiceChatSystemInstruction: { ar: 'أنت مساعد صوتي خبير اقتصادي ودود ومفيد.', en: 'You are a friendly and helpful expert economic voice assistant.' }, // New translation
  voiceChatStopped: { ar: 'تم إيقاف المحادثة الصوتية.', en: 'Voice chat stopped.' }, // New translation
  
  // Conversation History
  untitledChat: { ar: 'محادثة بدون عنوان', en: 'Untitled Chat' },
  confirmDeleteChat: { ar: 'هل أنت متأكد أنك تريد حذف هذه المحادثة؟', en: 'Are you sure you want to delete this chat?' },
  chatLoaded: { ar: 'تم تحميل المحادثة', en: 'Chat loaded' },
  chatDeleted: { ar: 'تم حذف المحادثة', en: 'Chat deleted' },
  chatRenamed: { ar: 'تمت إعادة تسمية المحادثة', en: 'Chat renamed' },
  renameChat: { ar: 'إعادة تسمية', en: 'Rename' },
  deleteChat: { ar: 'حذف', en: 'Delete' },
  enterNewName: { ar: 'أدخل الاسم الجديد', en: 'Enter new name' },
  generateTitlePrompt: { ar: 'أنشئ عنوانًا قصيرًا جدًا (3-5 كلمات) للمحادثة بناءً على هذا الاستعلام الأولي: "{prompt}"', en: 'Generate a very short (3-5 word) title for a conversation based on this initial query: "{prompt}"' },
  startNow: { ar: 'ابدأ الآن', en: 'Start Now' },
  welcomeMessage: {
    ar: 'أهلاً بك في **Elbokl AI**، نظامك الاقتصادي الذكي. أنا هنا لمساعدتك في التحليل الاقتصادي، الاستشارات الاستثمارية، والتنبؤات المستقبلية. يمكنني الاتصال بمصادر بيانات عالمية مثل **{worldBankName}**، **{imfName}**، **{comtradeName}**، و **{fredName}** لتزويدك بأحدث المعلومات. كيف يمكنني مساعدتك اليوم؟',
    en: 'Welcome to **Elbokl AI**, your intelligent economic system. I am here to assist you with economic analysis, investment consulting, and future forecasts. I can connect to global data sources like **{worldBankName}**, **{imfName}**، **{comtradeName}**، and **{fredName}** to provide you with the latest information. How can I help you today?',
  },
  newChatStarted: { ar: 'بدأت محادثة جديدة.', en: 'New chat started.' },
  pleaseEnterMessage: { ar: 'الرجاء إدخال رسالة', en: 'Please enter a message' },
  alreadyUploading: { ar: 'جاري تحميل الملفات بالفعل، يرجى الانتظار.', en: 'Already uploading files, please wait.' },
  failedToReadFile: { ar: 'فشل في قراءة الملف.', en: 'Failed to read file.' },

  // Chart related translations
  economicDataChartTitle: {ar: 'مخطط البيانات الاقتصادية: {indicator} في {country} ({period})', en: 'Economic Data Chart: {indicator} in {country} ({period})'}
};