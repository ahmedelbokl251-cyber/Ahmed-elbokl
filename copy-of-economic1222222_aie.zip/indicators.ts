// indicators.ts
// Fix: Updated import to use the newly defined IndicatorOption from './types'
import { IndicatorOption } from './types';

export const INDICATORS: IndicatorOption[] = [
  // World Bank Indicators (primary code)
  { code: 'NY.GDP.MKTP.CD', name: { ar: 'الناتج المحلي الإجمالي', en: 'GDP' }, unit: { ar: 'دولار أمريكي', en: 'USD' }, fredCode: 'GDP' },
  { code: 'FP.CPI.TOTL.ZG', name: { ar: 'التضخم (مؤشر أسعار المستهلك)', en: 'Inflation (CPI)' }, unit: { ar: 'النسبة المئوية', en: 'Percent' }, fredCode: 'CPIAUCSL' },
  { code: 'SL.UEM.TOTL.ZS', name: { ar: 'معدل البطالة', en: 'Unemployment Rate' }, unit: { ar: 'النسبة المئوية', en: 'Percent' }, fredCode: 'UNRATE' },
  { code: 'FR.INR.LNDP', name: { ar: 'أسعار الفائدة', en: 'Interest Rates' }, unit: { ar: 'النسبة المئوية', en: 'Percent' }, fredCode: 'FEDFUNDS' },
  { code: 'NE.EXP.GNFS.CD', name: { ar: 'الصادرات من السلع والخدمات', en: 'Exports of Goods and Services' }, unit: { ar: 'دولار أمريكي', en: 'USD' }, fredCode: 'EXPGSC1' },
  { code: 'NE.IMP.GNFS.CD', name: { ar: 'الواردات من السلع والخدمات', en: 'Imports of Goods and Services' }, unit: { ar: 'دولار أمريكي', en: 'USD' }, fredCode: 'IMPGSC1' },
  { code: 'BN.CAB.XOKA.CD', name: { ar: 'الحساب الجاري', en: 'Current Account Balance' }, unit: { ar: 'دولار أمريكي', en: 'USD' }, fredCode: 'BOPBCA' },
  { code: 'GC.BAL.CASH.CD', name: { ar: 'الرصيد المالي للحكومة', en: 'Government Cash Surplus/Deficit' }, unit: { ar: 'دولار أمريكي', en: 'USD' }, fredCode: 'MTSDS1_A' }, // US specific FRED
  { code: 'NY.GNS.ICTR.ZS', name: { ar: 'إجمالي الادخار الوطني', en: 'Gross National Savings' }, unit: { ar: 'النسبة المئوية', en: 'Percent' }, fredCode: 'GNSAVE' }, // US specific FRED
  { code: 'BX.KLT.DINV.CD.WD', name: { ar: 'الاستثمار الأجنبي المباشر، صافي التدفقات', en: 'Foreign Direct Investment, net inflows' }, unit: { ar: 'دولار أمريكي', en: 'USD' }, fredCode: 'DRDI' }, // US specific FRED
  { code: 'SP.POP.TOTL', name: { ar: 'إجمالي السكان', en: 'Total Population' }, unit: { ar: 'أشخاص', en: 'Persons' }, fredCode: 'POP' },
  { code: 'EG.GDP.PUSE.KO.PP.KD', name: { ar: 'استهلاك الطاقة بالنسبة للناتج المحلي الإجمالي', en: 'Energy consumption per GDP' }, unit: { ar: 'كيلو جرام مكافئ نفط لكل 1000 دولار أمريكي', en: 'kg of oil equivalent per $1000 GDP' } }, // No direct FRED equivalent
  { code: 'SH.STA.SMSS.ZS', name: { ar: 'انتشار نقص التغذية', en: 'Prevalence of Undernourishment' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } }, // No direct FRED equivalent
  { code: 'SE.SEC.CUAT.LO.ZS', name: { ar: 'معدل إتمام المرحلة الثانوية', en: 'Lower Secondary Completion Rate' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } }, // No direct FRED equivalent
  { code: 'NV.AGR.TOTL.ZS', name: { ar: 'القيمة المضافة للزراعة', en: 'Agriculture, forestry, and fishing, value added (% of GDP)' }, unit: { ar: 'النسبة المئوية', en: 'Percent' } }, // No direct FRED equivalent
  { code: 'IC.BUS.EASE.XQ', name: { ar: 'سهولة ممارسة الأعمال التجارية', en: 'Ease of doing business index' }, unit: { ar: 'الرتبة', en: 'Rank' } }, // No direct FRED equivalent

  // Additional FRED-specific indicators (if no direct World Bank mapping is obvious)
  { code: 'CORESTICKM159SFRBATL', name: { ar: 'مؤشر أسعار المستهلك الأساسي (مقياس كليفلاند)', en: 'Sticky Price CPI (Cleveland Fed)' }, unit: { ar: 'النسبة المئوية', en: 'Percent' }, fredCode: 'CORESTICKM159SFRBATL' },
  { code: 'UNRATE', name: { ar: 'معدل البطالة', en: 'Unemployment Rate' }, unit: { ar: 'النسبة المئوية', en: 'Percent' }, fredCode: 'UNRATE' }, // Duplicate with WB for clarity
  { code: 'CPIAUCSL', name: { ar: 'مؤشر أسعار المستهلك لجميع المناطق الحضرية، جميع السلع', en: 'CPI for All Urban Consumers, All Items' }, unit: { ar: 'مؤشر', en: 'Index' }, fredCode: 'CPIAUCSL' }, // Duplicate with WB for clarity
  { code: 'PCE', name: { ar: 'الإنفاق الاستهلاكي الشخصي', en: 'Personal Consumption Expenditures' }, unit: { ar: 'مليارات الدولارات', en: 'Billions of USD' }, fredCode: 'PCE' },
  { code: 'PCEPILFE', name: { ar: 'مؤشر أسعار الإنفاق الاستهلاكي الشخصي الأساسي', en: 'Core Personal Consumption Expenditures Price Index' }, unit: { ar: 'مؤشر', en: 'Index' }, fredCode: 'PCEPILFE' },
  { code: 'UMCSENT', name: { ar: 'مؤشر معنويات المستهلك (جامعة ميشيغان)', en: 'Consumer Sentiment (Univ. of Michigan)' }, unit: { ar: 'مؤشر', en: 'Index' }, fredCode: 'UMCSENT' },
  { code: 'RECPROUSM156N', name: { ar: 'احتمالية الركود في الولايات المتحدة', en: 'US Recession Probability' }, unit: { ar: 'النسبة المئوية', en: 'Percent' }, fredCode: 'RECPROUSM156N' },
  { code: 'GDPC1', name: { ar: 'الناتج المحلي الإجمالي الحقيقي (سلاسل متسلسلة)', en: 'Real Gross Domestic Product (Chained Series)' }, unit: { ar: 'مليارات الدولارات (2017)', en: 'Billions of Chained 2017 Dollars' }, fredCode: 'GDPC1' },
  { code: 'INDPRO', name: { ar: 'مؤشر الإنتاج الصناعي', en: 'Industrial Production Index' }, unit: { ar: 'مؤشر', en: 'Index' }, fredCode: 'INDPRO' },
  { code: 'PAYEMS', name: { ar: 'إجمالي الوظائف غير الزراعية', en: 'Total Nonfarm Payrolls' }, unit: { ar: 'آلاف الأشخاص', en: 'Thousands of Persons' }, fredCode: 'PAYEMS' },
  { code: 'MSPUS', name: { ar: 'متوسط سعر البيع للمنازل في الولايات المتحدة', en: 'Median Sales Price of Houses Sold for the United States' }, unit: { ar: 'دولار أمريكي', en: 'USD' }, fredCode: 'MSPUS' },
  { code: 'GFDEBTN', name: { ar: 'إجمالي الدين الحكومي الفيدرالي', en: 'Federal Government Total Public Debt' }, unit: { ar: 'مليون دولار', en: 'Millions of USD' }, fredCode: 'GFDEBTN' },
];